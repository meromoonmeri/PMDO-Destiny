# Objets d’intérieur de guilde PMD — lot 02/06

## Cuisine et réfectoire

Les **10 objets** sont des créations distinctes, chacune issue d’une génération d’image. Les bruts sont conservés dans le dossier du projet. La finition enlève le magenta, ajuste l’échelle et remet les couleurs sur la palette de l’atelier.

- `011` Table du réfectoire — 96 × 58 px, au sol.
- `012` Tabouret-souche — 32 × 31 px, au sol.
- `013` Four de pierre — 58 × 58 px, au sol.
- `014` Marmite sur trépied — 36 × 51 px, au sol.
- `015` Bac de lavage — 58 × 60 px, au sol.
- `016` Desserte à vaisselle — 58 × 50 px, au sol.
- `017` Corbeille de baies — 38 × 32 px, sur un meuble.
- `018` Billot aux herbes — 40 × 41 px, au sol.
- `019` Cruche émaillée — 36 × 34 px, sur un meuble.
- `020` Garde-manger — 54 × 71 px, au sol.

- **`Sprites/`** : PNG RGBA à l’échelle 1×, un sprite par fichier. Une tuile logique vaut 8 px.
- **`Planche-transparente.png`** : planche de 560 × 176 px (5 colonnes × 2 lignes ; cellules de 112 × 88 px). Pas de texte ni fond collé aux sprites.
- **`Index.json`** et **`Index.csv`** : rectangles `[x, y, largeur, hauteur]`, mesurés depuis le coin haut gauche de la planche, ainsi que les ancres de pose locales. L’emprise éventuelle est indicative : calculez les collisions selon votre salle.
- **`Apercu-du-lot.png`** : planche légendée agrandie, pour la consultation. N’importez pas cette planche décorative dans le jeu.

Afficher les sprites en **nearest neighbor** / « voisin le plus proche ». Le kit fournit **une orientation statique par objet**, sans animation ni collision préconfigurée. Les fichiers du jeu ne sont pas modifiés.

Direction visuelle : pixel art DS d’Explorateurs du Ciel et bois de la guilde Destiny. Le repère de palette est un extrait de la banque PMU publiée dans le travail précédent ; aucun des 10 sprites livrés ne reprend son dessin.
