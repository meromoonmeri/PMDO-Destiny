# Objets d’intérieur de guilde PMD — lot 04/06

## Bureau et bibliothèque

Les **10 objets** sont des créations distinctes, chacune issue d’une génération d’image. Les bruts sont conservés dans le dossier du projet. La finition enlève le magenta, ajuste l’échelle et remet les couleurs sur la palette de l’atelier.

- `031` Bureau du maître — 84 × 59 px, au sol.
- `032` Lutrin au registre ouvert — 45 × 51 px, au sol.
- `033` Bibliothèque à arche — 62 × 72 px, au sol.
- `034` Globe cartographique — 31 × 46 px, au sol.
- `035` Encrier à plume — 26 × 30 px, sur un meuble.
- `036` Sablier de cuivre — 18 × 29 px, sur un meuble.
- `037` Sceau à cire sur support — 33 × 28 px, sur un meuble.
- `038` Casier des registres — 56 × 32 px, au sol.
- `039` Fauteuil du maître — 53 × 56 px, au sol.
- `040` Boussole sur pied — 39 × 41 px, au sol.

- **`Sprites/`** : PNG RGBA à l’échelle 1×, un sprite par fichier. Une tuile logique vaut 8 px.
- **`Planche-transparente.png`** : planche de 560 × 176 px (5 colonnes × 2 lignes ; cellules de 112 × 88 px). Pas de texte ni fond collé aux sprites.
- **`Index.json`** et **`Index.csv`** : rectangles `[x, y, largeur, hauteur]`, mesurés depuis le coin haut gauche de la planche, ainsi que les ancres de pose locales. L’emprise éventuelle est indicative : calculez les collisions selon votre salle.
- **`Apercu-du-lot.png`** : planche légendée agrandie, pour la consultation. N’importez pas cette planche décorative dans le jeu.

Afficher les sprites en **nearest neighbor** / « voisin le plus proche ». Le kit fournit **une orientation statique par objet**, sans animation ni collision préconfigurée. Les fichiers du jeu ne sont pas modifiés.

Direction visuelle : pixel art DS d’Explorateurs du Ciel et bois de la guilde Destiny. Le repère de palette est un extrait de la banque PMU publiée dans le travail précédent ; aucun des 10 sprites livrés ne reprend son dessin.
