# Jonctions sud sans rallonge — PMD Destiny 0.7.7

Cette version **remplace** le précédent correctif des sols qui prolongeait les sorties. Elle nettoie seulement le trait et les pixels irréguliers entre le bois et le vide dans **l’Accueil** et le **Grand Salon**. Le chemin s’arrête exactement à son extrémité d’origine : même longueur, même contour, aucun pixel peint dans le vide. Les marches et les racines sont conservées.

## Installer

1. Fermez Destiny. **Uniquement si vous avez installé le correctif précédent avec rallonge**, lancez d’abord `Restaurer-les-sols.cmd` depuis **l’ancien ZIP extrait**. N’installez pas les deux versions ensemble.
2. Extrayez ce nouveau ZIP en entier. Lancez `Installer-les-jonctions.cmd` et indiquez le dossier qui contient `Destiny.exe`.
3. Relancez le jeu. Le correctif fenêtres R2 peut rester installé.

Pour annuler cette version, quittez le jeu et lancez `Restaurer-les-jonctions.cmd` depuis ce dossier. Conservez la sauvegarde des deux banques originales dans `.sauvegarde-jonctions-sud-0.7.7`.

## Ce qui change réellement

Seulement deux banques de tuiles natives (`Accueil` et `Grand_Salon`) : 64 pixels retouchés sur le bord de l’Accueil et 67 sur la dernière marche du Grand Salon. Les cartes `.rsground`, l’index des tuiles, les accès, les fichiers de sauvegarde de partie et le vitrage R2 ne sont pas modifiés.

`Avant-apres.png` montre les bords aux mêmes coordonnées avant et après. `Verification.json` détaille les contrôles : rendu dans le moteur 0.7.7, deux transitions au clavier, installation et retour arrière. Les assemblies officielles 0.7.7 et PowerShell 7 ont été exécutés sur le banc Linux ; `Destiny.exe` n’a pas été lancé sous Windows pour ce test.
