@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Appliquer.ps1" -Action Installer
set "CODE=%ERRORLEVEL%"
echo.
pause
exit /b %CODE%
