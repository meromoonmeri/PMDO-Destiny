# PMD Destiny 0.7.7 — Accueil et Grand Salon

La retouche s’applique aux **cartes natives de la publication Windows 0.7.7**. Le parquet a été repris et les planches continuent jusqu’à la dernière rangée de pixels, uniquement dans les deux ouvertures sud. Le fond brun reste visible de chaque côté. Les marches, les racines, les portes, les fenêtres ainsi que les seuils et leurs destinations d’origine sont conservés.

| Salle | Vide au centre avant | Après | Destination du seuil existant |
| --- | ---: | ---: | --- |
| Accueil | 32 px | 0 px | Falaise de la guilde |
| Grand Salon | 49 px | 0 px | Salle des missions |

Le prolongement est **visuel** : il n’ajoute pas de zone à parcourir au-delà du seuil. Les autres salles ne sont pas modifiées. Le correctif fenêtres **R2** peut rester installé et n’est pas requis.

## Installer

1. Fermez le jeu et son éditeur. Extrayez le ZIP **en entier** hors du dossier du jeu.
2. Double-cliquez sur `Installer-la-retouche.cmd`, puis indiquez le **dossier qui contient `Destiny.exe`** (pas le fichier lui-même).
3. Une fois l’installation confirmée, relancez Destiny. Prévoyez environ 220 Mo libres le temps de réécrire l’index de tuiles. Le paquet lui-même ne contient pas l’index complet.

Le programme vérifie les empreintes des deux cartes, de l’index et du nouvel atlas. Il s’arrête si ces ressources ne correspondent pas à celles de la publication 0.7.7 ou du correctif. Il ne remplace ni l’exécutable, ni les scripts, ni les sauvegardes de partie. Ne copiez pas à la main le dossier `Correctif` : l’index et les tuiles doivent être installés ensemble.

## Revenir en arrière

Fermez le jeu et exécutez `Restaurer-les-sols.cmd` en indiquant le même dossier. Les deux Ground d’origine sont sauvegardés dans `.sauvegarde-sols-guilde-0.7.7` : conservez ce dossier. La restauration retire la nouvelle banque de tuiles et rend à l’index son contenu d’origine, sans toucher au vitrage R2.

Pour vérifier la compatibilité sans modifier le jeu, lancez depuis ce dossier dans PowerShell :

```powershell
.\Appliquer.ps1 -Action Verifier -Dossier 'C:\Jeux\PMDO-Destiny'
```

## Vérifications

- Jeu rendu dans le moteur 0.7.7 : comparaison des deux salles de jour, à l’aube, au crépuscule et de nuit.
- Sorties sud franchies au clavier avant et après la retouche : mêmes destinations. Aucune modification des rectangles de collision ni des scripts de transition.
- Installation, refus d’une carte modifiée, retour arrière après une panne simulée et restauration bit à bit contrôlés avec PowerShell 7 sur Linux, sur une copie de ressources 0.7.7 avec le vitrage R2 installé. Le banc utilise les assemblies officielles 0.7.7 ; ce n’est pas un lancement de `Destiny.exe` sous Windows.

`Avant-apres.png` montre les raccords. `Verification.json` contient les résultats de contrôle. La base est la [publication PMDO Destiny v0.7.7](https://github.com/meromoonmeri/PMDO-Destiny/releases/tag/v0.7.7).
