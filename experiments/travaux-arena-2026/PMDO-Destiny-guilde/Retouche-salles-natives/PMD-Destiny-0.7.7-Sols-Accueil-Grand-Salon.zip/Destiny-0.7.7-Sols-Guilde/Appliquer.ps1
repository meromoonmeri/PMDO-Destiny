[CmdletBinding()]
param(
    [ValidateSet('Installer','Restaurer','Verifier')][string]$Action = 'Installer',
    [string]$Dossier
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2

function At([string]$Base,[string]$Rel) { Join-Path $Base $Rel.Replace('/',[IO.Path]::DirectorySeparatorChar) }
function Sha([string]$Path) {
    if ([IO.File]::Exists($Path)) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
    elseif ([IO.Directory]::Exists($Path)) { throw "Un dossier occupe le chemin $Path" }
    else { '' }
}
function Save-Original([string]$src,[string]$dst,[string]$empreinte) {
    if ((Sha $dst) -ceq $empreinte) { return }
    if ([IO.File]::Exists($dst)) { throw "Sauvegarde en conflit : $dst" }
    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($dst)) | Out-Null
    $tmp = $dst + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::Copy($src,$tmp,$false)
        if ((Sha $tmp) -cne $empreinte) { throw "Original inattendu : $src" }
        [IO.File]::Move($tmp,$dst)
    } finally { if ([IO.File]::Exists($tmp)) { [IO.File]::Delete($tmp) } }
}
function Build-Index([string]$src,[string]$dst,[bool]$installer,$meta,[byte[]]$tail) {
    # Preserve the rest of the 0.7.7 index verbatim. The reverse recipe removes
    # only this patch's final entry and resets the 4 byte sheet count.
    $n = [int]$meta.nombre_avant
    $size = [long]$meta.taille_avant
    [IO.File]::Copy($src,$dst,$false)
    $f = [IO.File]::Open($dst,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    try {
        $buf = [byte[]]::new(4)
        if ($f.Read($buf,0,4) -ne 4) { throw 'Index tronque.' }
        if ($installer) {
            if ($f.Length -ne $size -or [BitConverter]::ToInt32($buf,0) -ne $n) { throw 'Index de depart incompatible.' }
            $f.Position = $size
            $f.Write($tail,0,$tail.Length)
            $buf = [BitConverter]::GetBytes([int]($n+1))
        } else {
            if ($f.Length -ne ($size + $tail.Length) -or [BitConverter]::ToInt32($buf,0) -ne ($n+1)) { throw 'Index corrige incompatible.' }
            $f.SetLength($size)
            $buf = [BitConverter]::GetBytes([int]$n)
        }
        $f.Position = 0
        $f.Write($buf,0,4)
        $f.Flush($true)
    } finally { $f.Dispose() }
}

$tile = 'Content/Tile/Destiny_Guilde_Parquet_Sud_077.tile'
$index = 'Content/Tile/index.idx'
$maps = @('Data/Ground/guilde_destiny_accueil.rsground','Data/Ground/guilde_destiny_grand_salon.rsground')
$files = @($tile)+$maps
$lock = $null
$tx = $null
$keep = $false
try {
    $bundle = $PSScriptRoot
    $payload = Join-Path $bundle 'Correctif'
    $m = Get-Content -LiteralPath (Join-Path $bundle 'Manifeste.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($m.version -cne '0.7.7' -or $m.build -cne '3d86bd838698d9de699c76f6f715c8eef35562e5' -or @($m.assets).Count -ne $files.Count) { throw 'Manifeste incompatible.' }
    $spec = @{}
    foreach ($a in $m.assets) {
        if ($files -cnotcontains $a.path -or $spec.ContainsKey($a.path) -or $a.apres_sha256 -cnotmatch '^[0-9a-f]{64}$') { throw 'Manifeste ou chemin incorrect.' }
        if ($a.path -ceq $tile) {
            if ($a.avant_sha256 -cne '') { throw 'Etat initial de la nouvelle banque incorrect.' }
        } elseif ($a.avant_sha256 -cnotmatch '^[0-9a-f]{64}$') { throw 'Empreinte d''origine incorrecte.' }
        $spec[$a.path] = $a
        if ((Sha (At $payload $a.path)) -cne $a.apres_sha256) { throw "Correctif incomplet ou modifie : $($a.path). Reextrayez le ZIP en entier." }
    }
    $idx = $m.index
    if ($idx.path -cne $index -or $idx.tail -cne 'Index-ajout.bin' -or $idx.avant_sha256 -cnotmatch '^[0-9a-f]{64}$' -or $idx.apres_sha256 -cnotmatch '^[0-9a-f]{64}$' -or $idx.tail_sha256 -cnotmatch '^[0-9a-f]{64}$' -or $idx.taille_avant -ne 209431987 -or $idx.nombre_avant -ne 2495) { throw 'Ajout pour index incompatible.' }
    $spec[$index] = $idx
    $tp = Join-Path $bundle $idx.tail
    if ((Sha $tp) -cne $idx.tail_sha256) { throw 'Ajout de banque absent ou modifie.' }
    $tail = [IO.File]::ReadAllBytes($tp)
    $stream = [IO.MemoryStream]::new($tail)
    $read = [IO.BinaryReader]::new($stream)
    try {
        $bankName = $read.ReadString()
        if ($bankName -cne 'Destiny_Guilde_Parquet_Sud_077') { throw 'Nom de banque non conforme.' }
        $start = [int]$stream.Position
        $size = $read.ReadInt32(); $num = $read.ReadInt32()
        $toc = 8 + 16*$num
        if ($size -ne 8 -or $num -lt 1 -or $num -gt 20000 -or $tail.Length-$start -ne $toc) { throw 'En-tete de tuiles invalide.' }
        $bytes = [IO.File]::ReadAllBytes((At $payload $tile))
        if ($bytes.Length -le $toc -or [Convert]::ToBase64String($tail,$start,$toc) -cne [Convert]::ToBase64String($bytes,0,$toc)) { throw 'Index non conforme a la nouvelle banque.' }
    } finally { $read.Dispose() }
    if ([string]::IsNullOrWhiteSpace($Dossier)) {
        Write-Host 'PMD Destiny 0.7.7 - sols de l''Accueil et du Grand Salon'
        Write-Host 'Fermez le jeu. Ce correctif ne modifie pas les sauvegardes.'
        $Dossier = Read-Host 'Chemin du dossier qui contient Destiny.exe (vide = annuler)'
        if ([string]::IsNullOrWhiteSpace($Dossier)) { exit 0 }
    }
    $game = (Resolve-Path -LiteralPath $Dossier.Trim().Trim('"')).ProviderPath
    if (!(Test-Path -LiteralPath (Join-Path $game 'Destiny.exe') -PathType Leaf)) { throw 'Choisissez le dossier qui contient Destiny.exe.' }
    if ($env:OS -eq 'Windows_NT' -and $Action -ne 'Verifier') {
        if (@(Get-Process -Name Destiny -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Le jeu tourne encore. Fermez Destiny avant de continuer.' }
    }
    $install = $Action -eq 'Installer'
    $targets = @($tile,$index)+$maps
    if ($Action -eq 'Restaurer') { $targets = $maps+@($index,$tile) }
    function State {
        $seen = @{}
        foreach ($rel in $targets) {
            $r = $spec[$rel]
            $h = Sha (At $game $rel)
            if ($h -cne $r.avant_sha256 -and $h -cne $r.apres_sha256) { throw "Ressource incompatible (autre version ou retouche locale) : $rel. Aucun fichier de jeu remplace." }
            $seen[$rel] = $h
        }
        return $seen
    }
    $before = State
    $ready = @($targets | Where-Object { $before[$_] -ceq $spec[$_].apres_sha256 }).Count
    if ($Action -eq 'Verifier') { Write-Host "Compatible : $ready/4 ressources deja corrigees."; exit 0 }
    if (($install -and $ready -eq 4) -or (!$install -and $ready -eq 0)) { Write-Host 'Aucun changement necessaire.'; exit 0 }
    $vault = Join-Path $game '.sauvegarde-sols-guilde-0.7.7'
    [IO.Directory]::CreateDirectory($vault) | Out-Null
    $lock = [IO.File]::Open((Join-Path $vault '.verrou'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $before = State
    foreach ($rel in $maps) {
        $a = $spec[$rel]; $original = At $vault $rel
        $store = Sha $original
        if ($store -ne '' -and $store -cne $a.avant_sha256) { throw "Sauvegarde non conforme : $rel" }
        if ($store -eq '') {
            if ($before[$rel] -cne $a.avant_sha256) { throw "Original absent de la sauvegarde : $rel" }
            if ($install) { Save-Original (At $game $rel) $original $a.avant_sha256 }
        }
    }
    $tx = Join-Path $vault ('.operation-' + [Guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($tx) | Out-Null
    $ops = New-Object 'System.Collections.Generic.List[object]'
    foreach ($rel in $targets) {
        $r = $spec[$rel]
        $want = if ($install) { $r.apres_sha256 } else { $r.avant_sha256 }
        if ($want -ceq $before[$rel]) { continue }
        $p = At $game $rel
        $stage = Join-Path $tx ($ops.Count.ToString()+'.new')
        $prev = Join-Path $tx ($ops.Count.ToString()+'.old')
        if ($want -ne '') {
            if ($rel -ceq $index) { Build-Index $p $stage $install $idx $tail }
            else {
                $src = if ($install) { At $payload $rel } else { At $vault $rel }
                [IO.File]::Copy($src,$stage,$false)
            }
            if ((Sha $stage) -cne $want) { throw "Verification avant ecriture echouee : $rel" }
        }
        $ops.Add([pscustomobject]@{rel=$rel; dst=$p; stage=$stage; prev=$prev; old=$before[$rel]; want=$want})
    }
    $done = New-Object 'System.Collections.Generic.List[object]'
    try {
        foreach ($o in $ops) {
            if ((Sha $o.dst) -cne $o.old) { throw "Fichier modifie pendant l'operation : $($o.rel)" }
            if ($o.want -eq '') { [IO.File]::Move($o.dst,$o.prev) }
            elseif ($o.old -eq '') { [IO.File]::Move($o.stage,$o.dst) }
            else { [IO.File]::Replace($o.stage,$o.dst,$o.prev,$true) }
            $done.Add($o)
        }
        foreach ($rel in $targets) {
            $want = if ($install) { $spec[$rel].apres_sha256 } else { $spec[$rel].avant_sha256 }
            if ((Sha (At $game $rel)) -cne $want) { throw "Verification finale echouee : $rel" }
        }
    } catch {
        $err = $_
        for ($i=$done.Count-1;$i -ge 0;$i--) {
            $o = $done[$i]
            try {
                if ($o.old -eq '') { [IO.File]::Delete($o.dst) }
                elseif ([IO.File]::Exists($o.dst)) { [IO.File]::Replace($o.prev,$o.dst,[System.Management.Automation.Language.NullString]::Value,$true) }
                else { [IO.File]::Move($o.prev,$o.dst) }
                if ((Sha $o.dst) -cne $o.old) { throw 'Retour arriere incomplet.' }
            } catch { $keep=$true; Write-Warning "Copie de secours conservee dans : $tx" }
        }
        throw $err
    }
    if ($install) { Write-Host 'Retouche installee. Vous pouvez relancer Destiny.' -ForegroundColor Green }
    else { Write-Host 'Sols et index 0.7.7 d''origine restaures. Le vitrage est inchange.' -ForegroundColor Green }
    exit 0
} catch {
    Write-Host ('ARRET : '+$_.Exception.Message) -ForegroundColor Red
    exit 1
} finally {
    if (!$keep -and $tx -and [IO.Directory]::Exists($tx)) {
        try { [IO.Directory]::Delete($tx,$true) }
        catch { Write-Warning "Dossier temporaire conserve : $tx" }
    }
    if ($null -ne $lock) { $lock.Dispose() }
}
