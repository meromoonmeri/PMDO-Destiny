# Guilde Destiny — 9 salles régénérées

Retouches du générateur à partir des cartes complètes du jeu Windows 0.7.3. Ce sont les **plans Destiny eux-mêmes**, pas des conversions des plans Grodoudou. Les couches indépendantes de décor végétal et de mobilier n’ont pas été activées pour la référence passée au générateur. Aucun décor n’a été assemblé avec des morceaux des anciens essais.

- `Jour/` et `Nuit/` contiennent chacun neuf salles et l’état ouvert du Grand Salon. Le nom et le canevas correspondent à la carte Destiny.
- Export à la définition d’origine, palette pixel art commune sans tramage. La nuit reprend le même dessin avec la teinte et la variation du verre mesurées sur les PNG du jeu. Les deux poses de porte partagent le même décor, la différence est restreinte au voisinage de la porte.
- `Controle.json` donne les dimensions, le recouvrement des silhouettes et les empreintes des bruts. Une génération reste une retouche, pas une copie des pixels de la release.

PNG décoratifs, pas une installation de cartes ou de collisions. Rien n’a été modifié dans le jeu.
