COPIE D’ÉTUDE — NE PAS ÉCRASER LA 0.4.11.
3 cartes de la sauvegarde town02 + 10 banques isolées renommées.
Les scripts de Destiny et les sauvegardes existantes ne sont pas fournis ni modifiés.
Index de tuiles global et compatibilité PMDO 0.8.12 à reconstruire et à tester avant intégration.
Les cartes sont identiques aux originaux hormis les noms de banques, traçabilité dans manifest.json.
