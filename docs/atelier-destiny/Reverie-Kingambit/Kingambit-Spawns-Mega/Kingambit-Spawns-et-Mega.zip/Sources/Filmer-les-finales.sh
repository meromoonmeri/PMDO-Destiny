#!/usr/bin/env bash
set -eu
D="$HOME/.cache/spawns-kingambit"
C="$D/runtime12/jeu/PMDO"
P="$D/profil-film"
mkdir -p "$P/MODS" "$P/SAVE"
ln -sfn "$D/export/Mega/Addon/Mega_Stones_Reverie" "$P/MODS/Mega_Stones_Reverie"
cp "$D/profil/SAVE/SAVE.rssv" "$P/SAVE/"
cd "$C"
export SDL_AUDIODRIVER=dummy
xvfb-run -n 97 -s '-screen 0 960x720x24 -nolisten tcp -noreset' bash -c '
D="$1" P="$2"
./PMDO -appdata "$P/" -mod Mega_Stones_Reverie -lang en -nolog > "$D/natif/film-18.log" 2>&1 & moteur=$!
trap "kill $moteur 2>/dev/null || true" EXIT
xdotool search --sync --name "Mystery Dungeon" >/dev/null
tap(){ xdotool keydown "$1"; sleep .15; xdotool keyup "$1"; }
(sleep 1; for t in Return Return Return x x; do tap "$t"; sleep 1.15; done) &
date +%s.%N > "$D/natif/debut-film.txt"
ffmpeg -nostdin -v error -y -f x11grab -draw_mouse 0 -framerate 30 -video_size 640x480 -i "$DISPLAY.0+160,120" -t 42 -c:v libx264 -threads 1 -preset ultrafast -crf 18 -pix_fmt yuv420p "$D/natif/film-18-brut.mp4"
' _ "$D" "$P"
python - "$D" <<'PY'
import sys
from pathlib import Path
p=Path(sys.argv[1]);log=''.join(f.read_text() for f in (p/'profil-film/LOG').glob('*.txt')); assert 'KINGAMBIT_NATIF ALL DONE 18' in log;print('Capture des 18 finales terminée.')
PY
