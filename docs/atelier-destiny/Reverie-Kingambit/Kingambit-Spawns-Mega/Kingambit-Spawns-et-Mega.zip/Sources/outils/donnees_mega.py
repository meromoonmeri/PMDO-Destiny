#!/usr/bin/env python3
"""Vérifier sans repli les formes pointées par Mega Stones 1.2.0 et récupérer les banques natives."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from urllib.request import urlopen, Request
from urllib.error import HTTPError
from zipfile import ZipFile
import json, re, struct, subprocess, hashlib, time

D = Path(__file__).resolve().parents[1]
A = D/'amont'
S = D/'source'
VANILLA = '9d864d1425f002b051e7a54fffc639988d8ef9c9'
RAW = 'https://raw.githubusercontent.com/audinowho/DumpAsset/'+VANILLA
EXTRA = '''buneary charmeleon charmander wartortle squirtle grovyle treecko electrike snover snorunt riolu haunter gastly gabite gible pidgeotto pidgey kadabra abra kakuna weedle pupitar larvitar shuppet shelgon bagon houndour metang beldum kirlia ralts'''.split()

def git(*a):
    return subprocess.check_output(['git','-C',str(S),*a])

def lire_json(b):
    return json.loads(b.decode('utf-8-sig'))

def amont(p):
    dest=A/'v0812'/p
    if not dest.exists():
        for i in range(3):
            try:
                with urlopen(Request(RAW+'/'+p,headers={'User-Agent':'Destiny-asset-audit'}),timeout=18) as r:
                    b=r.read()
                assert b
                dest.parent.mkdir(parents=True,exist_ok=True)
                dest.write_bytes(b)
                break
            except HTTPError as e:
                if e.code==404: return None
                if i==2: raise
                time.sleep(.4*(i+1))
            except OSError:
                if i==2: raise
                time.sleep(.4*(i+1))
    return dest

def pointer(b):
    off=0
    def read(fmt):
        nonlocal off
        ret=struct.unpack_from('<'+fmt,b,off);off+=struct.calcsize('<'+fmt)
        return ret[0] if len(ret)==1 else ret
    def sub(depth):
        assert depth <=4
        p,n=read('qi'); assert n>=0
        k={}
        for _ in range(n):
            key=read('i');k[key]=sub(depth+1)
        return p,k
    root=sub(0)[1];assert off==len(b),(off,len(b)); return root

def db_fichier(groupe,cle):
    p=f'Data/{groupe}/{cle}.json'
    q=S/'game'/p
    if q.is_file(): return q
    if groupe in OVERRIDES and cle in OVERRIDES[groupe]:
        q.parent.mkdir(parents=True,exist_ok=True)
        q.write_bytes(git('show','HEAD:game/'+p));return q
    return amont(p)

OVERRIDES={g:set(Path(p).stem for p in git('ls-tree','--name-only','HEAD:game/Data/'+g).decode().splitlines() if p.endswith('.json'))
           for g in ('Monster', 'Item')}

def banques(workers=10):
    z=A/'Mega_Stones_V1.2.0.zip'
    articles=[]
    with ZipFile(z) as a:
        for n in sorted(a.namelist()):
            if n.startswith('Data/Item/mega_') and n.endswith('.json'):
                o=lire_json(a.read(n))['Object']; esp=next(v['Value']['ArgTable'] for v in o['UseEvent']['BeforeTryActions'] if v['Value'].get('Script')=='CancelIfWrongMon')
                sp=re.fullmatch(r'\{"([a-z0-9_]+)"\}',esp)[1]
                act=next(v['Value']['Script'] for v in o['UseEvent']['OnHits'] if v['Value'].get('Script','').startswith('Mega_Evolve'))
                articles.append({'id':Path(n).stem,'espece':sp,'forme':2 if act.endswith('_Y') else 1,'nom':o['Name']['DefaultText'],'banque_icone':o['Sprite']+'.dir'})
    assert len(articles)==48
    base_idx=pointer(amont('Content/Chara/index.idx').read_bytes())
    mods_idx=pointer(git('show','HEAD:game/Content/Chara/index.idx'))
    idx={**base_idx,**mods_idx}
    mod_banques=set(git('ls-tree','--name-only','HEAD:game/Content/Chara').decode().splitlines())
    with ThreadPoolExecutor(max_workers=workers) as p:
        sp=sorted({m['espece'] for m in articles}|set(EXTRA)|{'sentret','pikachu','eevee'})
        for name,res in zip(sp,p.map(lambda k:db_fichier('Monster',k),sp)):
            assert res is not None,name
    mon={k:lire_json(db_fichier('Monster',k).read_bytes())['Object'] for k in sp}
    def sprite(m):
        v=mon[m['espece']]; ds=m['forme']; i=v['IndexNum']; m['dex']=i
        m['forme_declaree']=ds<len(v['Forms']) and bool(v['Forms'][ds]['Released'])
        m['types_base']=[v['Forms'][0]['Element1'],v['Forms'][0]['Element2']]
        m['types_mega']=[v['Forms'][ds]['Element1'],v['Forms'][ds]['Element2']] if ds<len(v['Forms']) else None
        form=idx.get(i,(0,{}))[1].get(ds,(0,{}))
        gen=form[1].get(0,(0,{}))
        c=[o for o in (form[0],gen[0],*(x[0] for x in gen[1].values())) if o>0]
        m['positions_sprite_normal']=sorted(set(c)); m['sprite_disponible']=bool(c)
        f=f'{i}.chara'
        if c:
            if f in mod_banques:
                b=git('show','HEAD:game/Content/Chara/'+f);q=A/'destiny-chara'/f;q.parent.mkdir(exist_ok=True);q.write_bytes(b);m['source_chara']='Destiny 936b5623'
            else:
                q=amont('Content/Chara/'+f);assert q;m['source_chara']='PMDO 0.8.12'
            b=q.read_bytes()
            for pos in c:
                plen=struct.unpack_from('<q',b,pos)[0];assert 0<plen<=len(b)-(pos+8) and b[pos+8:pos+16]==b'\x89PNG\r\n\x1a\n',(f,pos)
            m['banque_sprite']=f; m['sha256']=hashlib.sha256(b).hexdigest()
        return m
    # Pas de requêtes Git concurrentes sur les banques d'un même Pokémon.
    with ThreadPoolExecutor(max_workers=workers) as p:
        a=list(p.map(sprite,articles))
    (A/'Catalogue-48-Mega.json').write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    for m in a: print(m['espece'],m['forme'],m['forme_declaree'],m['sprite_disponible'],m.get('source_chara',''),m['nom'])
    for k in ('sprite_disponible','forme_declaree'):
        print(k, sum(m[k] for m in a), '/',len(a), flush=True)
    return a

if __name__=='__main__': banques()
