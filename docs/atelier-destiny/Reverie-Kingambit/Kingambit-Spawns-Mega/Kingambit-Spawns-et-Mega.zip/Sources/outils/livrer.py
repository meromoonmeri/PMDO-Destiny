#!/usr/bin/env python3
"""Contrôler les assets et sceller le lot. Aucun fichier du lot précédent n'est modifié."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from PIL import Image
import hashlib, io, json, struct, subprocess
from casting_kingambit import D,A,S,EXPORT,BOSSES,BASE,lire,git,upindex
from donnees_mega import pointer
from animation_mega import MOD,rebatir

DEST=Path.home()/'PMDO-Destiny-Kabutops/Kingambit-Spawns-Mega'

def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()

def verifier():
    stats=[];commit=(EXPORT/'Integration/Commit.txt').read_text().strip()
    meta=lire(EXPORT/'Index-Spawns.json'); cast=lire(EXPORT/'Registre-des-boss.json'); obj=lire(EXPORT/'Catalogue-48-Mega.json')
    assert len(meta)==len(cast)==18 and len(obj)==48 and len({r['espece'] for r in cast})==18
    for k,a in meta.items():
        for n,v in a['calques'].items():
            rel=Path(v['dossier'])/(v['banque']+'.dir');b=(EXPORT/'Content'/rel).read_bytes();p,=struct.unpack_from('<q',b);w,h=v['cellule_px']
            assert struct.unpack_from('<iiii',b,p+8)==(w,h,0,16) and p+24==len(b)
            im=Image.open(io.BytesIO(b[8:8+p])); assert im.mode=='RGBA' and im.size==(w*4,h*4)
            assert b[8:8+p]==(EXPORT/'Planches'/rel.with_suffix('.png')).read_bytes()
            assert im.crop((3*w,3*h,4*w,4*h)).getbbox() is None,rel
            orig=git('show',f'{commit}:game/Content/{rel.as_posix()}')
            o,=struct.unpack_from('<q',orig)
            oi=Image.open(io.BytesIO(orig[8:8+o])); assert oi.size==im.size and oi.tobytes()==im.tobytes(),rel
            if k in ('water','fire','electric') and n=='Air':
                top=im.crop((w,0,2*w,1)).getbbox() if k!='electric' else im.crop((2*w,0,3*w,1)).getbbox()
                assert top and h==384
        stats.append('PASS '+k+' : banques, alphabet RGBA, pose finale transparente.')
    for row in cast:
        t=row['type'];src=f'game/Data/Map/dojo_kingambit_dedales_{t}.rsmap'
        before,after=(json.loads(git('show',f'{ref}:{src}').decode('utf-8-sig')) for ref in ('936b5623',commit))
        team=after['Object']['MapTeams'][0]['Players'];assert [p['BaseForm']['Species'] for p in team]==row['troupe'] and all(p['BaseForm']['Form']==0 for p in team)
        assert all(before['Object'][k]==v for k,v in after['Object'].items() if k not in ('MapTeams','MapEffect'))
        m=next(x for x in obj if x['id']==row['pierre']);assert m['espece']==row['espece'] and m['sprite_disponible'] and m['forme_declaree'] and t in m['types_base']
    for p in ['game/Data/Zone/dojo_kingambit_dedales.json','game/Data/Script/destiny/dojo_kingambit_sceau.lua']:
        assert git('show',f'936b5623:{p}')==git('show',f'{commit}:{p}')
    addon=EXPORT/'Mega/Addon/Mega_Stones_Reverie'
    with ZipFile(MOD) as z:
        assert z.testzip() is None
        for n in z.namelist():
            if n.endswith('/'):continue
            original=z.read(n); replacement=(addon/n).read_bytes()
            if n.startswith('Data/Item/mega_') and n.endswith('.json'):
                original=json.loads(original.decode('utf-8-sig'));rebuilt=json.loads(json.dumps(original));rebatir(rebuilt,original)
                assert rebuilt==json.loads(replacement)
            elif n!='Mod.xml': assert original==replacement,n
    stats+=['PASS : 18 maîtres avec chacun 2 cadets de sa lignée, 54 formes de base ; formes et sprites Méga sans repli.',
            'PASS : géométrie des 18 finales, Zone des dédales et sceau égaux au candidat Troupes.',
            'PASS : 48 objets comparés à l’original ; seules les données d’effets et leur cadence changent.']
    env={'LUA_PATH':'game/Data/Script/?.lua;game/Data/Script/?/init.lua;;'}
    for n in ['test_dojo_kingambit_troupes.lua','test_dojo_kingambit_spawns_mega.lua']:
        stats.append(subprocess.check_output(['/usr/bin/lua5.4','tools/tests/'+n],cwd=S,env=env,text=True).strip())
    return obj,'\n'.join(stats)+'\n'

def emballer():
    objects,tests=verifier(); (EXPORT/'Preuves/Validations.txt').write_text(tests,encoding='utf-8')
    pack={}
    def add(r,p):
        p=Path(p); assert p.is_file(),p
        assert r not in pack; pack[r]=p
    def tree(folder,base):
        for p in sorted(folder.rglob('*')):
            if p.is_file():add((Path(base)/p.relative_to(folder)).as_posix(),p)
    for n in ('Planches','Content','Mega','Preuves'):tree(EXPORT/n,n)
    for n in ('Index-Spawns.json','Registre-des-boss.json','Catalogue-48-Mega.json','PMDO-LICENCE.txt'):add(n,EXPORT/n)
    for n in ('Spawns-Mega-depuis-Troupes.patch.xz','Spawns-Mega.bundle'):add('Integration/'+n,DEST/n)
    for n in ('Commit.txt','Fichiers.txt'):add('Integration/'+n,EXPORT/'Integration'/n)
    for n in ('Lisez-moi.md','Credits.md','Registre-des-boss.md'):add(n,DEST/n)
    add('Mega_Stones_V1.2.0-original.zip',MOD)
    add('Sources/Mega_Stones-depot-31a26eb9.zip',A/'Mega_Stones.zip')
    tree(D/'motifs','Sources/motifs-1x')
    kept=('normal','grass','fighting','flying','bug','dragon','v2-fire','v2-water','v2-electric','v2-ice','v2-ground','v2-rock','v2-poison')
    for k in kept:add('Sources/dessins-generes/'+k+'.png',D/'bruts'/f'{k}.png')
    tree(D/'ancien','Sources/planches-Troupes-1x')
    tree(A/'raw-anim','Sources/VFX-Mega-PMDCollab')
    for n in ('dessiner_spawns_mega.py','animation_mega.py','donnees_mega.py','casting_kingambit.py','apercu_kingambit.py','banc_kingambit.py','banc_retour_mega.py','monter_natif.py','livrer.py'):
        add('Sources/outils/'+n,D/'outils'/n)
    add('Sources/Filmer-les-finales.sh',D/'natif/filmer-les-finales.sh')
    add('Sprites-PMDO/spritebot_credits.txt',A/'base/spritebot_credits.txt')
    add('Sprites-PMDO/Tyranitar-credits.txt',A/'credits/Tyranitar-SpriteCollab.txt')
    add('Sprites-PMDO/Credits-Destiny.md',S/'CREDITS.md')
    bases={'Destiny':pointer(git('show','936b5623:game/Content/Chara/index.idx')),
           'PMDO-0.8.12':pointer((A/'v0812/Content/Chara/index.idx').read_bytes()),
           'PMDO-6333a8aa':pointer((A/'base/Content/Chara/index.idx').read_bytes())}
    indices={k:{} for k in bases}
    for m in objects:
        if m.get('sprite_complementaire'):
            o=m['sprite_complementaire'];f=A/'complements'/o['banque_sprite'];assert sha(f)==o['sha256'],f
            sub='PMDO-6333a8aa';add(f'Sprites-PMDO/{sub}/Chara/{f.name}',f);indices[sub][m['dex']]=bases[sub][m['dex']]
        if not m['sprite_disponible']:continue
        n=m['banque_sprite'];source=m['source_chara']; sub='Destiny' if source.startswith('Destiny') else 'PMDO-6333a8aa' if n=='248.chara' else 'PMDO-0.8.12'
        f=(A/'destiny-chara'/n) if sub=='Destiny' else (S/'game/Content/Chara'/n if n=='248.chara' else A/'v0812/Content/Chara'/n)
        assert sha(f)==m['sha256'],f
        p=f'Sprites-PMDO/{sub}/Chara/{n}'
        if p not in pack:add(p,f)
        indices[sub][m['dex']]=bases[sub][m['dex']]
    for name,rows in indices.items():
        tmp=EXPORT/'Integration'/f'{name}-chara.idx';tmp.write_bytes(upindex(rows));add(f'Sprites-PMDO/{name}/Chara/index.idx',tmp)
    manifest=''.join(f'{sha(p)}  {n}\n' for n,p in sorted(pack.items())).encode()
    dest=DEST/'Kingambit-Spawns-et-Mega.zip';temp=DEST/'Kingambit-Spawns-et-Mega.tmp'
    with ZipFile(temp,'w',ZIP_DEFLATED,compresslevel=7) as z:
        for n,p in sorted(pack.items()):z.write(p,n)
        z.writestr('SHA256SUMS.txt',manifest)
    with ZipFile(temp) as z:
        assert z.testzip() is None
        for n,p in pack.items():assert hashlib.sha256(z.read(n)).hexdigest()==sha(p),n
    temp.replace(dest)
    f=DEST/'SHA256SUMS.txt';f.write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted(DEST.iterdir()) if p.is_file() and p!=f),encoding='utf-8')
    print(tests,end='');print('ZIP',len(pack)+1,'fichiers',dest.stat().st_size,'octets')

if __name__=='__main__':emballer()
