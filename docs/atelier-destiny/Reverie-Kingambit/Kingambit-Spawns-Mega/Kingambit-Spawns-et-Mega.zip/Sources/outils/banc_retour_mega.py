#!/usr/bin/env python3
"""Test QA uniquement : un escalier dans l'arène du banc mène à un étage 4 de contrôle."""
from copy import deepcopy
from pathlib import Path
import shutil,sys
from casting_kingambit import D, EXPORT, lire, js

C=D/'runtime12/jeu/PMDO'; R=C/'Data'; B=D/'natif/avant-retour';P=D/'profil-retour'
level=R/'Map/dojo_kingambit_dedales_ice.rsmap'; nextlevel=R/'Map/kingambit_qa_floor4.rsmap'
zone=R/'Zone/dojo_kingambit_dedales.json';index=R/'Zone/index.idx'
loader=R/'Script/origin/ground/test_grounds/init.lua'; evt=R/'Script/origin/event_single.lua'; paths=[level,zone,index,loader,evt]
AUDIT='''
-- Test seulement : mesurer le retour automatique du porteur au sol suivant.
function SINGLE_CHAR_SCRIPT.KingambitQAFormeSuivante(o,c,x,a)
  if x.User~=nil then return end
  local ch=GAME:GetPlayerPartyMember(0)
  PrintInfo('KINGAMBIT_RETOUR floor='.._ZONE.CurrentZone.CurrentMapID.ID..' species='..ch.CurrentForm.Species..' form='..ch.CurrentForm.Form..' base='..ch.BaseForm.Form)
end
'''

def main():
    assert not (D/'natif/avant-banc').exists(),'restaurer le banc des 18 avant ce test'
    assert not B.exists()
    for f in paths:
        p=B/f.relative_to(C);p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,p)
    z=lire(zone);f=z['Object']['Segments'][5]['Floors'];f.append(deepcopy(f[2])); f[3]['GenSteps'][0]['Value']['MapID']='kingambit_qa_floor4';js(zone,z)
    ix=lire(index);ix['Object']['dojo_kingambit_dedales']['Maps'][5].append(3);js(index,ix)
    o=lire(level);o2=deepcopy(o)
    t=o['Object']['Tiles'][8][8];assert t['Data']['ID']=='floor';t['Effect'].update(ID='stairs_go_up',Revealed=True);js(level,o)
    o2['Object']['MapTeams']=[]
    o2['Object']['MapEffect']['OnMapStarts']=[{'Key':{'str':[5]},'Value':{'$type':'RogueEssence.Dungeon.SingleCharScriptEvent, RogueEssence','Script':'KingambitQAFormeSuivante','ArgTable':'{}'}}]
    js(nextlevel,o2)
    with evt.open('a') as f:f.write(AUDIT)
    text=loader.read_text().replace('i,2,0,RogueEssence.Data.GameProgress.DungeonStakes.Progress,true,false','i,2,0,RogueEssence.Data.GameProgress.DungeonStakes.Progress,false,false');loader.write_text(text)
    (D/'natif/segment.txt').write_text('5\n')
    q=P/'MODS'/'Mega_Stones_Reverie';q.parent.mkdir(parents=True,exist_ok=True)
    if not q.exists():q.symlink_to(EXPORT/'Mega/Addon/Mega_Stones_Reverie',target_is_directory=True)
    q=P/'SAVE/SAVE.rssv';q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(D/'profil/SAVE/SAVE.rssv',q)
    (P/'SAVE/QUICKSAVE.rsqs').unlink(missing_ok=True)
if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--restore':
        for f in B.rglob('*'):
            if f.is_file():shutil.copy2(f,C/f.relative_to(B))
        nextlevel.unlink(missing_ok=True);shutil.rmtree(B)
    else:main()
