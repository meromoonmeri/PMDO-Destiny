#!/usr/bin/env python3
"""Détourer les motifs générés, animer leurs pixels et écrire les banques PMDO.

Les planches sont en cellules non rognées ; ancre au centre. Les longues
colonnes dépassent la carte vers le haut. Les deux nappes sont des BG répétés.
Sources/motifs contient les cutouts à 1× ; leur reconstruction ne requiert pas l'IA.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageOps
import argparse, io, json, struct, math, random
import numpy as np

D=Path(__file__).resolve().parents[1]
TICKS=4; POSES=16
VERT={'water','fire','electric'}
TERRE={'ground','rock'}
INCHANGES={'psychic','ghost','fairy','dark','steel'}
TYPES='normal fire water grass electric ice fighting poison ground flying psychic bug rock ghost dragon dark steel fairy'.split()
SIZES={k:(112,112) for k in TYPES} | {k:(96,384) for k in VERT} | {'electric':(176,384)}
CUTS={'normal':(45,19),'fire':(47,168),'water':(50,171),'grass':(27,40),'electric':(61,157),'ice':(57,24),
      'fighting':(37,27),'poison':(71,34),'ground':(46,27),'flying':(50,26),'bug':(37,33),'rock':(53,36),'dragon':(50,33)}
PALETTE={
    'water':('#265976','#4eafc7','#abe8ee','#e5ffff'), 'fire':('#773821','#e45827','#ffad4b','#fff0bb'),
    'electric':('#8f6540','#e2ae44','#ffdc63','#fff7cc'),'ice':('#82a8c3','#bbdce7','#e4f4f7','#ffffff'),
    'poison':('#392744','#6a4d74','#866693','#b6a1b7'),'ground':('#533c2d','#a06b3b','#cf9c61','#f0d49a'),
    'rock':('#322927','#705d50','#a99272','#d0b68d'), 'bug':('#45522f','#81994d','#b5cf74','#e8eea1')}

def binaire(p,b):
    p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(b)

def png(im):
    out=io.BytesIO();im.save(out,'PNG',optimize=True);return out.getvalue()

def cut(im,w,h):
    arr=np.array(im.convert('RGBA'),dtype=np.int32); r,g,b,a=arr.transpose(2,0,1)
    key=(r>173)&(b>170)&(r-g>112)&(b-g>106)&(abs(r-b)<82)
    arr[key | (a<140)] = 0
    b=Image.fromarray(arr.astype('uint8')).getbbox(); assert b
    img=Image.fromarray(arr.astype('uint8')).crop(b).resize((w,h),Image.Resampling.NEAREST)
    ar=np.array(img); mask=ar[:,:,3]>0
    flat=Image.fromarray(ar[mask][:,:3][None,...]).quantize(colors=9,method=Image.Quantize.MEDIANCUT,dither=Image.Dither.NONE).convert('RGB')
    ar[mask,:3]=np.array(flat)[0]; ar[~mask]=0; ar[mask,3]=255
    return Image.fromarray(ar)

def prepare(bruts,dest):
    for k,(w,h) in CUTS.items():
        p=bruts/(('v2-' if k in (VERT|TERRE|{'ice','poison'}) else '')+k+'.png')
        binaire(dest/(k+'.png'),png(cut(Image.open(p),w,h)))

def resize(im,w,h): return im.resize((max(1,round(w)),max(1,round(h))),Image.Resampling.NEAREST)

def opac(im,o):
    if o>=255:return im
    c=im.copy();c.putalpha(c.getchannel('A').point(lambda v: round(v*max(0,o)/255)));return c

def stamp(target,im,x,y,alpha=255):
    target.alpha_composite(opac(im,alpha),(round(x),round(y)))

def milieu(target,im,x=0,y=0,alpha=255):
    stamp(target,im,target.width//2+x-im.width//2,target.height//2+y-im.height//2,alpha)

def geom(im):
    x=im.width//2;y=im.height//2;d=ImageDraw.Draw(im,'RGBA')
    def line(points,c,w=1):d.line([(round(x+i),round(y+j)) for i,j in points],fill=c,width=w)
    def arc(cx,cy,rx,ry,a,b,c,w=1):
        d.arc((round(x+cx-rx),round(y+cy-ry),round(x+cx+rx),round(y+cy+ry)),a,b,fill=c,width=w)
    def grain(cx,cy,c,r=1):
        i=round(x+cx);j=round(y+cy)
        if r<=1:d.point((i,j),fill=c)
        else:d.polygon([(i-r,j),(i,j-r//2),(i+r,j),(i,j+r//2)],fill=c)
    return line,arc,grain

def colonne(k,m,f,s,a):
    p=PALETTE[k]; ox=a.width//2; oy=a.height//2
    foot=oy+5
    line,arc,grain=geom(s)
    if k=='electric':
        # Un seul foudre, au milieu. Un réseau de décharges couvre maître et cadets.
        if 4<=f<=13:
            for j,x in enumerate((0,-48,48)):
                t=f-4-j
                if t<0:continue
                y=0 if not x else 24
                for z in range(9):
                    theta=z*math.tau/9+t*.19; r=7+min(t,5)*2.6+(z%2)*5
                    q=(math.cos(theta)*r+x,math.sin(theta)*r*.4+y+3)
                    line([(x+(q[0]-x)*.42,y+(q[1]-y)*.55), (q[0]-3,q[1]+2), q],p[max(0,3-t//3)],1+(z%4==0))
                r=9+t*2.3;arc(x,y+3,r,3+t,6,345,p[max(0,2-t//4)])
            if f<=10:
                for side in (-1,1):
                    line([(0,3),(15*side,9),(24*side,6),(33*side,17),(51*side,26)],p[3 if f<7 else 1])
        arr=f in (2,3,4,5,7,8)
        if arr:
            w=[.7,.79,.9,1,1,.94,.55,.76,.42][f]
            b=resize(m,m.width*w,foot+9); stamp(a,b,ox-b.width//2,0,255 if f<6 else 207)
            if f==2:
                a.paste((0,0,0,0),(0,round(foot*.68),a.width,a.height))
            if f==3:
                a.paste((0,0,0,0),(0,round(foot*.91),a.width,a.height))
        if 5<=f<=13:
            l,_,gr=geom(a)
            for j in range(27):
                rng=random.Random(198+j); x=rng.randrange(-70,71); t=f-4-j%3
                if t<0:continue
                y=(0 if abs(x)<12 else 22)-rng.randint(1,16)-t*2
                if ((j+f*3)%7)<4 and f>6:l([(x-2,y+3),(x,y),(x+2,y+1)],p[1+j%3])
                elif f<=9: gr(x,y,p[2+j%2])
        return
    if f<1:return
    if 4<=f<=14:
        r=6+2.45*(f-4)
        arc(0,4,r,2+r*.32,0,358,p[3 if f<7 else 2 if f<11 else 1],1+(f<8))
        if f>=6:arc(0,7,r*.65,2+r*.22,6,165,p[1])
        for j in range(15):
            t=f-4-j%3
            if t<0:continue
            th=j*2.39996; rng=random.Random(j+80)
            x=(7+t*(1.4+rng.random()))*math.cos(th)
            y=5+x*.08+math.sin(th)*(2+t*.65)
            if t<9:grain(x,y,p[1+j%3],1+(j%3==0 and t<5))
    if f<=11:
        # Le masque progresse de haut en bas. Aucun bouchon en haut du rendu.
        w=(.61,.81,.94,1.0,1.04,.99,.94,.9,.68,.55,.32)[f-1]
        end=foot+(8 if k=='water' else 7)
        length=int(end*((.11,.53,.88,1.0)[min(f-1,3)])) if f<=4 else end
        b=resize(m,m.width*w,end)
        # Les stries du fût se déplacent ; l'impact conserve la silhouette de la source.
        phase=(f*5)%(end-42);l=end-42
        top=Image.new('RGBA',(b.width,l));top.paste(b.crop((0,phase,b.width,l)),(0,0));top.paste(b.crop((0,0,b.width,phase)),(0,l-phase));b.paste(top,(0,0))
        b=b.crop((0,0,b.width,length))
        fade=(255,255,255,255,255,255,235,192,139,89,41)[f-1]
        stamp(a,b,ox-b.width//2,0,fade)
        if f<4:
            l,_,g=geom(a);y=length-oy-1;l([(-3,y),(3,y)],p[3],2)
    if 4<=f<=14:
        l,_,g=geom(a)
        for j in range(16):
            t=f-4-j%3
            if not 0<=t<=8-j%3:continue
            sign=(-1)**j
            x=sign*(5+j%5+t*(1+j%3*.56)); y=4+(j%4)-t*2.6+t*t*.25
            if k=='fire':y-=t*.9
            if j%3==0 and t<6:l([(x,y-2),(x+sign,y),(x,y+(k=='water'))],p[2+(t<4)])
            else:g(x,y,p[2+(j%3==0)])

def crevasse(k,m,f,s,a):
    if f==0 or f==15:return
    w,h=m.size;p=PALETTE[k];t=f-1; n=(.15,.25,.41,.61,.79,.98,1.06,1.05,1.0,.94,.81,.60,.40,.24)[t]
    x=1+min(7,t)*.55
    line,arc,gr=geom(s)
    arc(0,4,3+20*n,2+6*n,172,355,p[1])
    m=resize(m,w*n,h*(.35+.65*n));ww,hh=m.size; mid=ww//2; lip=round(hh*.77)
    # L'ouverture et les pans sont sous le personnage ; seule la lèvre passe devant lui.
    for i,(left,right) in enumerate(((0,mid),(mid,ww))):
        if left==right:continue
        part=m.crop((left,0,right,lip)); low=m.crop((left,lip,right,hh));
        X=(-1 if i==0 else 1)*x+left-ww//2;Y=6-hh//2
        stamp(s,part,s.width//2+X,s.height//2+Y)
        stamp(a,low,a.width//2+X,a.height//2+Y+lip)
    ln,ar,grain=geom(a)
    for j in range(12 if k=='ground' else 8):
        b=f-4-j%3
        if not 0<=b<=8:continue
        q=(-1)**j; xx=q*(6+j%5+b*(1+j%6/6));yy=-j%5-b*3.3+b*b*.47
        grain(xx,yy,p[1+j%3],2+(k=='rock' and b<=4))
        if k=='rock' and b<4:ln([(xx-1,yy),(xx+1,yy-1)],p[3])

def fog(m,f,s,a):
    if not 0<f<15:return
    for i in range(4):
        t=f-i
        if not 0<t<13:continue
        ww=26+min(t,9)*5; b=resize(m,ww,ww*.45)
        # Les nappes basses glissent en profondeur. Pas de bulles toxiques.
        if i%2==0:b=ImageOps.mirror(b)
        alpha=[38,55,97,134,174,201,225,218,183,144,95,45][t-1]
        milieu(s if i==0 else a,b,-27+t*4+i*3,4-(i%3)*8+i*6,alpha if i else alpha//2)

def seamless(target,img,x,y,a):
    for dx in (0,-target.width):
        for dy in (0,-target.height):stamp(target,img,x+dx,y+dy,a)

def meteo(k,m,f):
    W,H=160,120
    env={'ice':(0,26,68,134,204,235,250,251,242,222,184,132,85,49,21,0),
         'poison':(0,7,13,23,36,53,76,96,107,99,89,72,55,36,21,0)}[k][f]
    p=(211,235,246) if k=='ice' else (87,57,106)
    im=Image.new('RGBA',(W,H),(*p,env) if env else (0,0,0,0))
    if not env:return im
    for j in range(13 if k=='ice' else 8):
        rng=random.Random(800+j);w=rng.randint(24,57) if k=='ice' else rng.randint(34,70)
        chip=resize(m,w,w*(.31 if k=='ice' else .46));x=(rng.randrange(W)+f*(14+j%3 if k=='ice' else 2+j%2))%W;y=(rng.randrange(H)+f*(2 if k=='ice' else 0))%H
        seamless(im,chip,x,y,round(env*(.45 if k=='ice' else .74)))
    if k=='ice':
        dr=ImageDraw.Draw(im)
        for j in range(134):
            rng=random.Random(1408+j);v=9+j%11; lng=1+int(v*v/13);x=(rng.randrange(W)+f*v)%W;y=(rng.randrange(H)+f*(1+j%4))%H
            color= (248,255,255,min(255,int(env*.88)+11*(j%5))) if j%3 else (166,207,230,min(246,env+16))
            for dx in (0,-W):
                for dy in (0,-H):dr.line((x+dx,y+dy,x+dx+lng,y+dy+lng//5),fill=color,width=1+(j%19==0))
    return im

def accents(k,m,f,s,a):
    if not (1<=f<=14):return
    if k=='normal':
        for j in range(3):
            t=f-j*2
            if 1<=t<=10:
                w=10+t*5; milieu(s,resize(m,w,w*.39),0,5,255 if t<7 else (11-t)*55)
    elif k=='grass':
        for j,si in enumerate((-1,1)):
            t=f-j
            if not 2<=t<=13:continue
            h=(4+min(t,8)*4)*min(1,(14-t)/4);im=resize(m,h*.65,h)
            if si<0:im=ImageOps.mirror(im)
            milieu(a,im,si*(7+min(10,t)),4-h*.42,255 if t<11 else (14-t)*75)
    elif k=='fighting':
        if 7<=f<=12:
            w=[15,27,40,45,34,22][f-7];milieu(a,resize(m,w,w*.76),0,0,255 if f<=10 else (13-f)*70)
    elif k=='flying':
        if 3<=f<=12:
            t=f-3;w=15+min(5,t)*8;milieu(a,resize(m,w,w*.43),-21+4*t,-30+3.5*t,max(0,min(255,(10-t)*56)))
    elif k=='bug':
        if f>=2 and f<13:
            h=min(32,5+f*4);b=resize(m,h*1.07,h); x=max(0,f-7)*4; mid=b.width//2
            if f<=6:milieu(a,b,0,5-h/2)
            else:
                for i,q in enumerate((b.crop((0,0,mid,h)),b.crop((mid,0,b.width,h)))):
                    milieu(a,q,(-1 if i==0 else 1)*(x+mid/2),3-h/2+x*.42,(13-f)*42)
    elif k=='dragon':
        if 2<=f<=13:
            t=f-2; w=15+min(6,t)*6
            b=resize(m,w,w*.66);milieu(a,b,-16+2*t,4-min(t,8)*2,min(255,(12-t)*53))

def banque(out,name,frames,folder='Particle',col=4):
    w,h=frames[0].size; n=len(frames); row=(n+col-1)//col
    im=Image.new('RGBA',(w*col,h*row))
    for i,f in enumerate(frames):
        assert f.size==(w,h) and f.mode=='RGBA';im.paste(f,(i%col*w,i//col*h))
    img=png(im)
    binaire(out/'Planches'/folder/(name+'.png'),img)
    binaire(out/'Content'/folder/(name+'.dir'),struct.pack('<q',len(img))+img+struct.pack('<iiii',w,h,0,n))
    return {'banque':name,'dossier':folder,'cellule_px':[w,h],'ancre_px':[w//2,h//2], 'colonnes':col,'lignes':row,'poses':n}

def decouper(p,w=112,h=112):
    im=Image.open(p).convert('RGBA');return [im.crop((i%4*w,i//4*h,(i%4+1)*w,(i//4+1)*h)) for i in range(16)]

def monter(out,motifs,anciens):
    idx={}
    for k in TYPES:
        oldS,oldA=([*decouper(anciens/f'{k}_{l}.png')] for l in ('Sol','Air'))
        W,H=SIZES[k];s=[];a=[]
        m=None if k in INCHANGES else Image.open(motifs/(k+'.png')).convert('RGBA')
        for f in range(POSES):
            s0=Image.new('RGBA',(W,H));a0=Image.new('RGBA',(W,H))
            if k in VERT:colonne(k,m,f,s0,a0)
            elif k in TERRE:crevasse(k,m,f,s0,a0)
            elif k=='poison':fog(m,f,s0,a0)
            elif k=='ice':pass # Le blizzard est une nappe qui se répète jusqu'aux bords de l'écran.
            elif k in INCHANGES:s0,a0=oldS[f],oldA[f]
            else:
                s0,a0=oldS[f],oldA[f]
                if k in ('normal',):s0=Image.new('RGBA',(W,H))
                if k in ('grass','bug','dragon'):a0=Image.new('RGBA',(W,H))
                accents(k,m,f,s0,a0)
            s.append(s0);a.append(a0)
        assert s[-1].getbbox() is None and a[-1].getbbox() is None,k
        idx[k]={'inchange':k in INCHANGES,'ticks_par_pose':TICKS,'calques':{}}
        for plan,fs in (('Sol',s),('Air',a)):
            if k=='ice':continue
            idx[k]['calques'][plan]=banque(out,f'Kingambit_Entree_{k}_{plan}',fs)
        if k in ('ice','poison'):
            name='Kingambit_Entree_'+k+'_Ecran'
            idx[k]['calques']['Ecran']=banque(out,name,[meteo(k,m,f) for f in range(16)],'BG')
    binaire(out/'Index-Spawns.json',(json.dumps(idx,indent=2,ensure_ascii=False)+'\n').encode())
    return idx

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--bruts',type=Path);p.add_argument('--motifs',type=Path,default=D/'motifs');p.add_argument('--anciens',type=Path,default=D/'ancien');p.add_argument('--out',type=Path,default=D/'export');args=p.parse_args()
    if args.bruts:prepare(args.bruts,args.motifs)
    monter(args.out,args.motifs,args.anciens)
