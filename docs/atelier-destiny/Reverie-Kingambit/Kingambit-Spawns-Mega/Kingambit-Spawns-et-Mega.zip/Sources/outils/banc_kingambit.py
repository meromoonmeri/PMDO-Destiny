#!/usr/bin/env python3
"""Harnais temporaire : lancer les 18 finales dans PMDO 0.8.12, sans changer le patch livré.

Requiert la base PMDO isolée déjà préparée et les JSON/banques du lot.
Il charge chaque pierre et le sprite correspondant avec le moteur, puis fait
l'aller-retour 0 → Méga → 0 sur le chef seul via les Lua du mod. C'est un audit
technique : les cadets et la sauvegarde du joueur ne sont pas modifiés.
"""
from pathlib import Path
import argparse, json, shutil
from casting_kingambit import D, EXPORT, S, lire, js

C=D/'runtime12/jeu/PMDO'
P=D/'profil-18'
SCRIPTS=C/'Data/Script/origin'
UI=SCRIPTS/'ground/test_grounds/init.lua'
EVENT=SCRIPTS/'event_single.lua'
BAK=D/'natif/avant-banc'

LUA='''
-- Banc QA isolé ; absent de Destiny et du patch.
local seeds=$ROWS
local silencieux=$FILM
local graphics=luanet.import_type('RogueEssence.Content.GraphicsManager')
local data=luanet.import_type('RogueEssence.Data.DataManager').Instance
local function audit(args)
  local zone='dojo_kingambit_dedales'
  local seg=_ZONE.CurrentZone.CurrentMapID.Segment
  local e=seeds[seg+1]
  local group=_ZONE.CurrentMap.MapTeams[0].Players
  assert(group.Count==3 and args.Type==e[1])
  local status=data:GetStatus('mega_evolved')
  local stone=data:GetItem(e[3]);assert(stone~=nil and stone.Released and status~=nil and status.Released)
  local chef=group[0];local base=chef.BaseForm
  assert(base.Species==e[2] and base.Form==0 and chef.CurrentForm.Form==0)
  local spec=data:GetMonster(e[2]);assert(spec.Forms[e[4]].Temporary and spec.Forms[e[4]].Released)
  local verif=RogueEssence.Content.CharID(spec.IndexNum,e[4],0,tonumber(base.Gender) or 2)
  local id=graphics.GetFallbackForm(graphics.CharaIndex,verif)
  assert(id.Species==spec.IndexNum and id.Form==e[4], 'sprite non exact : '..e[2])
  assert(graphics.GetChara(id)~=nil)
  if not silencieux then
    local ctx={User=chef}
    local f=e[4]==1 and BATTLE_SCRIPT.Mega_Evolve or BATTLE_SCRIPT.Mega_Evolve_Y
    f(nil,nil,ctx,{})
    assert(chef.CurrentForm.Form==e[4] and chef.CurrentForm.Species==e[2] and chef.BaseForm.Form==0)
    STATUS_SCRIPT.Mega_Devolve(nil,nil,ctx,{})
    assert(chef.CurrentForm.Form==0 and group[1].CurrentForm.Form==0 and group[2].CurrentForm.Form==0)
    PrintInfo('KINGAMBIT_NATIF pass '..e[1]..' '..e[2]..' stone='..e[3]..' sprite='..id.Species..' form=0>'..e[4]..'>0')
  end
  if seg>=#seeds-1 then
    PrintInfo('KINGAMBIT_NATIF ALL DONE '..#seeds)
  else
    GAME:WaitFrames(12)
    GAME:ContinueDungeon(zone,seg+1,2,0)
  end
end
function SINGLE_CHAR_SCRIPT.KingambitNativeAudit(o,c,x,a)
  if x.User~=nil then return end
  local ok,err=pcall(audit,a)
  if not ok then PrintInfo('KINGAMBIT_NATIF FAIL '..tostring(err)) end
end
'''
START='''local q={}
function q.Enter(map)
  if q.started then return end
  q.started=true
  GAME:FadeIn(1)
  GAME:WaitFrames(25)
  GAME:EnterDungeon('dojo_kingambit_dedales',0,2,0,RogueEssence.Data.GameProgress.DungeonStakes.Progress,false,false)
end
q.GameLoad=q.Enter
return q
'''

def prepare(film=False):
    dossiers=[UI,EVENT]
    reg=lire(EXPORT/'Registre-des-boss.json')
    for r in reg:dossiers.append(C/'Data/Map'/f'dojo_kingambit_dedales_{r["type"]}.rsmap')
    assert not BAK.exists(),'restaurer le banc avant de réinstaller'
    for f in dossiers:
        p=BAK/f.relative_to(C);p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,p)
    sqlite='{' + ',\n'.join('{'+','.join(json.dumps(r[k],ensure_ascii=True) for k in ('type','espece','pierre','forme_mega'))+'}' for r in reg) + '}'
    with EVENT.open('a') as f:f.write(LUA.replace('$ROWS',sqlite).replace('$FILM','true' if film else 'false'))
    UI.write_text(START,encoding='utf-8')
    for r,f in zip(reg,dossiers[2:]):
        j=lire(f)
        j['Object']['MapEffect']['OnMapStarts'].append({'Key':{'str':[10]},'Value':{'$type':'RogueEssence.Dungeon.SingleCharScriptEvent, RogueEssence','Script':'KingambitNativeAudit','ArgTable':f'{{Type="{r["type"]}"}}'}})
        js(f,j)
    q=P/'MODS'/'Mega_Stones_Reverie';q.parent.mkdir(parents=True,exist_ok=True)
    if not q.exists():q.symlink_to(EXPORT/'Mega/Addon/Mega_Stones_Reverie',target_is_directory=True)
    q=P/'SAVE/SAVE.rssv';q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(D/'profil/SAVE/SAVE.rssv',q)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--restore',action='store_true');p.add_argument('--film',action='store_true');a=p.parse_args()
    if a.restore:
        for f in BAK.rglob('*'):
            if f.is_file():shutil.copy2(f,C/f.relative_to(BAK))
        shutil.rmtree(BAK)
    else:prepare(a.film)
