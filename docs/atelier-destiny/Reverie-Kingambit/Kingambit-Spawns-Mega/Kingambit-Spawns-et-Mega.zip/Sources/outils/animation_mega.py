#!/usr/bin/env python3
"""Nouvelle animation des 48 objets de Mega Stones 1.2.0, mécanique à l'identique.

Le tracé conserve les anneaux, l'orbe et les quatre étoiles de PMDCollab/RawAsset.
Il synchronise 215 ticks d'aspiration et 100 ticks d'éclosion avec le son amont.
"""
from copy import deepcopy
import json, math, random
from pathlib import Path
from zipfile import ZipFile
from PIL import Image
from dessiner_spawns_mega import D, banque, milieu, resize, geom, binaire

RAW=D/'amont/raw-anim'; MOD=D/'amont/Mega_Stones_V1.2.0.zip'; OUT=D/'export/Mega'
COULEURS={'Red':('#71314c','#bd526c','#ff916f','#ffe5b7'),
          'White':('#544879','#977dba','#e2cefa','#fff8e4'),
          'Yellow':('#7b533d','#c28842','#f1ca66','#fff6bc'),
          'Light_Blue':('#42527c','#638fcb','#9ddfff','#e9ffff')}
W=H=144; T_CHARGE=5; T_ECLOSION=4; CHARGE=43; ECLOSION=25
NS='RogueEssence.Content.'

def frame():return Image.new('RGBA',(W,H))
def series(name,side):
    im=Image.open(RAW/(name+'.None.png')).convert('RGBA'); assert im.height==side and im.width%side==0
    return [im.crop((i,0,i+side,side)) for i in range(0,im.width,side)]

def charge():
    sol,air=[],[]; rings=series('Circle_Small_Purple_In',32);orbs=series('Light_Ball_Purple',80)
    p=COULEURS['White']
    for f in range(CHARGE):
        s,a=frame(),frame();sol.append(s);air.append(a)
        if f==0:continue
        t=f/(CHARGE-1); L,R,G=geom(s);l,r,g=geom(a)
        radius=14+8*math.sin(min(.5,t)*math.pi)
        R(0,5,radius,5.5,5+f*15,219+f*15,p[1],1)
        R(0,5,radius-2,4.5,185-f*9,311-f*9,p[2])
        if f>10:
            R(0,5,radius+4,7,255+f*3,340+f*3,p[0]);R(0,5,radius+4,7,12+f*3,166+f*3,p[1]);
        # Séparer les stries de la spirale pour garder le corps lisible.
        for j in range(14):
            j1=j*math.tau/14; rng=random.Random(574+j); lag=j%5
            if f<lag:continue
            theta=j1+f*.24;rad=max(4,(rng.randrange(20,35))*(1-t*.76)); y=-(j%3*4+t*11)
            x=math.cos(theta)*rad;y+=math.sin(theta)*rad*.62
            ln,gr=(l,g) if math.sin(theta)>0 else (L,G)
            if j%3==0:ln(((x-3*math.sin(theta),y+1.5*math.cos(theta)),(x,y)), p[1+j%3])
            gr(x,y,p[2+j%2],1+(j%6==0 and t>.36))
        ring=rings[min(len(rings)-1,(f-1)%len(rings))]
        milieu(a,ring,0,-5,158 if f<22 else 211)
        if f>20:
            orb=orbs[min(len(orbs)-1,round((f-20)/22*(len(orbs)-1)))];w=min(86,48+int((f-20)*1.53));
            milieu(a,resize(orb,w,w),0,-7,200 if f<35 else 255)
        if f>37:
            q=13-(f-38)*2; r(0,-7,q,q,10*(f%3),251,p[3],1)
    return sol,air

def eclosion(kind):
    sol,air=[],[]; flux=series('Mega_Background_'+kind,120);p=COULEURS[kind]
    for f in range(ECLOSION):
        s,a=frame(),frame();sol.append(s);air.append(a)
        if f==ECLOSION-1:continue
        L,R,G=geom(s);l,r,g=geom(a)
        u=f/24
        if f<=15:
            size=98+min(6,f)*4
            if f<3:
                ix=min(len(flux)-1,1+f);fade=255
            elif f<9:
                ix=1+(f%max(1,len(flux)-2));fade=251-f*7
            else:
                ix=len(flux)-1 if len(flux)==6 else 1+(f%max(1,len(flux)-2));fade=(16-f)*28
            milieu(s,resize(flux[ix],size,size),0,-7,fade)
        for i in range(2):
            q=f-i*3
            if 0<=q<17:
                rr=10+q*2.6;R(0,6,rr,3+q*1.06,11+i*55,372-i*59,p[3 if q<4 else 2 if q<8 else 1],1+(q<=3))
        if f<5:
            rr=14+f*4;r(0,-7,rr,rr,22+f*45,296+f*11,p[max(0,3-f//2)],1)
        for j in range(20):
            rng=random.Random(1220+j);q=f-j%4
            if not 0<=q<=14+j%4: continue
            theta=(j*2.39996);speed=(1.8+rng.random()*1.4);rad=8+speed*q
            x=math.cos(theta)*rad;y=math.sin(theta)*rad*.61-7-q*.42
            c=p[3] if q<5 else p[2] if q<10 else p[1]
            if j%3==0 and q<10:l(((x-3*math.cos(theta),y-2*math.sin(theta)),(x,y)),c)
            if q<10 or (q+j)%4<2:g(x,y,c,2 if j%3==0 and q<7 else 1)
    return sol,air

def emitter(name,ftime,count,layer):
    return {'$type':NS+'SingleEmitter, RogueEssence','LocHeight':0,'finished':False,'Offset':0,
            'Anim':{'$type':NS+'StaticAnim, RogueEssence','Anim':{'AnimIndex':name,'FrameTime':ftime,
                   'StartFrame':0,'EndFrame':count-1,'AnimDir':-1,'Alpha':255,'AnimFlip':0},
                    'TotalTime':count*ftime,'Cycles':1,'FrameOffset':0},'Layer':layer,'UseDest':False}

def liste(anims):return {'$type':NS+'ListEmitter, RogueEssence','LocHeight':0,'finished':False,'Offset':0,
                        'Anim':anims,'Layer':2,'UseDest':False}

def monde(minimum,maximum,t):return {'MinShake':minimum,'MaxShake':maximum,'MaxShakeTime':t}

def rebatir(d,est):
    o=d['Object']; action=o['UseAction']; af=action['ActionFX']; post=o['UseEvent']['HitFX']; explosion=o['Explosion'];
    glyph=next(x['Anim']['Anim']['AnimIndex'] for x in post['Emitter']['Anim'] if 'Mega_Background_' in x['Anim']['Anim']['AnimIndex']); k=glyph.removeprefix('Mega_Background_');assert k in COULEURS,k
    fog=deepcopy(af['Emitter']['Anim'][0]); assert fog['Anim']['AnimIndex']=='Fog_2';
    fog.update(TotalTime=238,FadeIn=20,FadeOut=57,Color='0, 0, 0, 116')
    af['Emitter']=liste([fog,emitter('Kingambit_Mega_Charge_Sol',T_CHARGE,CHARGE,0),emitter('Kingambit_Mega_Charge_Air',T_CHARGE,CHARGE,3)])
    af['ScreenMovement']=monde(0,0,0)
    action['LagBehindTime']=CHARGE*T_CHARGE
    post['Emitter']=liste([emitter('Kingambit_Mega_Eclosion_'+k+'_Sol',T_ECLOSION,ECLOSION,1),
                          emitter('Kingambit_Mega_Eclosion_'+k+'_Air',T_ECLOSION,ECLOSION,3)])
    # HitFX est lancé avant le script de changement de forme. Ne pas laisser
    # le Pokémon de base visible pendant toute l'étoile : attendre deux poses.
    post['ScreenMovement']=monde(0,1,12);post['Delay']=8
    # Le contrat natif de Explosion exige un CircleSquareEmitter. Garder
    # exactement son type ; une densité nulle supprime la foudre parasite.
    explosion['Emitter']['ParticlesPerTile']=0.0
    if est:
        # Le test rétablit précisément et uniquement les champs visuels autorisés.
        old=est['Object']; back=deepcopy(d)['Object']
        ao,ap=old['UseAction'],back['UseAction'];ap['LagBehindTime']=ao['LagBehindTime'];ap['ActionFX']=ao['ActionFX'];
        back['UseEvent']['HitFX']=old['UseEvent']['HitFX'];back['Explosion']['Emitter']=old['Explosion']['Emitter'];assert back==old
        assert af['Sound']==ao['ActionFX']['Sound']=='Mega_Evolution'
    return k

def main():
    for n,f in zip(('Sol','Air'),charge()):banque(OUT,'Kingambit_Mega_Charge_'+n,f,col=7)
    for c in COULEURS:
        for n,f in zip(('Sol','Air'),eclosion(c)):banque(OUT,'Kingambit_Mega_Eclosion_'+c+'_'+n,f,col=5)
    meta=[]
    tree=OUT/'Addon/Mega_Stones_Reverie'
    with ZipFile(MOD) as z:
        for fname in z.namelist():
            if fname.endswith('/'):continue
            b=z.read(fname)
            if fname.startswith('Data/Item/mega_') and fname.endswith('.json'):
                d=json.loads(b.decode('utf-8-sig'));kind=rebatir(d,deepcopy(d)); b=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode()
                meta.append({'id':Path(fname).stem,'couleur':kind})
            if fname=='Mod.xml':
                b=b.replace(b'<Name>Mega Stones</Name>',b'<Name>Mega Stones - Reverie</Name>')
            binaire(tree/fname,b)
    for p in sorted((OUT/'Content/Particle').glob('*.dir')): binaire(tree/'Content/Particle'/p.name,p.read_bytes())
    assert len(meta)==48
    binaire(OUT/'Index-Mega.json',(json.dumps({'source':'Mega Stones 1.2.0 + PMDCollab/RawAsset',
        'charge':[CHARGE,T_CHARGE], 'eclosion':[ECLOSION,T_ECLOSION], 'objets':meta},indent=2)+'\n').encode())
    print('48 objets : FX seuls modifiés. Dix planches et banques de particules, quatre couleurs. Licence et assets du mod conservés.')

if __name__=='__main__':main()
