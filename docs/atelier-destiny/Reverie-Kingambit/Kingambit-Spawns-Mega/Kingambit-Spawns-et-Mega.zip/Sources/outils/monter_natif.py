#!/usr/bin/env python3
"""Présenter les captures PMDO sans redessiner ni recomposer les scènes."""
from datetime import datetime
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from concurrent.futures import ThreadPoolExecutor
import json,subprocess,re
D=Path(__file__).resolve().parents[1]
O=Path.home()/'PMDO-Destiny-Kabutops/Kingambit-Spawns-Mega'
N=D/'natif'; TMP=N/'film-decoupe'; TMP.mkdir(exist_ok=True)
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans'; W,H=1120,630; XX,YY=42,84
NOMS='Normal|Feu|Eau|Plante|Électrik|Glace|Combat|Poison|Sol|Vol|Psy|Insecte|Roche|Spectre|Dragon|Ténèbres|Acier|Fée'.split('|')
COULEURS='#d8ba94 #ff9b63 #7acef2 #afdc9b #f8d779 #bfecf0 #fca18a #d4abd9 #dbaf83 #b2d4f1 #e7acda #bfda97 #d8be8d #bcb1ed #b5b8eb #c3a4c9 #bcccd5 #f3b5c7'.split()
TITRES=['Piste des échos','Colonnes de flammes','Colonnes d’eau','Fougères déroulées','Foudre et champ statique','Blizzard de poudreuse','Onde de choc','Brouillard du Col Céleste','Brèches de sable','Piqués des alizés','Téléportation prismatique','Cocons fendus','Blocs soulevés','Sortie des ombres','Volutes draconiques','Croissants nocturnes','Berceau magnétique','Pétales de cerisier']

def shq(p):return str(p)
def font(n,b=False):return ImageFont.truetype(FONT+('-Bold' if b else '')+'.ttf',n)

def cartel(i,r):
    e=COULEURS[i];bg='#141b23';fg='#efeee7';low='#a3b0b7';p=Image.new('RGB',(W,H),bg);d=ImageDraw.Draw(p)
    def text(x,y,t,n=20,ink=fg,b=False):d.text((x,y),t,font=font(n,b),fill=ink)
    d.line((42,68,1078,68),fill='#3e4952',width=1)
    text(42,30,'DOJO KINGAMBIT',23,fg,True);text(270,34,'/  Les dix-huit finales',17,low)
    d.rounded_rectangle((924,31,1078,54),4,fill='#24313b');text(935,34,'PMDO 0.8.12',15,'#c5d1d7',True)
    d.rectangle((XX-1,YY-1,XX+640,YY+480),outline='#84989f',width=1)
    x=722;d.line((x,151,1078,151),fill='#4e5661',width=1);d.rectangle((x,149,x+77,152),fill=e)
    text(x,112,f'{i+1:02d}  /  18',18,e,True)
    text(x,171,NOMS[i].upper(),19,e,True)
    text(x,211,r['boss'],40,fg,True)
    text(x,287,TITRES[i],19)
    d.line((x,343,1078,343),fill='#3e4952',width=1)
    text(x,373,'1 MAÎTRE  +  2 CADETS',17,low,True)
    text(x,416,'Sprite Méga vérifié',17,e)
    text(x,442,'Arrivée en forme de base',17,low)
    if r['type'] in ('psychic','ghost','fairy'):text(x,518,'Effet de référence conservé',16,low)
    if r['type'] in ('dark','steel'):text(x,518,'Effet précédent conservé',16,low)
    d.line((42,580,1078,580),fill='#3e4952',width=1)
    text(42,594,'Capture sur un banc isolé • séquences d’entrée, sans combat',15,low)
    for k in range(18):
        x1=893+10*k;d.rectangle((x1,599,x1+6,603),fill=e if i==k else '#50606b')
    path=TMP/f'cartel-{i+1:02}.png';p.save(path);return path

def main():
    rows=json.loads((D/'export/Registre-des-boss.json').read_text()); t0=float((N/'debut-film.txt').read_text());log=''.join(p.read_text() for p in (D/'profil-film/LOG').glob('*.txt'))
    spans={}
    for ts,kind,ty in re.findall(r'\[([0-9/:. ]+)\] \[SE\]:KINGAMBIT_QA (start|end) (\w+)',log):
        tm=datetime.strptime(ts,'%Y/%m/%d %H:%M:%S.%f').timestamp()-t0
        spans.setdefault(ty,{})[kind]=tm
    assert len(spans)==18 and 'NATIF ALL DONE 18' in log
    def part(ir):
        i,r=ir;x=spans[r['type']];beg=x['start']-.095;dur=x['end']-beg+.065
        lbl=cartel(i,r);clip=TMP/f'finale-{i+1:02}.mp4'
        call=['ffmpeg','-nostdin','-v','error','-y','-threads','1','-ss',f'{beg:.3f}','-i',shq(N/'film-18-brut.mp4'),'-loop','1','-framerate','30','-i',shq(lbl),'-filter_complex_threads','1','-filter_complex',f'[0:v]trim=duration={dur:.3f},setpts=PTS-STARTPTS,tpad=stop_mode=clone:stop_duration=0.50[v];[1:v][v]overlay={XX}:{YY}:shortest=1:format=auto[out]',
              '-map','[out]','-an','-r','30','-t',f'{dur+.5:.3f}','-c:v','libx264','-threads','1','-preset','veryfast','-pix_fmt','yuv420p','-crf','18',shq(clip)]
        subprocess.run(call,check=True);return clip
    with ThreadPoolExecutor(max_workers=3) as pool: parts=list(pool.map(part,enumerate(rows)))
    l=TMP/'liste.txt';l.write_text(''.join(f"file '{p.name}'\n" for p in parts));p=O/'Les-18-apparitions-dans-PMDO.mp4'
    subprocess.run(['ffmpeg','-nostdin','-v','error','-y','-f','concat','-safe','0','-i',shq(l),'-c','copy','-movflags','+faststart',shq(p)],check=True)
    print(p)
if __name__=='__main__':main()
