#!/usr/bin/env python3
"""Montage hors moteur : arènes DTEF et sprites issus des banques PMDO réelles."""
from functools import lru_cache
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps
import io, json, math, struct, subprocess
from casting_kingambit import D, A, S, BASE, EXPORT, BOSSES, lire
from donnees_mega import pointer
from dessiner_spawns_mega import stamp, binaire, png, TYPES
from animation_mega import CHARGE,T_CHARGE,ECLOSION,T_ECLOSION

DELIVERY=Path.home()/'PMDO-Destiny-Kabutops/Kingambit-Spawns-Mega'
IDX={**pointer((BASE/'Content/Chara/index.idx').read_bytes()),**pointer((S/'game/Content/Chara/index.idx').read_bytes())}
META=lire(EXPORT/'Index-Spawns.json'); ROSTER={r['type']:r for r in lire(EXPORT/'Registre-des-boss.json')}
LABELS=['Normal','Feu','Eau','Plante','Électrik','Glace','Combat','Poison','Sol','Vol','Psy','Insecte','Roche','Spectre','Dragon','Ténèbres','Acier','Fée']
IDS=['water','fire','ice','ground','rock','electric','poison']
NOTES={
 'water':('Trois colonnes distinctes','Les filets d’eau entrent par le haut.','Tortank et ses cadets avancent','hors de leur propre colonne.'),
 'fire':('Pluie de feu','Trois jets descendent hors champ.','Les flammes éclatent au sol','puis la troupe en sort.'),
 'ice':('Blizzard plein écran','La poudreuse balaie toute la vue.','La troupe apparaît sous le voile,','avant que la neige se dissipe.'),
 'ground':('Sortie du sol','Le sable se fend sous chaque entrée.','Laggron et ses cadets franchissent','le rebord de leur brèche.'),
 'rock':('Pierre soulevée','Trois dalles se fissurent et se soulèvent.','La troupe de Tyranocif surgit','dans les éclats de roche.'),
 'electric':('Foudre et champ statique','Un seul éclair frappe le maître.','Des arcs restent au sol et','s’étendent aux deux cadets.'),
 'poison':('Brume du Col Céleste','Un brouillard violet roule au sol.','Ectoplasma apparaît dans la nappe,','inspirée de la scène du Col Céleste.'),
}
COLORS={'water':'#6cdbef','fire':'#ff945e','ice':'#b6e4ff','ground':'#ecc878','rock':'#d0af86','electric':'#ffe16e','poison':'#dbaddf','mega':'#d7abfb'}

@lru_cache(None)
def lookup(spec):
    p=S/'game/Data/Monster'/f'{spec}.json'
    if not p.exists():p=BASE/'Data/Monster'/f'{spec}.json'
    d=lire(p)['Object'];return d['IndexNum'],d['Forms'][0]

@lru_cache(None)
def banque_chara(dex):
    n=Path(f'Content/Chara/{dex}.chara');p=S/'game'/n
    if p.exists():return p.read_bytes()
    q=A/'destiny-chara'/n.name
    if q.exists():return q.read_bytes()
    if dex in pointer((S/'game/Content/Chara/index.idx').read_bytes()):
        from urllib.request import urlopen
        root='https://raw.githubusercontent.com/meromoonmeri/PMDO-Destiny/37e6b5cdcfb46a064239c7c6983ef4840d27d408/game/'
        with urlopen(root+n.as_posix(),timeout=10) as u:b=u.read()
        assert b[:8]!=b'version '
        q.write_bytes(b);return b
    return (BASE/n).read_bytes()

@lru_cache(None)
def at(spec,form=0,gender=1):
    i,v=lookup(spec); root=IDX[i]; fr=root[1].get(form,(0,{})); skin=fr[1].get(0,(0,{})); ge=skin[1].get(gender,(0,{}))
    pos=next((b for b in (ge[0],skin[0],fr[0],root[0]) if b>0),None)
    assert pos is not None and (form==0 or pos!=root[0]),(spec,form,fr)
    rd=io.BytesIO(banque_chara(i));rd.seek(pos)
    def read(fmt):
        v=struct.unpack('<'+fmt,rd.read(struct.calcsize('<'+fmt)));return v[0] if len(v)==1 else v
    length=read('q'); im=Image.open(io.BytesIO(rd.read(length))).convert('RGBA');w,h,shadow,offsets=read('iiii');rd.seek(offsets*8*4,1)
    anim={}
    for _ in range(read('i')):
        k,ind,copy=read('iii');
        if copy>-1:anim[k]=copy;continue
        rush,hit,ret,n=read('iiii');directions=[]
        for _ in range(n):directions.append([read('iii?iiii') for _ in range(read('i'))])
        anim[k]=directions
    def key(k):
        a=anim.get(k,1)
        if isinstance(a,int):a=anim.get(a)
        if not isinstance(a,list):a=next(g for g in anim.values() if isinstance(g,list))
        results=[]
        for x,y,du,flip,ox,oy,sx,sy in a[0]:
            px=im.crop((x*w,y*h,(x+1)*w,(y+1)*h))
            if flip:px=ImageOps.mirror(px)
            results.append((px,max(1,du),ox-w//2,oy-h//2))
        return results
    return {'Idle':key(1),'Walk':key(2)}

def char(im,spec,pos,t=0,movement='Idle',form=0):
    _,defaut=lookup(spec);kind=1 if defaut['MaleWeight'] else 2 if defaut['FemaleWeight'] else 0
    fs=at(spec,form,kind)[movement];tim=t%sum(x[1] for x in fs)
    px,d,ox,oy=fs[-1]
    for px,d,ox,oy in fs:
        if tim<d:break
        tim-=d
    x,y=pos
    stamp(im,px,x+ox,y+oy)

@lru_cache(None)
def arena(k):
    p=Path.home()/'PMDO-Destiny-Kabutops/Les-dojos-de-Reverie-Magenta/Les-18-arenes-DTEF.png';im=Image.open(p).convert('RGBA')
    i=TYPES.index(k); x=34+i%3*374;y=202+i//3*302
    return im.crop((x,y,x+360,y+264))

@lru_cache(None)
def frames(dir,name,cell,col,n):
    p=EXPORT/dir/(name+'.png');im=Image.open(p).convert('RGBA');w,h=cell
    return [im.crop((i%col*w,i//col*h,(i%col+1)*w,(i//col+1)*h)) for i in range(n)]

def bank(x):return frames('Planches/'+x['dossier'],x['banque'],tuple(x['cellule_px']),x['colonnes'],x['poses'])
def tiled(im,p,color=None):
    for y in range(0,im.height,p.height):
        for x in range(0,im.width,p.width):stamp(im,p,x,y)

def center(im,p,x,y):stamp(im,p,x-p.width//2,y-p.height//2)
def loc(xy):return tuple(x*24+12 for x in xy)

def scene(k,t,duo=True):
    im=arena(k).copy();r=ROSTER[k];c=META[k]['calques'];m=r['mode'];places=[loc(x) for x in r['places']]; departs=[loc(x) for x in r['departs']]
    if m=='warp': t-=20
    anchors=departs if m in ('column','emerge') else places
    def effects(plan):
        if plan not in c:return
        fs=bank(c[plan]); seq=[0] if m=='storm' else [0,6,12]
        for i,delay in enumerate(seq):
            f=(t-delay)//4
            if 0<=f<16:center(im,fs[f],*anchors[i])
    effects('Sol')
    for i,(spec,place,de) in enumerate(zip(r['troupe'],places,departs)):
        va=t-(i*(4 if m=='whiteout' else 6)+r['pose']*4)
        if va<0:
            if m=='warp' and -20<=t<-4:char(im,spec,de,t)
            continue
        if m in ('column','walk','shadow') and va<12:
            x,y=(d+(p-d)*(va/12) for d,p in zip(de,place));char(im,spec,(x,y),va,'Walk')
        elif m in ('emerge','jump') and va<30:
            x,y=(d+(p-d)*(va/30) for d,p in zip(de,place))
            char(im,spec,(x,y-12*math.sin(math.pi*va/30)),va)
        elif m=='drop' and va<24:
            char(im,spec,(place[0],place[1]-192*(1-va/24)),va)
        else:char(im,spec,place,va)
    if duo:
        char(im,'eevee',(168,220),t);char(im,'pikachu',(191,220),t)
    effects('Air')
    if 'Ecran' in c and 0<=t//4<16:tiled(im,bank(c['Ecran'])[t//4])
    return im.crop((20,12,340,252))

def mega(t,nouveau):
    im=arena('water').copy();x,y=180,127
    xfade=round(112*max(0,min(1,t/20,(315-t)/57)))
    im.alpha_composite(Image.new('RGBA',im.size,(0,0,15,xfade)))
    charge=CHARGE*T_CHARGE
    if nouveau:
        mode='Charge' if t<charge else 'Eclosion_Red';ft=T_CHARGE if t<charge else T_ECLOSION
        ns=CHARGE if t<charge else ECLOSION;cols=7 if t<charge else 5
        f=min(ns-1,(t if t<charge else t-charge)//ft)
        for l in ('Sol','Air'):
            if l=='Air':char(im,'blastoise',(x,y),t,form=0 if t<charge else 1)
            b=frames('Mega/Planches/Particle','Kingambit_Mega_'+mode+'_'+l,(144,144),cols,ns)[f];center(im,b,x,y)
    else:
        from animation_mega import series
        if t>=charge:
            fs=series_cached('Mega_Background_Red',120);center(im,fs[((t-charge)//2)%len(fs)],x,y)
        char(im,'blastoise',(x,y),t,form=0 if t<charge else 1)
        if t<charge:
            rings=series_cached('Circle_Small_Purple_In',32);center(im,rings[(t//3)%len(rings)],x,y)
            orbs=series_cached('Light_Ball_Purple',80);center(im,orbs[min(t//21,len(orbs)-1)],x,y)
    return im.crop((20,12,340,252))

@lru_cache(None)
def series_cached(name,side):
    from animation_mega import series
    return series(name,side)

@lru_cache(None)
def font(sz,heavy=False,mono=False):
    f='DejaVuSansMono' if mono else 'DejaVuSans'; f+= '-Bold' if heavy else ''
    return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/'+f+'.ttf',sz)

def ui(k,t,seq):
    W,H=1280,720;im=Image.new('RGB',(W,H),'#141724');d=ImageDraw.Draw(im)
    a=COLORS[k]; meta=ROSTER[k]; px=scene(k,t).convert('RGB').resize((640,480),Image.Resampling.NEAREST)
    d.rectangle((0,0,1280,5),fill=a)
    d.text((40,39),'RÉVERIE  /  DOJO KINGAMBIT',font=font(17,True,True),fill=a)
    d.text((1025,39),f'CHORÉGRAPHIE  {seq:02d}/07',font=font(15,False,True),fill='#c3cadf')
    d.text((40,74),NOTES[k][0],font=font(42,True),fill='#fbf4e8')
    d.rounded_rectangle((38,148,682,632),radius=4,fill='#444e64');im.paste(px,(40,150))
    d.rounded_rectangle((709,148,1240,632),radius=15,fill='#1f2435',outline='#3b4358',width=1)
    d.text((734,179),LABELS[TYPES.index(k)].upper(),font=font(17,True,True),fill=a)
    d.text((731,214),meta['boss'],font=font(55,True),fill='#fff3e3')
    d.text((735,293),meta['nom_pierre'],font=font(21),fill='#cdd6ee')
    d.line((735,342,1213,342),fill='#3d465e')
    for i,line in enumerate(NOTES[k][1:]):d.text((735,369+i*43),line,font=font(20),fill='#f1ebef')
    d.text((735,567),'1 maître · 2 cadets · forme de base au spawn',font=font(16,False,True),fill='#b5c0d6')
    d.text((40,665),'APERÇU HORS MOTEUR   /   ARÈNES DTEF ET SPRITES PMDO À 2×',font=font(14,False,True),fill='#b8c3d7')
    d.rounded_rectangle((836,670,1240,675),radius=3,fill='#434b5e')
    d.rounded_rectangle((836,670,836+int(max(0,min(1,t/112))*404),675),radius=3,fill=a)
    return im

def megaui(t):
    im=Image.new('RGB',(1280,720),'#141724');d=ImageDraw.Draw(im);a=COLORS['mega']
    d.rectangle((0,0,1280,5),fill=a);d.text((40,40),'RÉVERIE  /  MEGA STONES',font=font(17,True,True),fill=a)
    d.text((40,75),'Méga-Évolution · Tortank',font=font(42,True),fill='#fbf4e8')
    for i,name in enumerate(('SOURCE · ANNEAU ET ÉTOILE','RÉVISION · SPIRALE ET ÉCLOSION')):
        x=40+i*600;y=184;w=560;h=420
        d.text((x,y-34),name,font=font(16,True,True),fill=a if i else '#c2cbe0')
        d.rectangle((x-2,y-2,x+w+1,y+h+1),fill='#485068')
        im.paste(mega(t,bool(i)).convert('RGB').resize((w,h),Image.Resampling.NEAREST),(x,y))
    title='Charge et contraction' if t<CHARGE*T_CHARGE else 'Révélation et retombée de lumière'
    d.text((40,627),title,font=font(20,True),fill='#fff3e3')
    d.text((40,673),'MÊMES FORMES, PIERRES ET RÈGLES   /   PRÉSENTATION UNIQUEMENT',font=font(14,False,True),fill='#b8c3d7')
    return im

def poster():
    im=Image.new('RGB',(1060,298+3*346),'#151823');d=ImageDraw.Draw(im)
    d.rectangle((0,0,1060,6),fill='#9ce6d1');d.text((34,32),'PMDO DESTINY  /  DOJO KINGAMBIT',font=font(18,True,True),fill='#9ce6d1')
    d.text((32,71),'Spawns et Méga-Évolution',font=font(53,True),fill='#fff1dd')
    d.text((34,150),'7 entrées redessinées · 18 maîtres compatibles avec une Méga-Gemme',font=font(20),fill='#c3cee0')
    order=IDS+['mega']; picks=[24,24,31,27,30,17,32,CHARGE*T_CHARGE+12]
    for i,(k,t) in enumerate(zip(order,picks)):
        x=34+i%3*335;y=218+i//3*346
        d.text((x,y),f'{i+1:02d}  '+(LABELS[TYPES.index(k)] if k!='mega' else 'Méga-Évolution'),font=font(18,True),fill=COLORS[k])
        d.text((x,y+27),ROSTER[k]['boss'] if k!='mega' else 'Méga-Tortank',font=font(15),fill='#dce3f2')
        p=(scene(k,t) if k!='mega' else mega(t,True)).convert('RGB');im.paste(p,(x,y+58));
    d.text((34,im.height-39),'Images du montage d’aperçu · pas des captures d’un combat',font=font(14,False,True),fill='#b7c3d9');return im

def film():
    DELIVERY.mkdir(parents=True,exist_ok=True)
    montage=EXPORT/'film';montage.mkdir(exist_ok=True)
    poster().save(DELIVERY/'Planche-de-controle.png',optimize=True)
    # Deux ticks du moteur par image (export 30 i/s).
    parts=[]
    def encode(frames,count,path,audio=None,delay=0):
        cmd=['ffmpeg','-hide_banner','-nostdin','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size','1280x720','-framerate','30','-i','-']
        if audio:cmd+=['-i',str(audio)]
        else:cmd+=['-f','lavfi','-i','anullsrc=r=44100:cl=stereo']
        dur=count/30
        cmd+=['-map','0:v','-map','1:a','-c:v','libx264','-preset','veryfast','-threads','2','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','144k','-ar','44100','-ac','2','-af',f'adelay={delay}:all=1,apad','-t',f'{dur:.9f}',str(path)]
        with subprocess.Popen(cmd,stdin=subprocess.PIPE) as p:
            for im in frames:p.stdin.write(im.tobytes())
            p.stdin.close(); assert p.wait()==0,path
        parts.append((path,dur))
    starts=range(-10,133,2); ending=range(0,359,2)
    orig=D/'runtime12/jeu/PMDO/Content/Sound/Battle'
    for i,k in enumerate(IDS,1):encode((ui(k,t,i) for t in starts),len(starts),montage/(k+'.mp4'),orig/f'Kingambit_Whoosh_{k}.ogg',167)
    audio=next((EXPORT/'Mega/Addon').rglob('Mega_Evolution.ogg'))
    encode((megaui(t) for t in ending),len(ending),montage/'mega.mp4',audio)
    part_list=montage/'concat.txt';part_list.write_text(''.join(f"file '{p.name}'\nduration {d:.6f}\n" for p,d in parts))
    dst=DELIVERY/'Apercu-Spawns-et-Mega.mp4'
    subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(part_list),'-map','0:v','-map','0:a','-c:v','copy','-af','aresample=44100:async=1:first_pts=0','-c:a','aac','-movflags','+faststart',str(dst)],check=True)
    subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(dst),'-f','null','-'],check=True)
    print(dst)

if __name__=='__main__':film()
