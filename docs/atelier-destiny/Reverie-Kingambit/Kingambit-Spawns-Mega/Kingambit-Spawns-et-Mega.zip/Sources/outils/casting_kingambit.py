#!/usr/bin/env python3
"""Recaster les dix-huit finales, à cartes/étages/hall strictement constants."""
from collections import namedtuple
from copy import deepcopy
from pathlib import Path
import hashlib,json,sys,struct,shutil,re
from donnees_mega import D,A,S,VANILLA,lire_json,pointer
sys.path.insert(0,str(S/'tools'))
from build_dedales_kingambit import Forgeron
from dojo_kingambit_troupes import FORMATION

Bos=namedtuple('Bos','nom pierre combat effet pose mode')
BOSSES={
 'normal':Bos('Lockpin','mega_lopunnite',(('lopunny','pound','quick_attack'),('buneary','pound'),('buneary','quick_attack')),'Piste des échos',5,'walk'),
 'fire':Bos('Braségali','mega_blazikenite',(('blaziken','ember','double_kick'),('combusken','ember'),('torchic','scratch')),'Fournaises célestes',6,'column'),
 'water':Bos('Tortank','mega_blastoisinite',(('blastoise','water_gun','withdraw'),('wartortle','water_gun'),('squirtle','tackle')),'Colonnes de chute',6,'column'),
 'grass':Bos('Jungko','mega_sceptilite',(('sceptile','absorb','quick_attack'),('grovyle','absorb'),('treecko','pound')),'Fougères déroulées',8,'idle'),
 'electric':Bos('Élecsprint','mega_manectite',(('manectric','spark','leer'),('electrike','tackle'),('electrike','thunder_wave')),'Foudre et champ statique',5,'storm'),
 'ice':Bos('Oniglali','mega_glalitite',(('glalie','powder_snow','leer'),('snorunt','powder_snow'),('snorunt','ice_shard')),'Voile de poudreuse',6,'whiteout'),
 'fighting':Bos('Lucario','mega_lucarionite',(('lucario','quick_attack','force_palm'),('riolu','quick_attack'),('riolu','endure')),'Bonds et onde de choc',3,'jump'),
 'poison':Bos('Ectoplasma','mega_gengarite',(('gengar','lick','disable'),('haunter','lick'),('gastly','astonish')),'Brume du Col Céleste',8,'mist'),
 'ground':Bos('Laggron','mega_swampertite',(('swampert','mud_slap','tackle'),('marshtomp','mud_slap'),('mudkip','tackle')),'Brèches de sable',6,'emerge'),
 'flying':Bos('Dracaufeu','mega_charizardite_x',(('charizard','wing_attack','growl'),('charmeleon','ember'),('charmander','scratch')),'Piqués des alizés',4,'drop'),
 'psychic':Bos('Alakazam','mega_alakazite',(('alakazam','confusion','kinesis'),('kadabra','confusion'),('abra','hidden_power')),'Téléportation prismatique',6,'warp'),
 'bug':Bos('Dardargnan','mega_beedrillite',(('beedrill','fury_attack','focus_energy'),('kakuna','harden'),('weedle','poison_sting')),'Cocons fendus',7,'idle'),
 'rock':Bos('Tyranocif','mega_tyranitarite',(('tyranitar','smack_down','leer'),('pupitar','bite'),('larvitar','bite')),'Mégalithes soulevés',6,'emerge'),
 'ghost':Bos('Branette','mega_banettite',(('banette','astonish','spite'),('shuppet','astonish'),('shuppet','night_shade')),'Sortie des ombres',7,'shadow'),
 'dragon':Bos('Altaria','mega_altarianite',(('altaria','dragon_breath','growl'),('swablu','peck'),('swablu','astonish')),'Volutes draconiques',6,'idle'),
 'dark':Bos('Démolosse','mega_houndoominite',(('houndoom','bite','howl'),('houndour','ember'),('houndour','bite')),'Croissants nocturnes',6,'walk'),
 'steel':Bos('Métalosse','mega_metagrossite',(('metagross','metal_claw','confusion'),('metang','metal_claw'),('beldum','take_down')),'Berceau magnétique',8,'idle'),
 'fairy':Bos('Gardevoir','mega_gardevoirite',(('gardevoir','disarming_voice','growl'),('kirlia','disarming_voice'),('ralts','confusion')),'Pluie de pétales de cerisier',10,'idle'),
}
HEAD_ASSET='6333a8aacfb255d94b085ecf22edb15fcaef56f3'
BASE=D/'runtime12/jeu'/f'DumpAsset-{VANILLA}'
EXPORT=D/'export'


def js(p,o): p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8')
def lire(p): return lire_json(p.read_bytes())
def git(*a):
    import subprocess
    return subprocess.check_output(['git','-C',str(S),*a])

def upindex(b):
    def node(p,k):return struct.pack('<qi',p,len(k))+b''.join(struct.pack('<i',key)+node(*data) for key,data in sorted(k.items()))
    return node(0,b)

def deploy248():
    # Même format 0.8.12.0, dernière banque officielle SpriteCollab compilée
    # par PMDO. Autoriser uniquement la forme pour laquelle l'index est présent.
    latest=pointer((A/'base/Content/Chara/index.idx').read_bytes())
    mod=pointer(git('show','936b5623:game/Content/Chara/index.idx'))
    assert 248 not in mod and 1 in latest[248][1]
    form=latest[248][1][1]; positions=sorted({p for p in (form[0],form[1].get(0,(0,{}))[0]) if p>0});assert positions
    image=(A/'tyranocif/248.chara').read_bytes()
    for p in positions: assert image[p+8:p+16]==b'\x89PNG\r\n\x1a\n'
    c=S/'game/Content/Chara';c.mkdir(parents=True,exist_ok=True)
    (c/'248.chara').write_bytes(image);mod[248]=latest[248];(c/'index.idx').write_bytes(upindex(mod))
    o=lire(BASE/'Data/Monster/tyranitar.json');assert o['Version']=='0.8.12.0'
    assert o['Object']['Forms'][1]['FormName']['DefaultText']=='Mega Tyranitar' and o['Object']['Forms'][1]['Temporary']
    o['Object']['Forms'][1]['Released']=True
    js(S/'game/Data/Monster/tyranitar.json',o)
    return {'sprite_disponible':True,'forme_declaree':True,'banque_sprite':'248.chara','source_chara':'PMDO DumpAsset '+HEAD_ASSET,'positions_sprite_normal':positions,'sha256':hashlib.sha256(image).hexdigest()}

class Fusion(Forgeron):
    def __init__(self): self.max_level=100
    def contenu(self,group,name):
        r=f'Data/{group}/{name}.json';p=S/'game'/r
        if not p.is_file():p=BASE/r
        return lire(p)['Object']


def liste_origines(typ,mode):
    if mode=='warp':return ((6,2),(4,2),(10,2))
    if typ=='dark':return ((6,3),(4,4),(10,4))
    if mode in ('walk','jump','shadow','column','emerge'):return tuple((x,y-1) for x,y in FORMATION)
    return FORMATION


def main():
    assert (BASE/'Data/Monster').is_dir()
    port=deploy248()
    mod=lire(A/'Catalogue-48-Mega.json')
    for m in mod:
        if m['id']=='mega_tyranitarite':m.update(port)
    js(EXPORT/'Catalogue-48-Mega.json',mod)
    megas={r['id']:r for r in mod};f=Fusion();rows=[]; staged=[]
    for typ,b in BOSSES.items():
        mon=b.combat[0][0];m=megas[b.pierre]
        assert m['espece']==mon and m['sprite_disponible'] and m['forme_declaree'] and typ in m['types_base'],(typ,mon,m)
        mdata=f.monstre(mon,typ);assert all(k[0] in set(f.lignee(mon)) for k in b.combat[1:]),(typ,mon)
        assert f.contenu('Monster',mon)['Forms'][m['forme']]['Temporary']
        path=S/'game/Data/Map'/f'dojo_kingambit_dedales_{typ}.rsmap'
        j=lire_json(git('show',f'936b5623:game/Data/Map/{path.name}'));orig=deepcopy(j);o=j['Object']; team=o['MapTeams'][0]
        origines=liste_origines(typ,b.mode)
        assert all(o['Tiles'][x][y]['Data']['ID']=='floor' for x,y in (*origines,*FORMATION)),(typ,origines)
        team['Players']=[f.combattant(team['Players'][i],esp,moves,pos,niv,points)
            for i,((esp,*moves),pos,niv,points) in enumerate(zip(b.combat,FORMATION,(12,8,7),(10,0,0)))]
        for e in o['MapEffect']['OnMapStarts']:
            if e['Value'].get('Script') in ('DestinyDojoTroupeMasquer','DestinyDojoTroupeJouer'):
                luapoints='{'+','.join('{'+str(x)+','+str(y)+'}' for x,y in origines)+'}'
                e['Value']['ArgTable']=f'{{ Type = "{typ}", Mode = "{b.mode}", Pose = {b.pose}, Origines = {luapoints} }}'
        for k in o:
            if k not in ('MapTeams','MapEffect'):assert o[k]==orig['Object'][k],(typ,k)
        staged.append((path,j));rows.append(dict(type=typ,boss=b.nom,espece=mon,troupe=[i[0] for i in b.combat],
                                                   pierre=b.pierre,nom_pierre=m['nom'],forme_mega=m['forme'],
                                                   effet=b.effet,pose=b.pose,mode=b.mode,departs=origines,places=FORMATION))
    for p,j in staged:js(p,j)
    cfg=S/'tools/dojo_kingambit_troupes.py'; text=git('show','936b5623:tools/dojo_kingambit_troupes.py').decode()
    new=repr({k:(b.combat,b.effet,b.pose,b.mode) for k,b in BOSSES.items()})
    cfg.write_text(text[:text.index('TROUPES = ')]+'TROUPES = {\n'+',\n'.join(f'    {k!r}: {(b.combat,b.effet,b.pose,b.mode)!r}' for k,b in BOSSES.items())+'\n}\nMEGA_STONES = '+repr({k:b.pierre for k,b in BOSSES.items()})+'\n'+text[text.index('POSES, TICKS'):].replace("('walk','jump','shadow')","('walk','jump','shadow','column','emerge')"),encoding='utf-8')
    js(EXPORT/'Registre-des-boss.json',rows)
    for r in rows:print('PASS',r['type'],r['boss'],r['pierre'],r['mode'])
    print('18 boss uniques, sprites/formes présents, cadets de lignée, géométrie inchangée.')

if __name__=='__main__':main()
