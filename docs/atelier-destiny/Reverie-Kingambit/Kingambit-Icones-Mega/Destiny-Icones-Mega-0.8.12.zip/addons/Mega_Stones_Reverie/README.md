![mega_evolution](https://github.com/Deeshura/Mega_Stones/blob/main/Github_Assets/mega_stones.gif?raw=true)

# Mega Stones
 Adds Mega Stones and Mega Evolution to PMDO. By using a Mega Stone, your team members can Mega Evolve, becoming stronger until you progress to the next floor. However, each use of a Mega Stone drains your belly somewhat, so be careful!

 For those looking to obtain these Mega Stones, there's rumors about of a mysterious Pokémon seen sneaking into a cave on the outskirts of Overgrown Wilds...

## TODO
 * Localization.
 * Adding in new Mega Stones as they're released.

## Credits
Item icons by Ryveriel.

Thanks to Trio- for translating FormChoiceEvent's C# script for calling CancelState into lua, and correcting my syntax.

Thanks to FlowerSnek, Palika, and Sh\*tpost Sunkern for valuable feedback on a cutscene.

Thanks to MistressNebula for helping work out a system for devolving the player between floors, as well as pointing me in the right direction for scripting systems to check which Mega Evolutions are available and in the players Pokedex.

This project is an addon mod for [PMDO](https://github.com/audinowho/PMDODump). PMDO is Copyright (c) Audino 2021.

Furthermore, special thanks to Audino for adding a boolean to FormChoiceEvent() for temporary forms, and PMDO wiki contributer "IDK"'s articles on [modding moves](https://wiki.pmdo.pmdcollab.org/Creating_Moves) thanks to the useful emitter documentation there.
