# Appliquer le lot Fosse Cascade & Réverie

Patch Git avec les binaires natifs et comprimés. Base exacte : `aa1430c4e8953e486b82691731fbbcbce8e4c57e`
(`wip/reverie-integration-kingambit-cafe`). Ce n’est pas une distribution autonome du jeu.

1. Décompresser cette archive à côté d'un checkout propre de la base de travail. Ne pas appliquer le patch par-dessus un autre lot de retouches sans vérifier le diff.
2. À la racine du dépôt, lancer `git apply --check /chemin/Fosse-Reverie.patch`.
3. Si la vérification passe, lancer `git apply /chemin/Fosse-Reverie.patch`. Cette commande ne commit ni ne pousse.
4. Pour jouer ou tester : si les anciens grounds Réverie ont déjà été décompressés, les mettre de côté (l’outil refuse de les écraser). Les dix chemins concernés sont déclarés dans `tools/unpack_payload.py`. Régénérer `game/Content/Tile/index.idx` avec `python tools/build_tile_index.py` s’il existe déjà, puis lancer `python tools/unpack_payload.py`.
5. Contrôles conseillés : `python tools/validate.py`, `python tools/tests/test_grotte_verdoyante.py`, `python tools/tests/test_polish_reverie.py` et `python tools/tests/test_reverie_architecture.py`. Tests avec Pillow, ijson et Lupa ou l’environnement de tests du projet.

Ne pas appliquer sur votre jeu installé ou sur un profil personnel. Le patch ne transporte ni sauvegardes, ni atlas externes, ni fichiers générés.

Application comparée octet à octet au lot local : 29 fichiers.
SHA-256 du patch : `6e58d44d58084d64594469eb90555a8700201d2d0b85f7525d23fdd16f8523e3`.
