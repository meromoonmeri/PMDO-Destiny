# Guilde Destiny — nuit et verdure de Grodoudou

Les mêmes 9 plans Destiny et les mêmes accès que dans le lot précédent. Aucun bois des éditions générées pour le lierre n’a été recopié dans les cartes.

- **Salles/** : les versions jour et nuit avec verdure. Pour le Grand Salon, les deux états de porte partagent la même verdure.
- **Sans-verdure/** : les neuf salles avec les vitres et l’ambiance corrigées, sans le calque végétal (porte fermée pour le Grand Salon).
- **Calques/Verdure/** : 9 calques PNG transparents par ambiance, un dessin généré pour le mur de chaque salle. À poser à (0,0). Aucun pixel sur les baies, les escaliers ni les seuils protégés.
- **Masques/Verre/** : les vitres isolées, sans le bois. La nuit, elles reçoivent directement la couleur bleue de la guilde de Grodoudou, sans opération de soustraction qui pourrait les noircir.

La nuit reprend les fonds indigo et les teintes mesurées sur les variantes des cartes de Grodoudou. Les communs restent plus chauds et lisibles que le côté dortoir. Les salles sans rip nocturne correspondant reprennent la palette du même secteur. Voir [les rips Explorateurs du Ciel](https://projectpokemon.org/home/gallery/category/12-pok%C3%A9mon-mystery-dungeon-explorers-of-sky/).

PNG de décor et calques d’image, pas de carte jouable ni de modification du jeu.
