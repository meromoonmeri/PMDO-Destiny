[CmdletBinding()]
param(
    [ValidateSet('Installer','Restaurer','Verifier')][string]$Action='Installer',
    [string]$Dossier
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2
function At([string]$Base,[string]$Rel) { Join-Path $Base $Rel.Replace('/',[IO.Path]::DirectorySeparatorChar) }
function Digest([string]$File) {
    if ([IO.File]::Exists($File)) { (Get-FileHash -LiteralPath $File -Algorithm SHA256).Hash.ToLowerInvariant() }
    elseif ([IO.Directory]::Exists($File)) { throw "Un dossier occupe le chemin : $File" }
    else { '' }
}
function Save-Original([string]$src,[string]$dst,[string]$hash) {
    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($dst)) | Out-Null
    $temp=$dst+'.'+[Guid]::NewGuid().ToString('N')+'.tmp'
    try {
        [IO.File]::Copy($src,$temp,$false)
        if ((Digest $temp) -cne $hash) { throw "Original inattendu : $src" }
        [IO.File]::Move($temp,$dst)
    } finally { if ([IO.File]::Exists($temp)) { [IO.File]::Delete($temp) } }
}
$lock=$null
$tx=$null
$keep=$false
try {
    $bundle=$PSScriptRoot
    $payload=Join-Path $bundle 'Correctif'
    $m=Get-Content -LiteralPath (Join-Path $bundle 'Manifeste.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($m.version -cne '0.7.7' -or $m.objet -cne 'cadrage-sud-seules' -or $m.commit -cne '3d86bd838698d9de699c76f6f715c8eef35562e5') { throw 'Manifeste incompatible.' }
    $names=@('guilde_destiny_accueil','guilde_destiny_missions','guilde_destiny_grand_salon','guilde_destiny_bureau_maitre','guilde_destiny_cuisine','guilde_destiny_dortoir_nord_1','guilde_destiny_dortoir_nord_2')
    $new='Data/Script/destiny/guilde_cadrage_sud.lua'
    $paths=@($new)+@($names | ForEach-Object { "Data/Script/destiny/ground/$_/init.lua" })
    $rows=@($m.assets)
    $mapRows=@($m.salles)
    if ($rows.Count -ne 8 -or $mapRows.Count -ne 7) { throw 'Fichiers attendus absents du manifeste.' }
    $spec=@{}
    foreach ($r in $rows) {
        if ($paths -cnotcontains $r.path -or $spec.ContainsKey($r.path) -or $r.apres_sha256 -cnotmatch '^[0-9a-f]{64}$') { throw 'Nom de fichier ou empreinte invalide.' }
        if ($r.path -ceq $new) { if ($r.avant_sha256 -cne '') { throw 'Module du correctif invalide.' } }
        elseif ($r.avant_sha256 -cnotmatch '^[0-9a-f]{64}$') { throw 'Empreinte du script original invalide.' }
        $spec[$r.path]=$r
        if ((Digest (At $payload $r.path)) -cne $r.apres_sha256) { throw "Correctif incomplet ou modifie : $($r.path). Extrayez le ZIP en entier." }
    }
    $seen=@{}
    foreach ($r in $mapRows) {
        if ($names -cnotcontains $r.salle -or $seen.ContainsKey($r.salle) -or $r.ground -cne ('Data/Ground/'+$r.salle+'.rsground') -or $r.ground_sha256 -cnotmatch '^[0-9a-f]{64}$') { throw 'Carte non autorisee dans le manifeste.' }
        $seen[$r.salle]=$true
    }
    if ([string]::IsNullOrWhiteSpace($Dossier)) {
        Write-Host 'PMD Destiny 0.7.7 - cadrage des sorties sud'
        Write-Host 'Fermez le jeu avant de continuer.'
        $Dossier=Read-Host 'Dossier qui contient Destiny.exe (vide = annuler)'
        if ([string]::IsNullOrWhiteSpace($Dossier)) { exit 0 }
    }
    $game=(Resolve-Path -LiteralPath $Dossier.Trim().Trim('"')).ProviderPath
    if (!(Test-Path -LiteralPath (Join-Path $game 'Destiny.exe') -PathType Leaf)) { throw 'Choisissez le dossier qui contient Destiny.exe.' }
    if ($env:OS -eq 'Windows_NT' -and $Action -ne 'Verifier' -and @(Get-Process -Name Destiny -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Destiny est ouvert. Fermez le jeu puis reessayez.' }
    if ($Action -ne 'Restaurer') {
        if (Test-Path -LiteralPath (At $game 'Content/Tile/Destiny_Guilde_Parquet_Sud_077.tile')) { throw 'Ancienne version avec rallonge detectee. Utilisez Restaurer-les-sols.cmd de son ZIP avant d''installer ce cadrage.' }
        foreach ($r in $mapRows) {
            if ((Digest (At $game $r.ground)) -cne $r.ground_sha256) { throw "Carte non conforme a la publication Windows 0.7.7 : $($r.ground). Aucun fichier remplace." }
        }
    }
    $install=$Action -eq 'Installer'
    $order=$paths
    if ($Action -eq 'Restaurer') { $order=@($paths | Where-Object { $_ -cne $new })+@($new) }
    function Read-State {
        $r=@{}
        foreach ($rel in $order) {
            $h=Digest (At $game $rel)
            if ($h -cne $spec[$rel].avant_sha256 -and $h -cne $spec[$rel].apres_sha256) { throw "Script incompatible ou deja modifie : $rel. Aucun fichier remplace." }
            $r[$rel]=$h
        }
        return $r
    }
    $state=Read-State
    $ready=@($paths | Where-Object { $state[$_] -ceq $spec[$_].apres_sha256 }).Count
    if ($Action -eq 'Verifier') { Write-Host "Compatible : $ready/8 scripts deja corriges."; exit 0 }
    if (($install -and $ready -eq 8) -or (!$install -and $ready -eq 0)) { Write-Host 'Aucun changement necessaire.'; exit 0 }
    $vault=Join-Path $game '.sauvegarde-cadrage-sud-0.7.7'
    [IO.Directory]::CreateDirectory($vault) | Out-Null
    $lock=[IO.File]::Open((Join-Path $vault '.verrou'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $state=Read-State
    foreach ($rel in ($paths | Where-Object { $_ -cne $new })) {
        $original=At $vault $rel; $before=$spec[$rel].avant_sha256; $got=Digest $original
        if ($got -ne '' -and $got -cne $before) { throw "Sauvegarde en conflit : $rel" }
        if ($got -eq '') {
            if ($state[$rel] -cne $before) { throw "Original indisponible dans la sauvegarde : $rel" }
            if ($install) { Save-Original (At $game $rel) $original $before }
        }
    }
    $tx=Join-Path $vault ('.operation-'+[Guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($tx) | Out-Null
    $ops=New-Object 'System.Collections.Generic.List[object]'
    foreach ($rel in $order) {
        $from=$state[$rel]
        $want=if($install){$spec[$rel].apres_sha256}else{$spec[$rel].avant_sha256}
        if($want -ceq $from){continue}
        $stage=Join-Path $tx ($ops.Count.ToString()+'.new')
        $old=Join-Path $tx ($ops.Count.ToString()+'.old')
        if ($want -ne '') {
            $src=if($install){At $payload $rel}else{At $vault $rel}
            [IO.File]::Copy($src,$stage,$false)
            if ((Digest $stage) -cne $want) { throw "Copie non conforme : $rel" }
        }
        $ops.Add([pscustomobject]@{rel=$rel;dst=(At $game $rel);stage=$stage;old=$old;from=$from;want=$want})
    }
    $done=New-Object 'System.Collections.Generic.List[object]'
    try {
        foreach ($op in $ops) {
            if ((Digest $op.dst) -cne $op.from) { throw "Ressource modifiee pendant l'operation : $($op.rel)" }
            if ($op.want -eq '') { [IO.File]::Move($op.dst,$op.old) }
            elseif ($op.from -eq '') { [IO.File]::Move($op.stage,$op.dst) }
            else { [IO.File]::Replace($op.stage,$op.dst,$op.old,$true) }
            $done.Add($op)
        }
        foreach ($rel in $order) {
            $want=if($install){$spec[$rel].apres_sha256}else{$spec[$rel].avant_sha256}
            if ((Digest (At $game $rel)) -cne $want) { throw "Verification finale echouee : $rel" }
        }
    } catch {
        $failure=$_
        for($i=$done.Count-1;$i -ge 0;$i--) {
            $op=$done[$i]
            try {
                if ($op.from -eq '') { [IO.File]::Delete($op.dst) }
                elseif ([IO.File]::Exists($op.dst)) { [IO.File]::Replace($op.old,$op.dst,[System.Management.Automation.Language.NullString]::Value,$true) }
                else { [IO.File]::Move($op.old,$op.dst) }
                if ((Digest $op.dst) -cne $op.from) { throw 'Annulation incomplete.' }
            } catch { $keep=$true; Write-Warning "Copie de secours conservee dans : $tx" }
        }
        throw $failure
    }
    if ($install) { Write-Host 'Cadrage installe. Vous pouvez relancer Destiny.' -ForegroundColor Green }
    else { Write-Host 'Cadrage original restaure. Cartes et graphismes inchanges.' -ForegroundColor Green }
    exit 0
} catch {
    Write-Host ('ARRET : '+$_.Exception.Message) -ForegroundColor Red
    exit 1
} finally {
    if (!$keep -and $tx -and [IO.Directory]::Exists($tx)) {
        try { [IO.Directory]::Delete($tx,$true) } catch { Write-Warning "Dossier temporaire conserve : $tx" }
    }
    if ($null -ne $lock) { $lock.Dispose() }
}
