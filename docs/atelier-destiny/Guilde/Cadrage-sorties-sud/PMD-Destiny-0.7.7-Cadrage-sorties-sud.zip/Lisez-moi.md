# Cadrage des sorties sud · PMD Destiny 0.7.7

La caméra de suivi s’arrête à la fin du bois ou de la dernière marche. La bande brune **sous** le passage sort de l’écran ; le fond reste visible à gauche et à droite. Le chemin n’est ni rallongé ni retouché par ce correctif, et l’itinéraire du héros ne change pas.

**Sept salles :** Accueil, Missions, Grand Salon, Bureau du maître, Cuisine, Dortoir nord I et Dortoir nord II. Le Carrefour et les deux couloirs ne présentaient pas cette bande sous leur sortie sud ; ils sont laissés tels quels.

## Installer sous Windows

1. Fermez Destiny. **Seulement si vous avez installé l’ancien correctif qui ajoutait du bois**, lancez d’abord `Restaurer-les-sols.cmd` de son ZIP. Il ne s’agit pas du correctif du liseré.
2. Extrayez **tout** ce ZIP dans un dossier. Lancez `Installer-le-cadrage.cmd` et indiquez le dossier qui contient `Destiny.exe`.
3. Relancez le jeu. Le **vitrage R2** et le **liseré sans rallonge** sont compatibles et facultatifs : ils peuvent rester installés, mais le cadrage n’en a pas besoin.

Pour annuler, quittez le jeu, lancez `Restaurer-le-cadrage.cmd` depuis ce ZIP extrait et indiquez le même dossier du jeu. Gardez le répertoire `.sauvegarde-cadrage-sud-0.7.7` dans le jeu : il contient les sept scripts originaux. Les autres correctifs restent en place. L’installateur vérifie les empreintes des fichiers de la publication Windows 0.7.7 et refuse d’écraser un script différent.

## Ce qui change — et ce qui ne change pas

Les sept `init.lua` d’origine reçoivent un appel à un petit module commun de caméra. Aucune carte `.rsground`, texture, tuile, banque, zone de collision, position de seuil, destination, sauvegarde de partie ou exécutable n’est remplacé. Le cadre ne zoome pas pour cacher le vide ; il ne descend simplement pas plus bas que le seuil. Les plans à caméra explicitement imposée par le jeu conservent leur cadrage.

## Vérification

- `Avant-apres-cadrage-sud.png` compare les bas de fenêtre de jeu dans les sept salles. Même position et mêmes graphismes de chaque côté, seule la caméra est corrigée.
- `Verification.json` détaille les 28 paires jour/aube/crépuscule/nuit et les 7 sorties parcourues au clavier dans chaque état. Après alignement des vues sur la carte, aucun pixel du décor dans la zone commune ne change. Une fenêtre R2 et les trois salles témoins ont des captures identiques.
- Dans les Missions, l’arrivée au marqueur sud, la remontée au clavier, un plan à caméra fixe suivi du retour au suivi normal, le zoom moteur ×2 puis ×1 et la reprise d’une partie de test ont aussi été vérifiés.
- Banc : assemblies officielles 0.7.7 et PowerShell 7 sur Linux. Le fichier `Destiny.exe` n’a pas été exécuté sous Windows lors de la vérification.
