'use strict';
// Node + Playwright. PLAYWRIGHT et CHROME peuvent viser des installations locales.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {chromium}=require(process.env.PLAYWRIGHT || 'playwright');
const base=path.resolve(__dirname,'..');
const file=path.join(base,'Vestiaire-Foulards-et-Rubans.html');
const controls=[]; const passes=(msg)=>{controls.push(msg);console.log('OK · '+msg);};
(async()=>{
 const browser=await chromium.launch({headless:true,...(process.env.CHROME?{executablePath:process.env.CHROME}:{}),args:['--no-sandbox','--disable-dev-shm-usage']});
 const page=await browser.newPage({viewport:{width:1240,height:900},reducedMotion:'reduce'}); const faults=[], requests=[]; page.setDefaultTimeout(7000);
 page.on('pageerror',e=>faults.push(e.message)); page.on('request',rq=>{if (/^https?:/.test(rq.url()))requests.push(rq.url());});
 await page.route('http**',rq=>rq.abort());
 await page.goto(pathToFileURL(file).href);
 await page.waitForFunction(()=>art.size>0 && canvases.every((c,i)=>contexts[i].getImageData(0,0,64,62).data.some(x=>x>0)));
 if(process.argv[2])await page.screenshot({path:process.argv[2],fullPage:true});
 assert.equal(await page.locator('#starter option').count(),86);
 assert.equal(await page.locator('#palette button').count(),10);
 assert.equal(await page.locator('[data-piece]').count(),8); passes('86 choix préchargés, huit accessoires, neuf teintes + Sans accessoire, deux sprites natifs visibles');
 const getHash=async id=>await page.locator('#sprite'+id).evaluate(el=>el.toDataURL());
 const hero=await getHash(0),partner=await getHash(1);
 for (let i=2;i<8;i++) {
  await page.locator(`[data-piece="${i}"]`).click();
  assert.equal(await page.locator('[data-piece][aria-pressed="true"]').count(),1);
  assert.equal(await getHash(1),partner);
 }
 await page.locator('[data-piece="1"]').click();
 await page.waitForFunction(h=>canvases[0].toDataURL()===h,hero);
 passes('Six nouvelles pièces sélectionnables ; un seul accessoire par membre');
 assert.equal(await page.locator('#angles button').count(),8);
 assert.equal(await page.locator('#wear0').innerText(),'Foulard · Garance');
 assert.equal(await page.locator('#wear1').innerText(),'Ruban · Lagon');
 await page.getByRole('button',{name:'Ruban',exact:true}).click();
 await page.waitForFunction(h=>canvases[0].toDataURL()!==h,hero);
 assert.equal(await getHash(1),partner);
 assert.equal(await page.locator('#wear0').innerText(),'Ruban · Garance');
 await page.getByRole('button',{name:'Ivoire',exact:true}).click();
 await page.waitForFunction(h=>canvases[0].toDataURL()!==h,hero);
 assert.equal(await getHash(1),partner);
 await page.locator('.roles').getByRole('button',{name:'Partenaire'}).click();
 assert.equal(await page.locator('#nomCouleur').innerText(),'Lagon');
 await page.getByRole('button',{name:'Sans accessoire',exact:true}).click();
 await page.waitForFunction(h=>canvases[1].toDataURL()!==h,partner);
 assert.equal(await page.locator('#nomCouleur').innerText(),'Sans accessoire');
 passes('Type et teinte indépendants pour les deux membres ; retrait de l’accessoire');
 await page.locator('#recherche').fill('hisui');
 assert.equal(await page.locator('#starter option[value]:not([value=""])').count(),3);
 await page.locator('#starter').selectOption('zorua_1');
 assert.match(await page.locator('#label1').innerText(),/Hisui/);
 await page.locator('#recherche').fill('miaouss');
 assert.equal(await page.locator('#starter option[value="meowth_0"]').count(),1);
 await page.locator('#recherche').fill('introuvable');
 assert.equal(await page.locator('#starter').isDisabled(),true);
 passes('Recherche sans accent, formes régionales conservées, Miaouss trouvé, aucun résultat propre');
 await page.locator('#reset').click();
 for(const d of ['3/4 gauche','Profil gauche','Dos gauche','Dos','Dos droit','Profil droit','3/4 droit','Face']) {
  await page.locator('#versG').click(); assert.equal(await page.locator('#direction').innerText(),d);
 }
 await page.locator('#versD').click(); assert.equal(await page.locator('#direction').innerText(),'3/4 droit');
 await page.locator('#angles').getByRole('button',{name:'Dos',exact:true}).click();
 assert.equal(await page.locator('#direction').innerText(),'Dos');
 assert.match(await page.locator('#style').innerText(),/nœud et le pan/);
 await page.locator('#angles').getByRole('button',{name:'Profil droit',exact:true}).click();
 assert.match(await page.locator('#style').innerText(),/derrière le corps/);
 await page.getByRole('button',{name:'Marche',exact:true}).click();
 let walked=await getHash(0);
 await page.waitForFunction(h=>canvases[0].toDataURL()!==h,walked);
 await page.getByRole('button',{name:'Nuit',exact:true}).click();
 await page.waitForFunction(()=>frames.get(0)?.includes(':nuit:'));
 assert.equal(await page.locator('#sceneTag').innerText(),'NUIT');
 if(process.argv[3])await page.screenshot({path:process.argv[3],fullPage:true});
 passes('Huit angles, images de marche successives, filtres jour/nuit actifs hors ligne');
 await page.locator('#reset').click();
 const count=await page.evaluate(async()=>{
  let count=0;
  const convert=hex=>[...hex.slice(1).matchAll(/../g)].map(m=>parseInt(m[0],16)).concat(255);
  for(const entry of lib.entries) {
   duo[0]={slug:entry.slug,ink:0,piece:0};
   const img=getTex(entry.slug,false);
   if(!img)await art.get(entry.slug+':0').decode();
   for (let mode=0;mode<2;mode++) for(let heading=0;heading<8;heading++) {
    move=mode;dir=heading;
    duo[0].ink=0; paint(start);
    const bare=contexts[0].getImageData(0,0,64,62).data;
    const f=entry.anim[move][dir][0];
    const x=32-Math.floor(entry.width/2)+f[1],y=39-Math.floor(entry.height/2)+f[2];
    for (let k=0;k<8;k++) {
     const colors= k===7 ? [lib.palette[1].c[0],lib.lunettes.c[1],lib.palette[1].c[2],lib.lunettes.c[3]] : lib.palette[1].c;
     const rgba=colors.map(convert);
     duo[0].ink=1;duo[0].piece=k;paint(start);
     const styled=contexts[0].getImageData(0,0,64,62).data;
     const goal=new Uint8ClampedArray(bare);
     const layers=entry.stencils[f[4+k]].slice(0,2);
     for (let layer=0;layer<2;layer++) {
      const runs=atob(layers[layer]);
      for (let p=0;p<runs.length;p+=4) {
       const px=x+runs.charCodeAt(p)-128,py=y+runs.charCodeAt(p+1)-128;
       for(let step=0;step<runs.charCodeAt(p+2);step++) {
        if (px+step<0 || px+step>=64 || py<0 || py>=62) continue;
        const i=(py*64+px+step)*4;
        if (layer || !bare[i+3]) goal.set(rgba[runs.charCodeAt(p+3)-1],i);
       }
      }
     }
     if (styled.every((v,i)=>v===bare[i])) throw new Error(`Accessoire invisible : ${entry.name} ${k}/${dir}/${move}`);
     if (styled.some((v,i)=>v!==goal[i])) throw new Error(`Calques différents : ${entry.name} ${k}/${dir}/${move}`);
     count++;
    }
   }
  }
  return count;
 });
 assert.equal(count,11008);passes('11 008 essais pixel à pixel : huit accessoires, 86 formes, huit angles, deux animations');
 await page.locator('#reset').click();
 for(const width of [320,390,730,1024]){
  await page.setViewportSize({width,height:900});
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,`débordement ${width}`);
 }
 passes('Pas de débordement à 320, 390, 730 ni 1024 px');
 const sandbox=await browser.newPage({viewport:{width:950,height:740},reducedMotion:'reduce'});
 sandbox.on('pageerror',e=>faults.push(e.message)); sandbox.on('request',rq=>{if(/^https?:/.test(rq.url()))requests.push(rq.url());});
 await sandbox.setContent('<iframe sandbox="allow-scripts" width="900" height="730"></iframe>');
 await sandbox.locator('iframe').evaluate((el,html)=>el.srcdoc=html,fs.readFileSync(file,'utf8'));
 const frame=sandbox.frameLocator('iframe'); await frame.locator('#starter option[value="meowth_0"]').waitFor({state:'attached'});
 await frame.locator('#starter').selectOption('meowth_0');
 await frame.getByRole('button',{name:'Saphir',exact:true}).click();
 assert.equal(await frame.locator('#label0').innerText(),'Miaouss');
 assert.equal(await frame.locator('#nomCouleur').innerText(),'Saphir');
 passes('Fonctionne dans le lecteur iframe allow-scripts, sans stockage et sans réseau');
 assert.deepEqual(faults,[]);assert.deepEqual(requests,[]);passes('Zéro erreur JavaScript, zéro requête externe');
 fs.writeFileSync(path.join(base,'Verification-vestiaire.json'),JSON.stringify({statut:'PASS',verifications:controls},null,2)+'\n');
 console.log('PASS · '+controls.length+' groupes de contrôles');
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1);});
