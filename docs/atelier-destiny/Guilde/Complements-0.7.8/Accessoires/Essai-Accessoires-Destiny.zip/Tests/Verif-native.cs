// Banc isolé : compilez ce fichier AVEC les sources de RogueEssence, entrée
// DestinyRubans.VerifNative. Ne pas inclure ce fichier dans la build du jeu.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RogueElements;
using RogueEssence;
using RogueEssence.Content;
using RogueEssence.Ground;
using RogueEssence.Dungeon;

namespace DestinyRubans
{
    sealed class VerifNative : Game
    {
        private readonly GraphicsDeviceManager graphics;
        private readonly string root;
        private readonly string roster;
        private readonly string output;
        private int testedFrames, testedPoses, headCount, headRender, usedSheets, checkedVariants, rendered, dungeonRenders, limited, tails, exposedTails, hiddenTailPixels, rearWithoutBow;
        private SpriteBatch batch;
        private RenderTarget2D target;


        public VerifNative(string root, string roster, string output)
        {
            this.root = Path.GetFullPath(root);
            this.roster = roster;
            this.output = output;
            graphics = new GraphicsDeviceManager(this) { PreferredBackBufferWidth = 320, PreferredBackBufferHeight = 240 };
        }

        public static int Main(string[] args)
        {
            if (args.Length != 3)
            {
                Console.Error.WriteLine("Usage : VerifNative <racine contenant base et game> <roster.tsv> <sortie>");
                return 2;
            }
            try
            {
                CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
                using var game = new VerifNative(args[0], args[1], args[2]);
                game.Run();
                return 0;
            }
            catch (Exception ex) { Console.Error.WriteLine(ex); return 1; }
        }

        protected override void LoadContent()
        {
            Directory.CreateDirectory(output);
            PathMod.InitPathMod(Path.Combine(root, "base", "Banc.dll"));
            DiagManager.InitInstance();
            GraphicsManager.InitParams();
            using var placeholder = new Texture2D(GraphicsDevice, 16, 16);
            BaseSheet.InitBase(GraphicsDevice, placeholder);
            using var spriteBatch = new SpriteBatch(GraphicsDevice);
            batch = spriteBatch;
            using var buffer = new RenderTarget2D(GraphicsDevice, 128, 128);
            target = buffer;
            CheckAll();
            Exit();
        }

        private static readonly DestinyRibbon.Kind[] Styles = { DestinyRibbon.Kind.Ribbon, DestinyRibbon.Kind.Scarf };
        private void CheckAll()
        {
            var monster = new Dictionary<string, int>();
            var index = new CharaIndexNode { Nodes = new Dictionary<int, CharaIndexNode>() };
            foreach (string layer in new[] { "base", "game" })
            {
                string m = Path.Combine(root, layer, "Data", "Monster", "index.idx");
                if (File.Exists(m))
                    foreach (var kv in (JObject)JObject.Parse(File.ReadAllText(m))["Object"])
                        if (kv.Value is JObject value && value["SortOrder"] != null) monster[kv.Key] = (int)value["SortOrder"];
                string c = Path.Combine(root, layer, "Content", "Chara", "index.idx");
                using var reader = new BinaryReader(File.OpenRead(c));
                foreach (var kv in CharaIndexNode.Load(reader).Nodes) index.Nodes[kv.Key] = kv.Value;
            }

            var entries = new List<object>();
            var landmarks = new Dictionary<string, int[][]>();
            var seen = new HashSet<(string, int)>();
            var cuts = new HashSet<DestinyRibbon.Fit>();
            var referenceSpecies = new HashSet<string>(new[] { "pikachu_0", "vulpix_1", "growlithe_1", "rowlet_0", "snom_0", "beldum_0", "cosmog_0", "applin_0", "dratini_0", "wooper_1" });
            foreach (string line in File.ReadLines(roster))
            {
                string[] s = line.Split('\t');
                int form = Int32.Parse(s[1]), gen = Int32.Parse(s[3]);
                string name = s[2];
                Require(seen.Add((s[0], form)), "doublon " + s[0]);
                var fit = DestinyRibbon.ReadFit(s[4]); cuts.Add(fit);
                var seams = DestinyRibbon.ReadSeams(s.Length > 5 ? s[5] : "");
                int dex = monster[s[0]];
                var fallback = GraphicsManager.GetFallbackForm(index, new CharID(dex, form, 0, 0));
                var checkedIds = new HashSet<CharID>();
                for (int skin = 0; skin < 3; skin++)
                    for (int gender = 0; gender < 3; gender++)
                    {
                        var id = GraphicsManager.GetFallbackForm(index, new CharID(dex, form, skin, gender));
                        Require(id.Species == dex && (id.Form == form || (form == 0 && id.Form == -1)), "Repli espèce/forme : " + name + " / " + skin + " / " + gender);
                        checkedVariants++;
                        if (!checkedIds.Add(id)) continue;
                        using var sheet = ReadSheet(index, id);
                        int idle = GraphicsManager.IdleAction, walk = GraphicsManager.WalkAction;
                        usedSheets++;
                        bool normal = id == fallback;
                        var pixels = BaseSheet.GetData(sheet);
                        var frameTiles = new Dictionary<(int, int, bool), int>();
                        var sequences = new List<object>();
                        var stencils = new List<object>();
                        var patternIndex = new Dictionary<DestinyRibbon.Pose, int>();
                        // Le banc teste les clés uniques du cache une seule fois par feuille.
                        var checkedPoses = new HashSet<DestinyRibbon.Pose>();
                        foreach (int action in new[] { idle, walk })
                        {
                            int reference = sheet.GetReferencedAnimIndex(action);
                            Require(reference >= 0, "Animation absente " + name + ":" + action);
                            var choreo = new List<int[][]>();
                            for (int d = 0; d < 8; d++)
                            {
                                var dir = (Dir8)d;
                                List<CharAnimFrame> seq = sheet.AnimData[reference].SeqAtDir(dir).Frames;
                                Require(seq.Count > 0, "Séquence vide " + name + ":" + action + ":" + d);
                                int prior = 0;
                                var frames = new List<int[]>();
                                for (int f = 0; f < seq.Count; f++)
                                {
                                    CharAnimFrame frame = seq[f];
                                    var r = sheet.GetDestinyRibbonPose(frame, dir, fit, Styles[0], seams?[d] ?? Loc.Zero);
                                    var c = sheet.GetDestinyRibbonPose(frame, dir, fit, Styles[1], seams?[d] ?? Loc.Zero);
                                    var headStyles = new[] { DestinyRibbon.Kind.Cowboy, DestinyRibbon.Kind.Cap, DestinyRibbon.Kind.TopHat, DestinyRibbon.Kind.Beret, DestinyRibbon.Kind.Beanie, DestinyRibbon.Kind.Sunglasses };
                                    var headPoses = headStyles.Select(kind => sheet.GetDestinyRibbonPose(frame, dir, fit, kind, Loc.Zero)).ToArray();
                                    Require(headPoses.All(p => p != null && p.Front.Length + p.Behind.Length > 0), "Accessoire de tête invisible " + name + ":" + d);
                                    foreach (var headPose in headPoses)
                                    {
                                        headCount++;
                                        int ax = headPose.Anchor.X, ay = headPose.Anchor.Y;
                                        Require((uint)ax < (uint)sheet.TileWidth && (uint)ay < (uint)sheet.TileHeight &&
                                            pixels[(frame.Frame.Y*sheet.TileHeight+ay)*sheet.Width+frame.Frame.X*sheet.TileWidth+(frame.Flip?sheet.TileWidth-1-ax:ax)].A >= 64,
                                            "Ancrage de tête hors silhouette : " + name + "/" + d);
                                    }
                                    Require(r != null && c != null, "Attache absente " + name + " : " + action + "/" + d + "/" + f);
                                    Require(frame.EndTime > prior, "Durée nulle " + name);
                                    Require(r.Front.Length > 0 && c.Front.Length > 0, "Bande invisible " + name);
                                    foreach (var kind in Styles)
                                    {
                                        var pose = kind == Styles[0] ? r : c;
                                        testedPoses++;
                                        if (!checkedPoses.Add(pose)) continue;
                                        CheckGeometry(sheet,pixels,frame,pose,kind,fit,d,name);
                                    }
                                    testedFrames++;
                                    if (normal)
                                    {
                                        var tile = (frame.Frame.X, frame.Frame.Y, frame.Flip);
                                        if (!frameTiles.TryGetValue(tile, out int tileId))
                                        {
                                            tileId = frameTiles.Count;
                                            frameTiles.Add(tile, tileId);
                                        }
                                        Loc offset = sheet.GetSheetOffset(action, action == walk, dir, _ => f);
                                        frames.Add(new[] {tileId, offset.X, offset.Y, frame.EndTime - prior, Shape(r), Shape(c)}.Concat(headPoses.Select(Shape)).ToArray());
                                    }
                                    prior = frame.EndTime;
                                }
                                if (normal) choreo.Add(frames.ToArray());
                            }
                            if (normal) sequences.Add(choreo);
                        }
                        if (!normal) continue;
                        string slug = s[0] + "_" + form;
                        WriteTileExport(sheet, frameTiles, pixels, Path.Combine(output, slug + ".png"));
                        entries.Add(new { slug, species = s[0], form, name, generation = gen, cut = s[4],
                            width = sheet.TileWidth, height = sheet.TileHeight, columns = 8, tiles = frameTiles.Count, anim = sequences, stencils });
                        var referenceFrames = sheet.AnimData[sheet.GetReferencedAnimIndex(idle)];
                        landmarks[slug] = Enumerable.Range(0,8).Select(d => {
                            CharAnimFrame fr = referenceFrames.SeqAtDir((Dir8)d).Frames[0];
                            var offsets = sheet.OffsetData[fr.Frame.X + fr.Frame.Y * (sheet.Width / sheet.TileWidth)];
                            var head = fr.Flip ? offsets.HeadFlip : offsets.Head;
                            var center = fr.Flip ? offsets.CenterFlip : offsets.Center;
                            return new[] { head.X + sheet.TileWidth/2, head.Y + sheet.TileHeight/2,
                                center.X + sheet.TileWidth/2, center.Y + sheet.TileHeight/2 };
                        }).ToArray();
                        if (referenceSpecies.Contains(slug)) CheckRenders(sheet, name, fit, seams);

                        int Shape(DestinyRibbon.Pose pose)
                        {
                            if (!patternIndex.TryGetValue(pose, out int n))
                            {
                                n = stencils.Count; patternIndex.Add(pose,n);
                                stencils.Add(new object[] { Export(pose.Behind), Export(pose.Front), pose.Knot ? 1 : 0, pose.Limited ? 1 : 0, pose.Anchor.X, pose.Anchor.Y });
                            }
                            return n;
                        }
                    }
                if (entries.Count % 16 == 0) Console.WriteLine(entries.Count + " formes vérifiées");
            }
            Require(entries.Count == 86 && cuts.Count == 15, "Roster ou profils inattendus");
            Require(exposedTails > 0 && hiddenTailPixels > 0 && rearWithoutBow > 0 && limited > 0, "Occultation ou projection non exercée");
            var palette = DestinyRibbon.Colors.Select(shade => new { id = shade.Key, n = shade.Name,
                c = shade.Ink.Select(Hex), nuit = shade.Ink.Select(c => Hex(CharSheet.DestinyNightGrade(c))) }).ToArray();
            File.WriteAllText(Path.Combine(output, "Reperes.json"), JsonConvert.SerializeObject(landmarks, Formatting.None));
            File.WriteAllText(Path.Combine(output, "Sprites.json"), JsonConvert.SerializeObject(new { entries, palette, lunettes = new { c = new [] { "#14141D", "#141822", "#617084", "#AFC0CC" }, nuit = new [] { new Color(20,20,29), new Color(20,24,34), new Color(97,112,132), new Color(175,192,204) }.Select(c => Hex(CharSheet.DestinyNightGrade(c))).ToArray() } }, Formatting.None));
            File.WriteAllText(Path.Combine(output, "Verification-rendu.json"), JsonConvert.SerializeObject(new {
                resultat = "PASS", formes = entries.Count, profils = cuts.Count, variantes_testees = checkedVariants, feuilles_distinctes = usedSheets,
                images_sprite_visitees = testedFrames, poses_ruban_ou_foulard = testedPoses, poses_accessoires_de_tete = headCount, rendus_accessoires_de_tete = headRender,
                rubans_sans_noeud_au_dos = rearWithoutBow, poses_cote_lointain = limited,
                pans_de_profil = tails, pans_emergeant_du_profil = exposedTails, pixels_de_pan_occultes = hiddenTailPixels,
                rendus_fna = rendered, rendus_donjon = dungeonRenders,
                note = "Les poses sont comptées sur toutes les séquences de marche et de repos des feuilles natives distinctes. Les compteurs de projection concernent des positions uniques par feuille.",
                verifications = new[] { "Les attaches restent sur la silhouette, angle par angle", "Ruban : pas de nœud frontal au dos", "Foulard : pan projeté vers l’arrière, occulté par le corps", "Attache latérale : pli visible seulement du côté anatomique porteur", "Aucune grappe extérieure de tissu sans attache", "Calques natifs comparés pixel à pixel, au sol, de nuit et en mouvement de donjon (huit types)" }
            }, Formatting.Indented) + "\n");
            Console.WriteLine($"PASS · {entries.Count} formes · {cuts.Count} profils · {checkedVariants} variantes · {testedPoses} poses et {rendered} rendus GPU");
        }

        private static string Export(DestinyRibbon.Run[] runs)
        {
            byte[] data = new byte[runs.Length * 4]; int i = 0;
            foreach (var r in runs)
            {
                Require(r.X >= -128 && r.X < 128 && r.Y >= -128 && r.Y < 128 && r.Width <= 255, "Coordonnées d’export hors limites");
                data[i++] = (byte)(r.X + 128); data[i++] = (byte)(r.Y + 128); data[i++] = (byte)r.Width; data[i++] = r.Ink;
            }
            return Convert.ToBase64String(data);
        }

        private void CheckGeometry(CharSheet sheet,Color[] pixels,CharAnimFrame frame,DestinyRibbon.Pose p,
            DestinyRibbon.Kind kind,DestinyRibbon.Fit fit,int d,string name)
        {
            int w = sheet.TileWidth, h = sheet.TileHeight;
            int yaw = Math.Min(d,8-d);
            bool side = fit == DestinyRibbon.Fit.Wing || fit == DestinyRibbon.Fit.Flank;
            bool far = side && d >= 1 && d <= 3;
            bool scarf = kind == DestinyRibbon.Kind.Scarf;
            Require(p.Limited == far && p.Knot == (!far && (scarf ? yaw >= 3 : yaw <= 2)), "Projection incorrecte " + name + " / " + d);
            if (far) limited++;
            if (!scarf && yaw >= 3) rearWithoutBow++;
            Require(Solid(p.Anchor.X,p.Anchor.Y), "Nœud/attache hors silhouette " + name);
            var fabric = new HashSet<Loc>();
            var grounded = new Queue<Loc>();
            bool exposed = false;
            foreach (var lr in new[] {p.Front,p.Behind})
                foreach (var r in lr)
                {
                    Require(r.Width > 0 && r.Ink >= 1 && r.Ink <= 4, "Pixel tissu invalide");
                    for (int x = r.X; x < r.X + r.Width; x++)
                    {
                        if (lr == p.Behind)
                        {
                            Require(scarf && yaw == 2 && !far && (x-p.Anchor.X)*(d == 2 ? 1 : -1) >= 1, "Pan avant ou sur côté invisible " + name);
                            if (!Solid(x,r.Y)) exposed=true; else hiddenTailPixels++;
                        }
                        // Les parties de tissu sous le corps comptent comme attaches.
                        var q = new Loc(x,r.Y);
                        if (fabric.Add(q) && Solid(x,r.Y)) grounded.Enqueue(q);
                    }
                }
            while (grounded.Count > 0)
            {
                var at=grounded.Dequeue(); fabric.Remove(at);
                for(int dy=-1;dy<=1;dy++) for(int dx=-1;dx<=1;dx++)
                {
                    var n=at+new Loc(dx,dy);
                    if (fabric.Remove(n)) grounded.Enqueue(n);
                }
            }
            Require(fabric.Count == 0, "Tissu flottant " + name);
            if (p.Behind.Length > 0) tails++;
            if (exposed) exposedTails++;

            bool Solid(int x,int y) => (uint)x < (uint)w && (uint)y < (uint)h
                && pixels[(frame.Frame.Y*h+y)*sheet.Width+frame.Frame.X*w+(frame.Flip?w-1-x:x)].A>=64;
        }

        private CharSheet ReadSheet(CharaIndexNode index, CharID id)
        {
            string f = Path.Combine("Content", "Chara", id.Species + ".chara");
            string complete = Path.Combine(root, "game", f);
            if (!File.Exists(complete)) complete = Path.Combine(root, "base", f);
            using var reader = new BinaryReader(File.OpenRead(complete));
            long pos = index.GetPosition(id.Species, id.Form, id.Skin, id.Gender);
            Require(pos > 0 && pos < reader.BaseStream.Length, "Index de sprite invalide : " + complete);
            reader.BaseStream.Position = pos;
            return CharSheet.Load(reader);
        }

        private void WriteTileExport(CharSheet sheet, Dictionary<(int, int, bool), int> tiles, Color[] pixels, string filename)
        {
            int w = sheet.TileWidth, h = sheet.TileHeight, width = w * 8, height = h * ((tiles.Count + 7) / 8);
            Color[] data = new Color[width * height];
            foreach (var kv in tiles)
            {
                var (fx, fy, mirror) = kv.Key;
                int left = (kv.Value % 8) * w;
                int top = (kv.Value / 8) * h;
                for (int y = 0; y < h; y++)
                    for (int x = 0; x < w; x++)
                        data[(top + y) * width + left + x] = pixels[(fy * h + y) * sheet.Width + fx * w + (mirror ? w - 1 - x : x)];
            }
            using var tex = new Texture2D(GraphicsDevice, width, height);
            tex.SetData(data);
            using var file = File.Create(filename);
            tex.SaveAsPng(file, width, height);
        }

        private void CheckRenders(CharSheet sheet, string name, DestinyRibbon.Fit cut, Loc[] seams)
        {
            var cam = new Loc(3,-2);
            var map = new Loc(58,52);
            const int height = 7;
            for (int move=0; move<=1; move++)
                for (int d=0;d<8;d++)
                {
                    Dir8 dir=(Dir8)d;
                    int type=move==0?GraphicsManager.IdleAction:GraphicsManager.WalkAction;
                    var frames = sheet.AnimData[sheet.GetReferencedAnimIndex(type)].SeqAtDir(dir).Frames;
                    var time = FrameTick.FromFrames(move==1 && frames.Count>1 ? frames[0].EndTime : 0);
                    GroundAction action = move==0 ? new IdleGroundAction(map,height,dir) { Override=type } : new WalkGroundAction(map,height,dir,false,1,time);
                    action.ActionTime=time;
                    action.UpdateFrame();
                    var frame=frames[action.FrameMethod(frames)];
                    Loc origin=action.GetDrawLoc(cam,sheet)+sheet.GetSheetOffset(type,move==1,dir,action.FrameMethod)-new Loc(0,height);
                    var night=sheet.GetDestinyNightCopy();
                    Color[] bare=Render(()=>action.Draw(batch,cam,sheet,Color.White));
                    Color[] dark=Render(()=>action.Draw(batch,cam,night,Color.White));
                    foreach(var kind in (DestinyRibbon.Kind[])Enum.GetValues(typeof(DestinyRibbon.Kind)))
                    {
                        var wear=new DestinyRibbon.Wear(1+(d+move*2+(int)kind*3)%(DestinyRibbon.Colors.Length-1),cut,kind,seams);
                        var pose=sheet.GetDestinyRibbonPose(frame,dir,cut,kind,wear.Seam(dir));
                        var actual=Render(()=>action.Draw(batch,cam,sheet,Color.White,wear));
                        Compare(bare,actual,pose,origin,wear,false,"Sol "+name);
                        var dim=Render(()=>action.Draw(batch,cam,night,Color.White,wear));
                        Compare(dark,dim,pose,origin,wear,true,"Nuit "+name);
                        if ((int)kind >= 2) headRender += 2;
                    }
                    action.UpdateDrawEffects(new HashSet<DrawEffect> { DrawEffect.Absent });
                    Require(Render(()=>action.Draw(batch,cam,sheet,Color.White,new DestinyRibbon.Wear(3,cut,Styles[1],seams))).All(p=>p.A==0),"Tissu sur Pokémon invisible");
                    // Rendu du chemin d'action de donjon, avec la translation et le miroir du moteur.
                    var tile=new Loc(2,2);
                    CharAnimation anim=move==0?new CharAnimIdle(tile,dir){ Override=type }:new CharAnimWalk(tile,tile+dir.GetLoc(),dir,1);
                    anim.Update(FrameTick.FromFrames(move==0?0:7),default,0);
                    var combat=new EmptyCharAction(anim); combat.UpdateFrame();
                    combat.GetCurrentSprite(sheet,out int ac,out _,out int fn);
                    var combatFrame=sheet.AnimData[sheet.GetReferencedAnimIndex(ac)].SeqAtDir(dir).Frames[fn];
                    var cpos=combat.GetDrawLoc(cam,sheet)+combat.GetSheetOffset(sheet);
                    var dbare=Render(()=>combat.Draw(batch,cam,sheet));
                    foreach(var k in (DestinyRibbon.Kind[])Enum.GetValues(typeof(DestinyRibbon.Kind)))
                    {
                        var dr=new DestinyRibbon.Wear(5,cut,k,seams);
                        Compare(dbare,Render(()=>combat.Draw(batch,cam,sheet,dr)),sheet.GetDestinyRibbonPose(combatFrame,dir,cut,k,dr.Seam(dir)),cpos,dr,false,"Donjon "+name);
                    }
                    dungeonRenders+=9;
                    headRender += 6;
                }
        }

        private static void Compare(Color[] bare,Color[] actual,DestinyRibbon.Pose shape,Loc origin,DestinyRibbon.Wear dress,bool night,string what)
        {
            Color[] expect=(Color[])bare.Clone();
            var ink=DestinyRibbon.Colors[dress.Ink].Ink;
            if (dress.Style == DestinyRibbon.Kind.Sunglasses)
                ink = new [] { ink[0], new Color(20,24,34), ink[2], new Color(175,192,204) };
            foreach(var lr in new[] {shape.Behind,shape.Front})
                foreach(var run in lr)
                    for(int x=run.X;x<run.X+run.Width;x++)
                    {
                        int px=origin.X+x,py=origin.Y+run.Y;
                        Require(px>=0 && py>=0 && px<128 && py<128,what+" : hors cible");
                        int n=py*128+px;
                        Color c=night?CharSheet.DestinyNightGrade(ink[run.Ink-1]):ink[run.Ink-1];
                        if (lr==shape.Front) expect[n]=c;
                        else if (bare[n].A==0) expect[n]=c;
                        else if (bare[n].A!=255)
                        {
                            int a=255-bare[n].A;
                            expect[n]=new Color(Math.Min(255,bare[n].R+c.R*a/255),Math.Min(255,bare[n].G+c.G*a/255),Math.Min(255,bare[n].B+c.B*a/255),255);
                        }
                    }
            Require(!bare.SequenceEqual(actual), what+" : accessoire invisible");
            for(int n=0;n<expect.Length;n++) Require(Near(expect[n],actual[n]), what+" : superposition différente, pixel "+n);
        }

        private Color[] Render(Action draw)
        {
            GraphicsDevice.SetRenderTarget(target);
            GraphicsDevice.Clear(Color.Transparent);
            batch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp, null, null, null, Matrix.Identity);
            draw();
            batch.End();
            GraphicsDevice.SetRenderTarget(null);
            Color[] data = new Color[128 * 128];
            target.GetData(data);
            rendered++;
            return data;
        }

        private static bool Near(Color p, Color q) => Math.Abs(p.R - q.R) <= 1 && Math.Abs(p.G - q.G) <= 1 && Math.Abs(p.B - q.B) <= 1 && Math.Abs(p.A - q.A) <= 1;
        private static string Hex(Color c) => $"#{c.R:X2}{c.G:X2}{c.B:X2}";
        private static void Require(bool cond, string message) { if (!cond) throw new Exception(message); }
    }
}
