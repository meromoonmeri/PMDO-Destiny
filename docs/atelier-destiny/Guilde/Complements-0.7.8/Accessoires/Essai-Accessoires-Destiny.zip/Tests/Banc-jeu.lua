-- Banc isolé, jamais incorporé au patch à installer.
local M = {}
local time,last = 0,''
local cut = require 'destiny.guilde_destiny_decors'
local chars = require 'destiny.equipe_scene'
local directions = {
  face = Direction.Down, faceg = Direction.DownLeft, profilg = Direction.Left,
  dosg = Direction.UpLeft, dos = Direction.Up, dosd = Direction.UpRight,
  profild = Direction.Right, faced = Direction.DownRight,
}

local function log(token, room, detail)
  local f = assert(io.open('banc-rubans-reponse.tmp','w'))
  f:write(token .. '\n' .. room .. '\n' .. tostring(detail) .. '\n')
  local team = _DATA.Save.ActiveTeam
  for i=0,team.Players.Count-1 do
    local p = team.Players[i]
    f:write(table.concat({p.BaseForm.Species,tostring(p.BaseForm.Form),p.DestinyRibbonColor or '-',p.DestinyRibbonStyle or '-',p.EquippedItem.ID ~= '' and p.EquippedItem.ID or '-'},'\t')..'\n')
  end
  f:close()
  os.rename('banc-rubans-reponse.tmp','banc-rubans-reponse.txt')
end

function M.Update(map, room)
  time = (time + 1) % 10
  if time ~= 0 then return end
  local f = io.open('banc-rubans-commande.txt','r')
  if f == nil then return end
  local request = f:read('*a'); f:close()
  if request == nil or request == last then return end
  local token, command = request:match('^(%w+)%s+(%w+)')
  if token == nil then return end
  last = request
  local ok, detail = pcall(function()
    local team = _DATA.Save.ActiveTeam
    if command == 'duo' or command == 'kaiminus' then
      local p = CH('PLAYER').MapLoc
      team.Players:Clear()
      local function player(spec,form,gender,name,role)
        local id = RogueEssence.Dungeon.MonsterID(spec, form, 'normal', gender)
        local intrinsic = _DATA:GetMonster(spec).Forms[form].Intrinsic1
        local ch = team:CreatePlayer(_DATA.Save.Rand, id, 8, intrinsic, 0)
        ch.IsFounder, ch.IsPartner = true, true
        LTBL(ch).Importance = role
        GAME:SetCharacterNickname(ch,name)
        team.Players:Add(ch)
        return ch
      end
      local hero = command == 'kaiminus' and player('totodile', 0, Gender.Male, 'Kaiminus', 'Hero') or player('pikachu', 0, Gender.Male, 'Pikachu', 'Hero')
      hero.EquippedItem = RogueEssence.Dungeon.InvItem('berry_oran')
      player('vulpix', 1, Gender.Female, 'Goupix', 'Partner')
      team.LeaderIndex = 0
      GROUND:RefreshPlayer()
      local partner = chars.Partenaire(p.X+25,p.Y,Direction.Down)
      cut.ForcerAmbiance(map,room,'jour')
    elseif command == 'place' then
      local p = CH('PLAYER'); local at = p.MapLoc
      chars.Partenaire(at.X+28,at.Y,Direction.Down)
    elseif directions[command] ~= nil then
      local p = CH('PLAYER'); local partner = CH('Teammate1')
      p.Direction = directions[command]
      if partner ~= nil then partner.Direction = directions[command] end
      return command .. ' ' .. tostring(p.Direction)
    elseif command == 'actors' then
      local res = {}
      for _, key in ipairs({'PLAYER','Teammate1'}) do
        local a = CH(key)
        if a ~= nil then
          local d = a.Data
          table.insert(res, key .. ':' .. tostring(d:GetType().FullName) .. ':' .. tostring(d.Discriminator) .. ':' .. tostring(d.OriginalUUID) .. ':' .. tostring(d.OriginalTeam) .. ':' .. tostring(d.DestinyRibbonColor) .. ':' .. tostring(d.DestinyRibbonStyle))
        end
      end
      for i=0,team.Players.Count-1 do
        local d=team.Players[i]
        table.insert(res, 'team'..i..':'..tostring(d:GetType().FullName)..':'..tostring(d.Discriminator)..':'..tostring(d.OriginalUUID)..':'..tostring(d.OriginalTeam)..':'..tostring(d.DestinyRibbonColor)..':'..tostring(d.DestinyRibbonStyle))
      end
      return table.concat(res, '|')
    elseif command == 'stat' then
      local p = CH('PLAYER')
      return 'stat ' .. p.MapLoc.X .. ' ' .. p.MapLoc.Y .. ' ' .. tostring(p.Direction)
    elseif command == 'save' then
      _DATA:SaveMainGameState()
    elseif command == 'jour' or command == 'nuit' then
      cut.ForcerAmbiance(map,room,command)
    elseif command == 'walk' then
      local p = CH('PLAYER'); local x,y = p.MapLoc.X,p.MapLoc.Y
      TASK:BranchCoroutine(function()
        GROUND:MoveToPosition(p,x-32,y,false,1)
        GROUND:MoveToPosition(p,x,y,false,1)
      end)
    else
      error('Commande de test inconnue : ' .. tostring(command))
    end
    return command
  end)
  log(token,room,ok and detail or ('FAIL '..tostring(detail)))
end
return M
