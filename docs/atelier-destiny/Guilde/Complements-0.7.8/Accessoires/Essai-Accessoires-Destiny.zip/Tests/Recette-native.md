# Recette de la version d’essai accessoires

## Roster et patch

`Provenance-Banc.json` indique la révision et les identifiants Git des banques de sprites et des fiches utilisées. Le banc doit conserver `base/` et `game/` séparés, avec priorité à `game/`, ainsi que `base/Base/GFXParams.xml` de la même révision.

Depuis le kit : `lua5.4 Tests/Lister-starters.lua <copie-originale>/game/Data/Script Sources/game/Data/Script > roster.tsv`. Les six colonnes sont espèce, forme, nom, génération, profil et coutures. `python Sources/Construire-patch.py <dépôt> <révision> <dossier-test-inexistant>` extrait les fichiers visés, produit le patch complet et vérifie son aller-retour. Il n’écrit pas dans le dépôt d’origine.

## Banc FNA et HTML

Avec .NET 8, Roslyn et les dépendances FNA : consulter `Tests/Compiler-banc.py --help`, puis utiliser la superposition de sources moteur du patch. Exécuter sous un affichage : `dotnet <banc>/RogueEssence.dll <banques> roster.tsv <sortie>`.

Le contrôle visite 86 formes, 15 profils, 774 variantes de feuilles, 56 336 poses ruban/foulard et 169 008 poses d’accessoires de tête. Il teste 4 480 rendus FNA, dont 1 440 rendus d’actions de donjon, par comparaison des calques. Un ancrage sur une silhouette ne prouve pas qu’il se trouve sur les yeux : les coiffes et lunettes restent à contrôler visuellement espèce par espèce.

`python Sources/Construire-vestiaire.py <sortie>` reconstruit le HTML depuis les exports du banc. `node Tests/Verifier-vestiaire.cjs` effectue les tests navigateur ; `PLAYWRIGHT` et `CHROME` peuvent viser des installations locales. Les 11 008 comparaisons HTML couvrent les huit accessoires, 86 formes, huit angles, deux animations, sur une image de chaque séquence. Elles ne sont pas une validation visuelle de toutes les images de chaque séquence.

## Essai en jeu isolé

Sur une copie Destiny 0.7.7, moteur compilé sur la révision de référence + patch, Linux/.NET 8/FNA, avec dossiers `CONFIG`, `LOG` et `SAVE` isolés. Le témoin initial R2 contenait Pikachu et Goupix d’Alola, deux rubans et une Baie Oran. Le vrai menu a servi à essayer le chapeau cow-boy et les lunettes, la rotation, l’annulation, la substitution, le retrait, la sauvegarde et la reprise dans un nouveau processus.

La fixture `Banc-jeu.lua`, appelée depuis le `Update` de `guilde_destiny_refectoire`, est strictement réservée au banc. Elle lit `banc-rubans-commande.txt` (`ID commande`) et émet une réponse. `kaiminus` crée un duo de test, `actors` relève équipe et acteurs visibles, `face`/angles, `jour`, `nuit`, `walk`, `stat` et `save` aident à observer l’état. Kaiminus a été essayé avec ruban, foulard et chapeau ; la sauvegarde du chapeau a été reprise, puis remplacée par des lunettes. La version finale, avec retouche des lunettes, a repris cette sauvegarde. Les versions successives des essais sont identifiées dans `Verification-integration.json`.

Ne pas distribuer les sauvegardes de test ni intégrer la fixture. Les rendus d’actions ne sont pas une traversée complète de donjon. Aucun build Windows ni installation joueur n’a été effectué.
