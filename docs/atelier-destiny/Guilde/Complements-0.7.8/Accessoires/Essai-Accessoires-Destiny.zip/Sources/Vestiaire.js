'use strict';
const lib = JSON.parse(document.getElementById('banque').textContent);
const bySlug = new Map(lib.entries.map(row => [row.slug, row]));
const $ = id => document.getElementById(id);
const canvases = [$('sprite0'), $('sprite1')];
const contexts = canvases.map(c => c.getContext('2d', {alpha:true}));
const frames = new Map();
const names = ['Face', '3/4 gauche', 'Profil gauche', 'Dos gauche', 'Dos', 'Dos droit', 'Profil droit', '3/4 droit'];
const defaultDuo = () => [{slug:'pikachu_0', ink:1, piece:1}, {slug:'vulpix_1', ink:4, piece:0}];
const pieces = ['Ruban', 'Foulard', 'Cow-boy', 'Casquette', 'Haut-de-forme', 'Béret', 'Bonnet', 'Lunettes de soleil'];
const fittings = {kaiminus:'Col court ajusté',debout:'Col', cou_court:'Col court', quadrupede:'Gorge et nuque', criniere:'Sous la crinière', plumes:'Sous le plumage', aile:'Attache à l’aile', long:'Cou étroit', flanc:'Attache au flanc', carapace:'Lien de carapace', coque_metal:'Lien de coque', tronc_bas:'Attache au corps', nuage:'Bande de nuage', pomme:'Bande autour du fruit', branchies:'Sous les branchies'};
const cacheStencils = new WeakMap();
let duo = defaultDuo(), active = 0, dir = 0, move = 0, light = 'jour', start = performance.now();
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
let imageStillNeeded = false;
const art = new Map();
const normalise = s => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[’']/g,' ');
const press = (list, match) => list.forEach(el => el.setAttribute('aria-pressed', String(match(el))));
const buttons = {
  actor: [...document.querySelectorAll('[data-personnage]')],
  mode: [...document.querySelectorAll('button[data-mode]')],
  light: [...document.querySelectorAll('button[data-lumiere]')],
  piece: [...document.querySelectorAll('button[data-piece]')],
  angles: [],
};
function getTex(slug, night) {
  const key = `${slug}:${+night}`;
  if (!art.has(key)) {
    const img = new Image(); img.decoding = 'async';
    img.onload = () => { frames.clear(); paint(performance.now()); };
    img.src = bySlug.get(slug).img[night ? 1 : 0]; art.set(key,img);
  }
  const img = art.get(key);
  if (!img.complete || !img.naturalWidth) { imageStillNeeded = true; return null; }
  return img;
}
function bands(stencil) {
  if (!cacheStencils.has(stencil)) cacheStencils.set(stencil,stencil.slice(0,2).map(atob));
  return cacheStencils.get(stencil);
}
function stamp(ctx, palette, data, px, py) {
  for (let i=0;i<data.length;i+=4) {
    ctx.fillStyle=palette[data.charCodeAt(i+3)-1];
    ctx.fillRect(px+data.charCodeAt(i)-128,py+data.charCodeAt(i+1)-128,data.charCodeAt(i+2),1);
  }
}
function paint(ts) {
  imageStillNeeded = false;
  const night = light === 'nuit';
  duo.forEach((member, n) => {
    const s = bySlug.get(member.slug), ctx = contexts[n], image = getTex(member.slug, night);
    if (!image) { ctx.clearRect(0,0,64,62); return; }
    const seq = s.anim[move][dir];
    const duration = seq.reduce((a,f)=>a+f[3],0);
    let tick = (reduced.matches && move===0) ? 0 : Math.floor((ts-start)*.06) % duration;
    let f = seq[0];
    for (const next of seq) { if (tick < next[3]) { f = next; break; } tick -= next[3]; }
    const key = `${s.slug}:${member.ink}:${member.piece}:${dir}:${move}:${light}:${f.join(',')}`;
    if (frames.get(n) === key) return;
    frames.set(n,key);
    const [tile,dx,dy] = f;
    const x = 32 - Math.floor(s.width/2) + dx;
    const y = 39 - Math.floor(s.height/2) + dy;
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0,0,64,62);
    const palette=member.ink && (member.piece===7 ? [lib.palette[member.ink][night?'nuit':'c'][0],lib.lunettes[night?'nuit':'c'][1],lib.palette[member.ink][night?'nuit':'c'][2],lib.lunettes[night?'nuit':'c'][3]] : lib.palette[member.ink][night?'nuit':'c']);
    const stencil=palette && bands(s.stencils[f[4+member.piece]]);
    if (stencil) stamp(ctx,palette,stencil[0],x,y);
    ctx.drawImage(image,(tile%s.columns)*s.width,Math.floor(tile/s.columns)*s.height,s.width,s.height,x,y,s.width,s.height);
    if (stencil) stamp(ctx,palette,stencil[1],x,y);
  });
}
let clock=0;
function tick(time) {
  clock = 0; paint(time);
  if (!document.hidden && (!reduced.matches || move === 1 || imageStillNeeded)) clock = requestAnimationFrame(tick);
}
function redraw() { if (!clock) clock=requestAnimationFrame(tick); }
function resetClock(){ start=performance.now(); frames.clear(); redraw(); }
document.addEventListener('visibilitychange',()=> { if (!document.hidden) redraw(); });
reduced.addEventListener('change',redraw);
function swatch(color) {
  if (!color.c.length) return `<svg viewBox="0 0 9 8" aria-hidden="true"><circle cx="4.5" cy="3.9" r="2.3" fill="none" stroke="#9788ac" stroke-width=".55"/><path d="M3 5.5 6 2.3" stroke="#9788ac" stroke-width=".6"/></svg>`;
  const pixels=['11.....11','143...341','.2344321.','..11311..','...3.2...','..31.21..'].map((row,y)=>[...row].map((digit,x)=>digit==='.'?'':`<rect x="${x}" y="${y}" width="1" height="1" fill="${color.c[Number(digit)-1]}"/>`).join('')).join('');
  return `<svg viewBox="0 0 9 8" aria-hidden="true">${pixels}</svg>`;
}
lib.palette.forEach((p,i)=>{
  const b=document.createElement('button'); b.type='button'; b.className='swatch'; b.dataset.encre=i;
  b.title=p.n; b.setAttribute('aria-label',p.n); b.innerHTML=swatch(p);
  const label=document.createElement('span'); label.textContent=i ? p.n.replace('Rose nacré','Rose') : 'Sans'; b.append(label);
  b.addEventListener('click',()=>{ duo[active].ink=i; sync(false); }); $('palette').append(b);
});
function writeOptions() {
  const q=normalise($('recherche').value.trim());
  const list=lib.entries.filter(s=>normalise(`${s.name} ${s.species} gen ${s.generation}`).includes(q));
  const select=$('starter'); const member=duo[active]; select.replaceChildren();
  if (!list.some(s=>s.slug===member.slug)) {
    let hint=new Option(list.length ? 'Choisir un résultat…':'Aucun résultat',''); hint.disabled=true; hint.selected=true; select.add(hint);
  }
  list.forEach(s=>select.add(new Option(s.name,s.slug,false,s.slug===member.slug)));
  select.disabled = list.length === 0;
  $('effectif').textContent=`${list.length} forme${list.length===1?'':'s'} ${q?'trouvée'+(list.length===1?'':'s'):'disponibles'}`;
}
function sync(options=true) {
  const member=duo[active], s=bySlug.get(member.slug);
  const yaw=Math.min(dir,8-dir);
  const shape=s.stencils[s.anim[move][dir][0][4+member.piece]];
  const clue=!member.ink ? 'Aucun accessoire porté.' : member.piece >= 2 ? 'La pièce suit le repère de tête du sprite et ses mouvements.' : shape[3] ? 'L’attache est sur le côté opposé : seule une partie du lien reste visible.'
    : member.piece===0 ? (yaw>=3 ? 'Le nœud reste devant ; seul le lien se voit.' : yaw===2 ? 'Le nœud se lit de profil comme un pli court.' : 'Le nœud se pose à l’avant de l’attache.')
    : yaw>=3 ? 'Le nœud et le pan court se voient à l’arrière.' : yaw===2 ? 'Le pan passe derrière le corps ; la silhouette en cache une partie.' : 'La bavette retombe devant, sans déplacer le nœud de la nuque.';
  press(buttons.actor, e=>Number(e.dataset.personnage)===active);
  press(buttons.mode, e=>Number(e.dataset.mode)===move);
  press(buttons.light,e=>e.dataset.lumiere===light);
  press(buttons.piece,e=>Number(e.dataset.piece)===member.piece);
  press(buttons.angles,e=>Number(e.dataset.dir)===dir);
  press([...$('palette').children], e=>Number(e.dataset.encre)===member.ink);
  $('scene').dataset.lumiere=light; $('sceneTag').textContent=light.toUpperCase();
  $('direction').textContent=names[dir];
  $('nomCouleur').textContent=lib.palette[member.ink].n;
  $('coupe').textContent=fittings[s.cut];
  $('style').textContent=clue;
  duo.forEach((m,i)=>{
    $('label'+i).textContent=bySlug.get(m.slug).name;
    const attire=m.ink?`${pieces[m.piece]} · ${lib.palette[m.ink].n}`:lib.palette[0].n;
    $('wear'+i).textContent=attire;
    $('acteur'+i).setAttribute('aria-label',`${i?'Partenaire':'Héros'} : ${bySlug.get(m.slug).name}, ${attire}`);
  });
  if(options)writeOptions();
  $('status').textContent=`${active?'Partenaire':'Héros'} : ${s.name}. ${$('wear'+active).textContent}. ${names[dir]}.`;
  redraw();
}
['↓','↙','←','↖','↑','↗','→','↘'].forEach((arrow,d)=>{
  const b=document.createElement('button'); b.type='button'; b.dataset.dir=d;
  b.textContent=arrow; b.title=names[d]; b.setAttribute('aria-label',names[d]);
  b.onclick=()=>{dir=d;sync(false);}; buttons.angles.push(b); $('angles').append(b);
});
buttons.piece.forEach(b=>b.onclick=()=>{const member=duo[active];member.piece=Number(b.dataset.piece);if(!member.ink)member.ink=active===0?1:4;sync(false);});
buttons.actor.forEach(b=>b.addEventListener('click',()=>{active=Number(b.dataset.personnage);$('recherche').value='';sync();}));
buttons.mode.forEach(b=>b.addEventListener('click',()=>{move=Number(b.dataset.mode);resetClock();sync(false);}));
buttons.light.forEach(b=>b.addEventListener('click',()=>{light=b.dataset.lumiere;sync(false);}));
$('recherche').addEventListener('input',writeOptions);
$('starter').addEventListener('change',()=>{ if ($('starter').value) { duo[active].slug=$('starter').value; resetClock(); sync(false); } });
$('versG').onclick=()=>{dir=(dir+1)%8;sync(false);};
$('versD').onclick=()=>{dir=(dir+7)%8;sync(false);};
$('reset').onclick=()=>{duo=defaultDuo();active=dir=move=0;light='jour';$('recherche').value='';resetClock();sync();};
sync();
