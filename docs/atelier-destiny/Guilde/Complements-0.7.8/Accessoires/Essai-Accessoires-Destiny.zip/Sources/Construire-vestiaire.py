#!/usr/bin/env python3
"""Assemble un vestiaire hors-ligne depuis les exports du banc natif FNA."""
import argparse, base64, io, json
from pathlib import Path
from PIL import Image
p=Path(__file__).resolve().parent

def pack(image):
    f=io.BytesIO();image.save(f,format='PNG',optimize=True)
    return 'data:image/png;base64,'+base64.b64encode(f.getvalue()).decode('ascii')

def grade(pixel):
    r,g,b,a=pixel
    if not a:return (0,0,0,0)
    assert a==255, 'Utiliser un export à alpha binaire (cf. banc natif).'
    gray=.299*r+.587*g+.114*b;lum=gray/255;k=.20+.30*lum
    return (int((r*.95+gray*.05)*(k*.52)),int((g*.95+gray*.05)*(k*.70)),min(255,int((b*.95+gray*.05)*(k*1.60)+6*lum)),a)

a=argparse.ArgumentParser(description=__doc__);a.add_argument('banc',type=Path);opt=a.parse_args()
d=json.loads((opt.banc/'Sprites.json').read_text(encoding='utf-8'))
assert len(d['entries'])==86 and len(d['palette'])==10
assert len({s['cut'] for s in d['entries']})==15
assert all(s['stencils'] for s in d['entries'])
for s in d['entries']:
    im=Image.open(opt.banc/(s['slug']+'.png')).convert('RGBA')
    colors=im.getcolors(20000);assert colors is not None
    night=im.copy();table={c:grade(c) for _,c in colors};night.putdata([table[x] for x in (im.get_flattened_data() if hasattr(im,"get_flattened_data") else im.getdata())])
    s['img']=[pack(im),pack(night)]
text=(p/'Vestiaire.html').read_text(encoding='utf-8')
text=text.replace('/* STYLE */',(p/'Vestiaire.css').read_text(encoding='utf-8')).replace('/* SCRIPT */',(p/'Vestiaire.js').read_text(encoding='utf-8'))
text=text.replace('/* DATA */',json.dumps(d,ensure_ascii=False,separators=(',',':')).replace('</','<\\/'))
out=p.parent/'Vestiaire-Foulards-et-Rubans.html';out.write_text(text,encoding='utf-8');print(out,out.stat().st_size)
