# Objets d’intérieur de guilde PMD — lot 01/06

## Accueil et missions

Les **10 objets** sont des créations distinctes, chacune issue d’une génération d’image. Les bruts sont conservés dans le dossier du projet. La finition enlève le magenta, ajuste l’échelle et remet les couleurs sur la palette de l’atelier. Le brut de la cloche touchait le cadre : un liseré d’un pixel a été raccordé lors du détourage.

- `001` Comptoir d’accueil — 86 × 49 px, au sol.
- `002` Tableau des missions — 65 × 67 px, au sol.
- `003` Poteau directionnel — 35 × 54 px, au sol.
- `004` Banc aux racines — 76 × 42 px, au sol.
- `005` Boîte à missions — 32 × 52 px, au sol.
- `006` Tapis du seuil — 82 × 48 px, au sol · tapis.
- `007` Lanterne du guichet — 30 × 33 px, sur un meuble.
- `008` Porte-cartes — 48 × 51 px, au sol.
- `009` Cloche de rappel — 34 × 20 px, sur un meuble.
- `010` Présentoir aux badges — 45 × 40 px, sur un meuble.

- **`Sprites/`** : PNG RGBA à l’échelle 1×, un sprite par fichier. Une tuile logique vaut 8 px.
- **`Planche-transparente.png`** : planche de 560 × 176 px (5 colonnes × 2 lignes ; cellules de 112 × 88 px). Pas de texte ni fond collé aux sprites.
- **`Index.json`** et **`Index.csv`** : rectangles `[x, y, largeur, hauteur]`, mesurés depuis le coin haut gauche de la planche, ainsi que les ancres de pose locales. L’emprise éventuelle est indicative : calculez les collisions selon votre salle.
- **`Apercu-du-lot.png`** : planche légendée agrandie, pour la consultation. N’importez pas cette planche décorative dans le jeu.

Afficher les sprites en **nearest neighbor** / « voisin le plus proche ». Le kit fournit **une orientation statique par objet**, sans animation ni collision préconfigurée. Les fichiers du jeu ne sont pas modifiés.

Direction visuelle : pixel art DS d’Explorateurs du Ciel et bois de la guilde Destiny. Le repère de palette est un extrait de la banque PMU publiée dans le travail précédent ; aucun des 10 sprites livrés ne reprend son dessin.
