# Objets d’intérieur de guilde PMD — lot 03/06

## Dortoirs et chambres

Les **10 objets** sont des créations distinctes, chacune issue d’une génération d’image. Les bruts sont conservés dans le dossier du projet. La finition enlève le magenta, ajuste l’échelle et remet les couleurs sur la palette de l’atelier.

- `021` Nid de feuilles — 68 × 37 px, au sol.
- `022` Coffre de chevet — 36 × 20 px, au sol.
- `023` Armoire à couvertures — 56 × 60 px, au sol.
- `024` Patère à sacs — 23 × 53 px, au sol.
- `025` Veilleuse champignon — 27 × 31 px, sur un meuble.
- `026` Miroir en goutte — 30 × 49 px, au sol.
- `027` Panier à linge — 23 × 31 px, au sol.
- `028` Paravent de feuilles — 72 × 64 px, au sol.
- `029` Hamac de lianes — 80 × 48 px, au sol.
- `030` Édredon roulé — 38 × 33 px, sur un meuble.

- **`Sprites/`** : PNG RGBA à l’échelle 1×, un sprite par fichier. Une tuile logique vaut 8 px.
- **`Planche-transparente.png`** : planche de 560 × 176 px (5 colonnes × 2 lignes ; cellules de 112 × 88 px). Pas de texte ni fond collé aux sprites.
- **`Index.json`** et **`Index.csv`** : rectangles `[x, y, largeur, hauteur]`, mesurés depuis le coin haut gauche de la planche, ainsi que les ancres de pose locales. L’emprise éventuelle est indicative : calculez les collisions selon votre salle.
- **`Apercu-du-lot.png`** : planche légendée agrandie, pour la consultation. N’importez pas cette planche décorative dans le jeu.

Afficher les sprites en **nearest neighbor** / « voisin le plus proche ». Le kit fournit **une orientation statique par objet**, sans animation ni collision préconfigurée. Les fichiers du jeu ne sont pas modifiés.

Direction visuelle : pixel art DS d’Explorateurs du Ciel et bois de la guilde Destiny. Le repère de palette est un extrait de la banque PMU publiée dans le travail précédent ; aucun des 10 sprites livrés ne reprend son dessin.
