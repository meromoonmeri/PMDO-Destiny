#!/usr/bin/env python3
"""Banc portable .NET 8 : compile la copie du moteur avec Verif-native.cs.

Fournir csc.dll du SDK 8.x, dotnet (8.x), ref/net8.0, un dossier host contenant
les dépendances PMDC et System.Resources.NetStandard.dll (NuGet 1.0.1).
Aucun fichier de ces dossiers n'est modifié.
"""
import argparse,json,os,subprocess
from pathlib import Path

a=argparse.ArgumentParser(description=__doc__)
for name in ('dotnet','csc','refs','dependances','sources','out'):
    a.add_argument('--'+name,type=Path,required=True)
a.add_argument('--superposition',type=Path,help='moteur patché partiel, pour banc sans checkout')
p=a.parse_args(); out=p.out.resolve();out.mkdir(parents=True,exist_ok=True)
launcher=out/'RogueEssence.dll'
refs=sorted(p.refs.glob('*.dll'))
assert len(refs)>100
engine={f.relative_to(p.sources):f for f in p.sources.rglob('*.cs') if not {'obj','bin'}.intersection(f.relative_to(p.sources).parts)}
if p.superposition:
    engine.update({f.relative_to(p.superposition):f for f in p.superposition.rglob('*.cs')})
for dep in ('FNA','RogueElements','NLua','Newtonsoft.Json','JsonDiffPatchDotNet','LiteNetLib','KeraLua','System.Resources.NetStandard'):
    loc=p.dependances/(dep+'.dll')
    assert loc.exists(),loc
    refs.append(loc)
    link=out/loc.name
    if not link.exists(): link.symlink_to(loc.resolve())
config={'runtimeOptions':{'tfm':'net8.0','framework':{'name':'Microsoft.NETCore.App','version':'8.0.0'}}}
launcher.with_suffix('.runtimeconfig.json').write_text(json.dumps(config,indent=2)+'\n')
rsp=out/'banc.rsp'
opts=['/nologo','/target:exe','/langversion:12.0','/deterministic+','/optimize+','/define:TRACE','/main:DestinyRubans.VerifNative',f'/out:"{launcher}"']
opts += [f'/r:"{f.resolve()}"' for f in refs]
opts += [f'"{f.resolve()}"' for _,f in sorted(engine.items())]+[f'"{Path(__file__).with_name("Verif-native.cs").resolve()}"']
rsp.write_text('\n'.join(opts)+'\n')
subprocess.run([str(p.dotnet.resolve()),str(p.csc.resolve()),'@'+str(rsp)],check=True)
