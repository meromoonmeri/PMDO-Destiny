# Recette des contrôles du vestiaire V2

## Banque et patch

`Provenance-Banc.json` indique la révision et les identifiants Git des `.chara`, index et fiches utilisés. Conserver les banques `base/` et `game/` séparées, avec priorité à `game/`. Ajouter `base/Base/GFXParams.xml` de la même révision pour les clés d’animations.

Depuis le kit : `lua5.4 Tests/Lister-starters.lua <copie-originale>/game/Data/Script Sources/game/Data/Script > roster.tsv`. Les six colonnes sont espèce, forme, nom, génération, coupe, décalages par angle. Le pool a été comparé à l’original : ordre et exclusion de l’espèce du héros chez le partenaire inchangés.

`python Sources/Construire-patch.py <dépôt> <révision> <dossier-test-inexistant>` extrait les fichiers ciblés, émet le patch et vérifie son aller-retour octet par octet. Ne modifie pas le dépôt de départ.

## Banc FNA et vestiaire

1. Avec .NET 8, Roslyn, les références et dépendances natives de FNA, exécuter `Tests/Compiler-banc.py --help` pour préparer le programme. Pointer `--superposition` sur `engine/RogueEssence/RogueEssence` extrait du patch appliqué. Le banc est un exécutable de test, pas une DLL à installer.
2. Avec un affichage, par exemple Xvfb : `dotnet <banc>/RogueEssence.dll <racine-des-deux-banques> roster.tsv <sortie>`.
3. Le banc vérifie 86 formes, 14 profils, 774 variantes, 56 336 poses repos/marche et 1 600 rendus FNA dont 480 actions de donjon. Observer `Verification-rendu.json` et les sorties graphiques. Les comparaisons portent sur les calques, la silhouette, les angles, les décalages et le rendu jour/nuit ; elles ne prouvent pas que chaque visage est sémantiquement dégagé.
4. `python Sources/Construire-vestiaire.py <sortie>` reconstruit le HTML depuis les exports du banc. `node Tests/Verifier-vestiaire.cjs` teste le HTML ; les variables `PLAYWRIGHT` et `CHROME` peuvent viser des installations locales.

## Essai en jeu isolé

Effectué sur une copie Destiny 0.7.7 et un moteur recompilé depuis la révision de référence, sous Linux/.NET 8/FNA. Les répertoires `CONFIG`, `LOG` et `SAVE` sont propres au banc. La sauvegarde de départ était une copie du témoin R2 : Pikachu ruban Garance, Baie Oran, et Goupix d’Alola ruban Lagon. Les champs de style absents ont conservé le sens ruban.

`Banc-jeu.lua` peut être appelé depuis le `Update` de `guilde_destiny_refectoire` dans le banc uniquement. Il lit `banc-rubans-commande.txt`, sous forme `ID commande`, et écrit `banc-rubans-reponse.txt`. `actors` distingue les valeurs de l’équipe et des acteurs visibles ; `place`, `face`, `faceg`, `profilg`, `dosg`, `dos`, `dosd`, `profild`, `faced`, `jour`, `nuit`, `walk`, `stat` et `save` commandent les observations. `duo` prépare un nouveau duo de test. L’essai a utilisé le vrai menu Équipe pour les choix et le retrait, pas la fixture.

Après confirmation, l’acteur au sol a été contrôlé en plus des données de l’équipe : cela détecte le cas où le chargement d’une sauvegarde a désolidarisé les deux objets. Une sauvegarde a ensuite été chargée dans un nouveau processus, puis le partenaire modifié et le héros déshabillé. Le témoin R2 d’origine n’a pas changé. Les captures et résultats sont résumés dans `Verification-integration.json`.

La synchronisation évite de choisir arbitrairement entre membres indiscernables : dans ce cas limite, le rendu d’un acteur détaché peut attendre un changement de carte. La fixture et la sauvegarde de banc ne sont pas destinées au jeu final. Le rendu d’actions de donjon n’est pas une traversée complète ; aucun build Windows, push ou installation sur une sauvegarde joueur n’a été réalisé.
