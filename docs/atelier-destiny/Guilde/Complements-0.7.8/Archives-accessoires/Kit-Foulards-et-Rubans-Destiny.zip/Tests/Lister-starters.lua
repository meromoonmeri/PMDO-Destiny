-- Usage: lua5.4 Lister-starters.lua <répertoire Data/Script original> <Sources/game/Data/Script>
local original, sources = assert(arg[1]), assert(arg[2])
package.path = sources .. '/?.lua;' .. original .. '/?.lua;' .. package.path
local pool = require 'destiny.starter_pool'
local forms = pool.construire(nil)
local fits, seams = {}, {}
local setup = require 'destiny.rubans'
luanet = { import_type = function() return nil end }
setup.installer() -- un moteur ancien ne casse pas l'initialisation
luanet.import_type = function(name)
  assert(name == 'RogueEssence.Content.DestinyRibbon')
  return { RegisterStarter = function(species, form, fit, seam)
    local key = species .. ':' .. tostring(form)
    assert(fits[key] == nil)
    fits[key], seams[key] = fit, seam
  end }
end
setup.installer()
for key in pairs(fits) do assert(key:find(':', 1, true)) end
for _, s in ipairs(forms) do
  local key = s.espece .. ':' .. tostring(s.forme)
  assert(fits[key] ~= nil and fits[key] == setup.profil(s.espece, s.forme), key .. " : profil explicite absent")
  local same = 0
  for _, other in ipairs(forms) do if other.espece == s.espece then same = same + 1 end end
  local partner = pool.construire(s.espece)
  assert(#partner == #forms - same)
  for _, other in ipairs(partner) do assert(other.espece ~= s.espece) end
  assert(seams[key] == setup.couture(s.espece, s.forme))
  print(table.concat({s.espece, s.forme, s.nom, s.gen, fits[key], seams[key]}, '\t'))
  fits[key] = nil
end
assert(next(fits) == nil)
