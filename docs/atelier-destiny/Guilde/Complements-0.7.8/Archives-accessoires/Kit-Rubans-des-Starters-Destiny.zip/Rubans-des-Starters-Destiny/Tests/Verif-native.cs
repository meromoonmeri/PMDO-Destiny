// Banc isolé : compilez ce fichier AVEC les sources de RogueEssence, entrée
// DestinyRubans.VerifNative. Ne pas inclure ce fichier dans la build du jeu.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RogueElements;
using RogueEssence;
using RogueEssence.Content;
using RogueEssence.Ground;
using RogueEssence.Dungeon;

namespace DestinyRubans
{
    sealed class VerifNative : Game
    {
        private readonly GraphicsDeviceManager graphics;
        private readonly string root;
        private readonly string roster;
        private readonly string output;
        private int testedFrames, usedSheets, checkedVariants, rendered, dungeonRenders;
        private SpriteBatch batch;
        private RenderTarget2D target;
        private readonly List<object> samples = new List<object>();

        public VerifNative(string root, string roster, string output)
        {
            this.root = Path.GetFullPath(root);
            this.roster = roster;
            this.output = output;
            graphics = new GraphicsDeviceManager(this) { PreferredBackBufferWidth = 320, PreferredBackBufferHeight = 240 };
        }

        public static int Main(string[] args)
        {
            if (args.Length != 3)
            {
                Console.Error.WriteLine("Usage : VerifNative <racine contenant base et game> <roster.tsv> <sortie>");
                return 2;
            }
            try
            {
                CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
                using var game = new VerifNative(args[0], args[1], args[2]);
                game.Run();
                return 0;
            }
            catch (Exception ex) { Console.Error.WriteLine(ex); return 1; }
        }

        protected override void LoadContent()
        {
            Directory.CreateDirectory(output);
            PathMod.InitPathMod(Path.Combine(root, "base", "Banc.dll"));
            DiagManager.InitInstance();
            GraphicsManager.InitParams();
            using var placeholder = new Texture2D(GraphicsDevice, 16, 16);
            BaseSheet.InitBase(GraphicsDevice, placeholder);
            using var spriteBatch = new SpriteBatch(GraphicsDevice);
            batch = spriteBatch;
            using var buffer = new RenderTarget2D(GraphicsDevice, 128, 128);
            target = buffer;
            CheckAll();
            Exit();
        }

        private void CheckAll()
        {
            var monster = new Dictionary<string, int>();
            var index = new CharaIndexNode { Nodes = new Dictionary<int, CharaIndexNode>() };
            foreach (string layer in new[] { "base", "game" })
            {
                string m = Path.Combine(root, layer, "Data", "Monster", "index.idx");
                if (File.Exists(m))
                    foreach (var kv in (JObject)JObject.Parse(File.ReadAllText(m))["Object"])
                        if (kv.Value is JObject value && value["SortOrder"] != null) monster[kv.Key] = (int)value["SortOrder"];
                string c = Path.Combine(root, layer, "Content", "Chara", "index.idx");
                using var reader = new BinaryReader(File.OpenRead(c));
                foreach (var kv in CharaIndexNode.Load(reader).Nodes)
                    index.Nodes[kv.Key] = kv.Value;
            }

            var entries = new List<object>();
            var seen = new HashSet<(string, int)>();
            foreach (string line in File.ReadLines(roster))
            {
                string[] s = line.Split('\t');
                int form = Int32.Parse(s[1]);
                string name = s[2];
                Require(seen.Add((s[0], form)), "doublon " + s[0]);
                var style = s[4] == "epaule" ? DestinyRibbon.Fit.Shoulder : s[4] == "bas" ? DestinyRibbon.Fit.LowCollar : DestinyRibbon.Fit.Collar;
                int dex = monster[s[0]];
                var first = new CharID(dex, form, 0, 0);
                var fallback = GraphicsManager.GetFallbackForm(index, first);
                var checkedIds = new HashSet<CharID>();
                for (int skin = 0; skin < 3; skin++)
                    for (int gender = 0; gender < 3; gender++)
                    {
                        var id = GraphicsManager.GetFallbackForm(index, new CharID(dex, form, skin, gender));
                        Require(id.Species == dex && (id.Form == form || (form == 0 && id.Form == -1)), "Sprite remplacé : " + name + " / " + skin + " / " + gender);
                        checkedVariants++;
                        if (!checkedIds.Add(id))
                            continue;
                        using var sheet = ReadSheet(index, id);
                        int idle = GraphicsManager.IdleAction;
                        int walk = GraphicsManager.WalkAction;
                        usedSheets++;
                        var normal = id == fallback;
                        var pixels = BaseSheet.GetData(sheet);
                        var frameTiles = new Dictionary<(int, int, bool), int>();
                        var sequences = new List<object>();
                        foreach (int action in new[] { idle, walk })
                        {
                            int reference = sheet.GetReferencedAnimIndex(action);
                            Require(reference >= 0 && sheet.AnimData.ContainsKey(reference), "Animation absente " + name + ":" + action);
                            var choreo = new List<int[][]>();
                            for (int d = 0; d < 8; d++)
                            {
                                var dir = (Dir8)d;
                                List<CharAnimFrame> seq = sheet.AnimData[reference].SeqAtDir(dir).Frames;
                                Require(seq.Count > 0, "Séquence vide " + name + ":" + action + ":" + d);
                                int prior = 0;
                                var frames = new List<int[]>();
                                for (int f = 0; f < seq.Count; f++)
                                {
                                    CharAnimFrame frame = seq[f];
                                    DestinyRibbon.Pose pose = sheet.GetDestinyRibbonPose(frame, dir, style);
                                    Require(pose.Exists, "Pose vide " + name + ":" + action + ":" + d + ":" + f);
                                    Require(pose.X >= 0 && pose.X < sheet.TileWidth && pose.Y >= 0 && pose.Y < sheet.TileHeight, "Nœud hors de la tuile " + name);
                                    int px = frame.Frame.X * sheet.TileWidth + (frame.Flip ? sheet.TileWidth - 1 - pose.X : pose.X);
                                    int py = frame.Frame.Y * sheet.TileHeight + pose.Y;
                                    Require(pixels[py * sheet.Width + px].A >= 64, "Nœud détaché " + name);
                                    Require(frame.EndTime > prior, "Durée nulle " + name);
                                    Require(DestinyRibbon.Masks[pose.Mask][DestinyRibbon.KnotY][DestinyRibbon.KnotX] != '.', "Nœud invisible");
                                    testedFrames++;
                                    if (normal)
                                    {
                                        var tile = (frame.Frame.X, frame.Frame.Y, frame.Flip);
                                        if (!frameTiles.TryGetValue(tile, out int tileId))
                                        {
                                            tileId = frameTiles.Count;
                                            frameTiles.Add(tile, tileId);
                                        }
                                        Loc offset = sheet.GetSheetOffset(action, action == walk, dir, _ => f);
                                        frames.Add(new[] { tileId, offset.X, offset.Y, frame.EndTime - prior, pose.X, pose.Y, pose.Mask, pose.Mirror ? 1 : 0 });
                                    }
                                    prior = frame.EndTime;
                                }
                                if (normal) choreo.Add(frames.ToArray());
                            }
                            if (normal) sequences.Add(choreo);
                        }
                        if (!normal) continue;
                        string slug = s[0] + "_" + form;
                        WriteTileExport(sheet, frameTiles, pixels, Path.Combine(output, slug + ".png"));
                        entries.Add(new { slug, species = s[0], form, name, generation = Int32.Parse(s[3]), cut = s[4],
                            width = sheet.TileWidth, height = sheet.TileHeight, columns = 8, tiles = frameTiles.Count, anim = sequences });
                        if (new[] { "pikachu_0", "rowlet_0", "vulpix_1", "snom_0", "beldum_0", "cosmog_0", "meowth_0" }.Contains(slug))
                        {
                            CheckRenders(sheet, name, slug, style);
                            CheckDungeon(sheet, name, style);
                        }
                    }
                if (entries.Count % 16 == 0) Console.WriteLine(entries.Count + " formes vérifiées");
            }
            Require(entries.Count == 86, "Roster inattendu");
            var palette = DestinyRibbon.Colors.Select(shade => new { id = shade.Key, n = shade.Name,
                c = shade.Ink.Select(Hex), nuit = shade.Ink.Select(c => Hex(CharSheet.DestinyNightGrade(c))) }).ToArray();
            File.WriteAllText(Path.Combine(output, "Sprites.json"), JsonConvert.SerializeObject(new { entries, palette, masks = DestinyRibbon.Masks, samples }, Formatting.None));
            File.WriteAllText(Path.Combine(output, "Verification-rendu.json"), JsonConvert.SerializeObject(new {
                resultat = "PASS", formes = entries.Count, variantes_testees = checkedVariants, feuilles_distinctes = usedSheets,
                attaches_sur_alpha = testedFrames, rendus_fna = rendered, rendus_donjon = dungeonRenders,
                note = "Variantes = 3 skins × 3 genres ; replis natifs conservant l'espèce et la forme. Seule la feuille normale est exportée dans le vestiaire.",
                verifications = new[] { "Espèce et forme maintenues dans chaque repli", "Les 8 directions en attente et en marche", "Nœud attaché à un pixel visible, y compris en miroir", "Comparaisons GPU du nœud au sol : couleur, nuit, hauteur et déplacement", "Comparaisons GPU des actions de donjon : repos, marche et invisibilité", "Sans ruban : aucun pixel cosmétique" }
            }, Formatting.Indented) + "\n");
            Console.WriteLine($"PASS · {entries.Count} formes · {checkedVariants} variantes · {usedSheets} feuilles · {testedFrames} nœuds · {rendered} rendus GPU");
        }

        private CharSheet ReadSheet(CharaIndexNode index, CharID id)
        {
            string f = Path.Combine("Content", "Chara", id.Species + ".chara");
            string complete = Path.Combine(root, "game", f);
            if (!File.Exists(complete)) complete = Path.Combine(root, "base", f);
            using var reader = new BinaryReader(File.OpenRead(complete));
            long pos = index.GetPosition(id.Species, id.Form, id.Skin, id.Gender);
            Require(pos > 0 && pos < reader.BaseStream.Length, "Index de sprite invalide : " + complete);
            reader.BaseStream.Position = pos;
            return CharSheet.Load(reader);
        }

        private void WriteTileExport(CharSheet sheet, Dictionary<(int, int, bool), int> tiles, Color[] pixels, string filename)
        {
            int w = sheet.TileWidth, h = sheet.TileHeight, width = w * 8, height = h * ((tiles.Count + 7) / 8);
            Color[] data = new Color[width * height];
            foreach (var kv in tiles)
            {
                var (fx, fy, mirror) = kv.Key;
                int left = (kv.Value % 8) * w;
                int top = (kv.Value / 8) * h;
                for (int y = 0; y < h; y++)
                    for (int x = 0; x < w; x++)
                        data[(top + y) * width + left + x] = pixels[(fy * h + y) * sheet.Width + fx * w + (mirror ? w - 1 - x : x)];
            }
            using var tex = new Texture2D(GraphicsDevice, width, height);
            tex.SetData(data);
            using var file = File.Create(filename);
            tex.SaveAsPng(file, width, height);
        }

        private void CheckRenders(CharSheet sheet, string name, string slug, DestinyRibbon.Fit cut)
        {
            var mapLoc = new Loc(58, 52);
            var camera = new Loc(3, -2);
            const int height = 7;
            for (int move = 0; move <= 1; move++)
                for (int d = 0; d < 8; d++)
                {
                    Dir8 dir = (Dir8)d;
                    int type = move == 0 ? GraphicsManager.IdleAction : GraphicsManager.WalkAction;
                    int frameCount = sheet.AnimData[sheet.GetReferencedAnimIndex(type)].SeqAtDir(dir).Frames.Count;
                    for (int timeChoice = 0; timeChoice < 2; timeChoice++)
                    {
                        var time = FrameTick.FromFrames(timeChoice == 0 || frameCount < 2 ? 0 : sheet.AnimData[sheet.GetReferencedAnimIndex(type)].SeqAtDir(dir).Frames[0].EndTime);
                        GroundAction action = move == 0 ? new IdleGroundAction(mapLoc, height, dir) { Override = type }
                            : new WalkGroundAction(mapLoc, height, dir, false, 1, time);
                        action.ActionTime = time;
                        action.UpdateFrame();
                        var frames = sheet.AnimData[sheet.GetReferencedAnimIndex(type)].SeqAtDir(dir).Frames;
                        var frame = frames[action.FrameMethod(frames)];
                        var pose = sheet.GetDestinyRibbonPose(frame, dir, cut);
                        Loc knot = action.GetDrawLoc(camera, sheet) + sheet.GetSheetOffset(type, move > 0, dir, action.FrameMethod) - new Loc(0, height) + new Loc(pose.X, pose.Y);
                        int ink = 1 + (d + move * 3 + timeChoice) % (DestinyRibbon.Colors.Length - 1);
                        var wear = new DestinyRibbon.Wear(ink, cut);
                        Color expected = DestinyRibbon.Colors[ink].Ink[DestinyRibbon.Masks[pose.Mask][DestinyRibbon.KnotY][DestinyRibbon.KnotX] - '1'];

                        Color[] bare = Render(action, sheet, camera, Color.White, default);
                        Color[] worn = Render(action, sheet, camera, Color.White, wear);
                        Require(bare[knot.Y * 128 + knot.X].A >= 64, "Couleur hors du sprite GPU " + name);
                        var knotColor = worn[knot.Y * 128 + knot.X];
                        Require(Near(knotColor, expected), "Coutures jeu ↔ banc incohérentes " + name + " " + knotColor + " / " + expected);
                        Require(!bare.SequenceEqual(worn), "Couleur sans effet " + name);

                        CharSheet night = sheet.GetDestinyNightCopy();
                        Color[] nights = Render(action, night, camera, Color.White, wear);
                        Require(Near(nights[knot.Y * 128 + knot.X], CharSheet.DestinyNightGrade(expected)), "Nœud phosphorescent en nuit " + name);
                        action.UpdateDrawEffects(new HashSet<DrawEffect> { DrawEffect.Absent });
                        Require(Render(action, sheet, camera, Color.White, wear).All(c => c.A == 0), "Ruban flottant sur personnage masqué");
                        if (timeChoice == 0 && move == 0 && (d == 0 || d == 2 || d == 4))
                        {
                            var file = Path.Combine(output, "moteur-" + slug + "-" + d + ".png");
                            using var strip = new Texture2D(GraphicsDevice, 128 * 3, 128);
                            strip.SetData(RowStrip(bare, worn, nights));
                            using var fs = File.Create(file);
                            strip.SaveAsPng(fs, strip.Width, strip.Height);
                            samples.Add(new { fichier = Path.GetFileName(file), name, d, ink, noeud = new[] { knot.X, knot.Y } });
                        }
                    }
                }
        }

        private void CheckDungeon(CharSheet sheet, string name, DestinyRibbon.Fit cut)
        {
            var camera = new Loc(3, 1);
            var tile = new Loc(2, 2);
            for (int move = 0; move < 2; move++)
                for (int d = 0; d < 8; d++)
                {
                    Dir8 dir = (Dir8)d;
                    CharAnimation anim = move == 0 ? new CharAnimIdle(tile, dir) { Override = GraphicsManager.IdleAction }
                        : new CharAnimWalk(tile, tile + dir.GetLoc(), dir, 1);
                    anim.Update(FrameTick.FromFrames(move == 0 ? 0 : 7), default, 0);
                    var action = new EmptyCharAction(anim);
                    action.UpdateFrame();
                    action.GetCurrentSprite(sheet, out int type, out _, out int frameNo);
                    var frame = sheet.AnimData[sheet.GetReferencedAnimIndex(type)].SeqAtDir(dir).Frames[frameNo];
                    var pose = sheet.GetDestinyRibbonPose(frame, dir, cut);
                    var knot = action.GetDrawLoc(camera, sheet) + action.GetSheetOffset(sheet) + new Loc(pose.X, pose.Y);
                    var wear = new DestinyRibbon.Wear(7, cut);
                    Color want = DestinyRibbon.Colors[wear.Ink].Ink[DestinyRibbon.Masks[pose.Mask][DestinyRibbon.KnotY][DestinyRibbon.KnotX] - '1'];
                    var bare = Render(() => action.Draw(batch, camera, sheet));
                    var worn = Render(() => action.Draw(batch, camera, sheet, wear));
                    Require(bare[knot.Y * 128 + knot.X].A >= 64 && Near(worn[knot.Y * 128 + knot.X], want) && !bare.SequenceEqual(worn), "Ruban donjon décalé " + name);
                    action.UpdateDrawEffects(new HashSet<DrawEffect> { DrawEffect.Absent });
                    Require(Render(() => action.Draw(batch, camera, sheet, wear)).All(c => c.A == 0), "Ruban donjon visible sur personnage masqué");
                    dungeonRenders += 3;
                }
        }

        private Color[] Render(GroundAction action, CharSheet sheet, Loc camera, Color tint, DestinyRibbon.Wear wear)
            => Render(() => action.Draw(batch, camera, sheet, tint, wear));

        private Color[] Render(Action draw)
        {
            GraphicsDevice.SetRenderTarget(target);
            GraphicsDevice.Clear(Color.Transparent);
            batch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp, null, null, null, Matrix.Identity);
            draw();
            batch.End();
            GraphicsDevice.SetRenderTarget(null);
            Color[] data = new Color[128 * 128];
            target.GetData(data);
            rendered++;
            return data;
        }

        private static Color[] RowStrip(params Color[][] cells)
        {
            Color[] row = new Color[128 * 128 * cells.Length];
            for (int y = 0; y < 128; y++)
                for (int i = 0; i < cells.Length; i++)
                    Array.Copy(cells[i], y * 128, row, y * 128 * cells.Length + i * 128, 128);
            return row;
        }

        private static bool Near(Color p, Color q) => Math.Abs(p.R - q.R) <= 1 && Math.Abs(p.G - q.G) <= 1 && Math.Abs(p.B - q.B) <= 1 && Math.Abs(p.A - q.A) <= 1;
        private static string Hex(Color c) => $"#{c.R:X2}{c.G:X2}{c.B:X2}";
        private static void Require(bool cond, string message) { if (!cond) throw new Exception(message); }
    }
}
