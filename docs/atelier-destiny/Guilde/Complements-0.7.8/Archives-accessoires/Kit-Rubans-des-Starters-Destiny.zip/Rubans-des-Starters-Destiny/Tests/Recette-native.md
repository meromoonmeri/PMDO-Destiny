# Recette des contrôles du vestiaire

## Banque de départ et patch

`Provenance-Banc.json` donne la révision et les identifiants Git des fichiers `.chara`, des index et des fiches utilisés. Garder `base/` et `game/` séparés, conformément au montage Destiny. La couche `game/` prend la priorité sur un conteneur homonyme. Ajouter `base/Base/GFXParams.xml` de la même révision sur le banc pour les clés d’animations.

Pour reconstituer la liste : depuis le kit, lancer `lua5.4 Tests/Lister-starters.lua <copie-originale>/game/Data/Script Sources/game/Data/Script > roster.tsv` (sans ligne d’en-tête). Le pool d’avant et après a été comparé à l’original Lua : choix et ordre identiques pour le héros et pour chaque filtre de partenaire.

`python Sources/Construire-patch.py <dépôt> <révision> <dossier-vide-non-créé>` extrait uniquement les fichiers ciblés, émet le patch, fait `git apply --check` et contrôle le retour exact octet par octet. N’écrit pas dans le dépôt de départ.

## Banc FNA

1. Appliquer le patch au code moteur, ou le monter avec `--superposition` sur une lecture seule. Utiliser `Tests/Compiler-banc.py --help` pour les chemins. FNA natif et bindings adaptés à l’OS sont requis pour exécuter le test ; l’outil n’installe aucune dépendance.
2. Avec .NET 8 et un affichage (Xvfb convient), exécuter `dotnet <banc>/RogueEssence.dll <racine-des-deux-banques> roster.tsv <sortie>`. Le programme est un exécutable de test, pas une DLL à installer dans le jeu.
3. Observer `Verification-rendu.json` et les captures `moteur-*`. `python Sources/Construire-vestiaire.py <sortie>` reconstruit le HTML à partir des petits exports de marche/repos. `node Tests/Verifier-vestiaire.cjs` lance les tests interactifs ; `PLAYWRIGHT` et `CHROME` peuvent viser des installations locales.

## Essai en jeu

Effectué sur une copie de banc de Destiny 0.7.7, .NET 8 et FNA Linux, avec le moteur recompilé à la révision de référence + patch et les ressources `.chara` exactes des formes testées. Les cartes du réfectoire étaient celles du banc 0.7.7. Le banc utilise ses propres répertoires `CONFIG`, `LOG` et `SAVE`.

Le point de départ d’essai est `guilde_destiny_interieur`, segment −1, carte 5 (`guilde_destiny_refectoire`). `Banc-jeu.lua` peut être appelé depuis le `Update` de cette carte d’essai uniquement. Il lit `banc-rubans-commande.txt` depuis le répertoire du banc, sous forme `ID commande`. `duo` prépare Pikachu et Goupix d’Alola, `stat` lit leurs couleurs, `jour`/`nuit` changent la lumière, `save` demande une sauvegarde native. Le choix de teintes a été effectué dans le **vrai menu Équipe**, pas avec la fixture. Reprendre la partie après arrêt et lancement d’un nouveau processus confirme la persistance. Il ne faut ni distribuer la sauvegarde de test ni incorporer cette fixture en production.

Le test d’affichage de donjon est un banc de rendu des actions natives, pas une traversée de donjon complète. Aucun build Windows ni push n’a été exécuté pour ce kit.
