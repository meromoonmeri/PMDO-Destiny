-- Banc isolé, jamais incorporé au patch à installer.
local M = {}
local time,last = 0,''
local cut = require 'destiny.guilde_destiny_decors'
local chars = require 'destiny.equipe_scene'

local function log(token, room, detail)
  local f = assert(io.open('banc-rubans-reponse.tmp','w'))
  f:write(token .. '\n' .. room .. '\n' .. tostring(detail) .. '\n')
  local team = _DATA.Save.ActiveTeam
  for i=0,team.Players.Count-1 do
    local p = team.Players[i]
    f:write(table.concat({p.BaseForm.Species,tostring(p.BaseForm.Form),p.DestinyRibbonColor or '-',p.EquippedItem.ID or '-'},'\t')..'\n')
  end
  f:close()
  os.rename('banc-rubans-reponse.tmp','banc-rubans-reponse.txt')
end

function M.Update(map, room)
  time = (time + 1) % 10
  if time ~= 0 then return end
  local f = io.open('banc-rubans-commande.txt','r')
  if f == nil then return end
  local request = f:read('*a'); f:close()
  if request == nil or request == last then return end
  local token, command = request:match('^(%w+)%s+(%w+)')
  if token == nil then return end
  last = request
  local ok, detail = pcall(function()
    local team = _DATA.Save.ActiveTeam
    if command == 'duo' then
      local p = CH('PLAYER').MapLoc
      team.Players:Clear()
      local function player(spec,form,gender,name,role)
        local id = RogueEssence.Dungeon.MonsterID(spec, form, 'normal', gender)
        local intrinsic = _DATA:GetMonster(spec).Forms[form].Intrinsic1
        local ch = team:CreatePlayer(_DATA.Save.Rand, id, 8, intrinsic, 0)
        ch.IsFounder, ch.IsPartner = true, true
        LTBL(ch).Importance = role
        GAME:SetCharacterNickname(ch,name)
        team.Players:Add(ch)
        return ch
      end
      local hero = player('pikachu', 0, Gender.Male, 'Pikachu', 'Hero')
      hero.EquippedItem = RogueEssence.Dungeon.InvItem('berry_oran')
      player('vulpix', 1, Gender.Female, 'Goupix', 'Partner')
      team.LeaderIndex = 0
      GROUND:RefreshPlayer()
      local partner = chars.Partenaire(p.X+25,p.Y,Direction.Down)
      cut.ForcerAmbiance(map,room,'jour')
    elseif command == 'stat' then
      local p = CH('PLAYER')
      return 'stat ' .. p.MapLoc.X .. ' ' .. p.MapLoc.Y
    elseif command == 'save' then
      _DATA:SaveMainGameState()
    elseif command == 'jour' or command == 'nuit' then
      cut.ForcerAmbiance(map,room,command)
    elseif command == 'walk' then
      local p = CH('PLAYER'); local x,y = p.MapLoc.X,p.MapLoc.Y
      TASK:BranchCoroutine(function()
        GROUND:MoveToPosition(p,x+32,y,false,1)
        GROUND:MoveToPosition(p,x,y,false,1)
      end)
    end
    return command
  end)
  log(token,room,ok and detail or ('FAIL '..tostring(detail)))
end
return M
