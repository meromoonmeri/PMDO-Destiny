'use strict';
// Node + Playwright. PLAYWRIGHT et CHROME peuvent viser des installations locales.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {chromium}=require(process.env.PLAYWRIGHT || 'playwright');
const base=path.resolve(__dirname,'..');
const file=path.join(base,'Vestiaire-des-Starters.html');
const controls=[]; const passes=(msg)=>{controls.push(msg);console.log('OK · '+msg);};
(async()=>{
 const browser=await chromium.launch({headless:true,...(process.env.CHROME?{executablePath:process.env.CHROME}:{}),args:['--no-sandbox','--disable-dev-shm-usage']});
 const page=await browser.newPage({viewport:{width:1240,height:900},reducedMotion:'reduce'}); const faults=[], requests=[]; page.setDefaultTimeout(7000);
 page.on('pageerror',e=>faults.push(e.message)); page.on('request',rq=>{if (/^https?:/.test(rq.url()))requests.push(rq.url());});
 await page.route('http**',rq=>rq.abort());
 await page.goto(pathToFileURL(file).href);
 await page.waitForFunction(()=>art.size>0 && canvases.every((c,i)=>contexts[i].getImageData(0,0,64,62).data.some(x=>x>0)));
 if(process.argv[2])await page.screenshot({path:process.argv[2],fullPage:true});
 assert.equal(await page.locator('#starter option').count(),86);
 assert.equal(await page.locator('#palette button').count(),10);
 passes('86 choix préchargés, neuf teintes + Sans ruban, deux sprites natifs visibles');
 const getHash=async id=>await page.locator('#sprite'+id).evaluate(el=>el.toDataURL());
 const hero=await getHash(0),partner=await getHash(1);
 await page.getByRole('button',{name:'Ivoire',exact:true}).click();
 await page.waitForFunction(h=>canvases[0].toDataURL()!==h,hero);
 assert.equal(await getHash(1),partner);
 await page.locator('.roles').getByRole('button',{name:'Partenaire'}).click();
 assert.equal(await page.locator('#nomCouleur').innerText(),'Lagon');
 await page.getByRole('button',{name:'Sans ruban',exact:true}).click();
 await page.waitForFunction(h=>canvases[1].toDataURL()!==h,partner);
 assert.equal(await page.locator('#nomCouleur').innerText(),'Sans ruban');
 passes('Changer une teinte ne change que le membre actif ; retrait du ruban');
 await page.locator('#recherche').fill('hisui');
 assert.equal(await page.locator('#starter option[value]:not([value=""])').count(),3);
 await page.locator('#starter').selectOption('zorua_1');
 assert.match(await page.locator('#label1').innerText(),/Hisui/);
 await page.locator('#recherche').fill('miaouss');
 assert.equal(await page.locator('#starter option[value="meowth_0"]').count(),1);
 await page.locator('#recherche').fill('introuvable');
 assert.equal(await page.locator('#starter').isDisabled(),true);
 passes('Recherche sans accent, formes régionales conservées, Miaouss trouvé, aucun résultat propre');
 await page.locator('#reset').click();
 for(const d of ['3/4 gauche','Profil gauche','Dos gauche','Dos','Dos droit','Profil droit','3/4 droit','Face']) {
  await page.locator('#versG').click(); assert.equal(await page.locator('#direction').innerText(),d);
 }
 await page.locator('#versD').click(); assert.equal(await page.locator('#direction').innerText(),'3/4 droit');
 await page.getByRole('button',{name:'Marche',exact:true}).click();
 let walked=await getHash(0);
 await page.waitForFunction(h=>canvases[0].toDataURL()!==h,walked);
 await page.getByRole('button',{name:'Nuit',exact:true}).click();
 await page.waitForFunction(()=>frames.get(0)?.includes(':nuit:'));
 assert.equal(await page.locator('#sceneTag').innerText(),'NUIT');
 if(process.argv[3])await page.screenshot({path:process.argv[3],fullPage:true});
 passes('Huit angles, images de marche successives, filtres jour/nuit actifs hors ligne');
 await page.locator('#reset').click();
 const count=await page.evaluate(async()=>{
  let count=0;
  for(const entry of lib.entries) {
   duo[0]={slug:entry.slug,ink:0};
   const img=getTex(entry.slug,false);
   if(!img)await art.get(entry.slug+':0').decode();
   frames.clear(); paint(start);
   const bare=canvases[0].toDataURL();
   duo[0].ink=1; frames.clear();paint(start);
   if (bare===canvases[0].toDataURL())throw new Error(`Pas de ruban visible : ${entry.name}`);
   count++;
  }
  return count;
 });
 assert.equal(count,86);passes('Comparaison pixel à pixel avec/sans ruban pour chacun des 86 choix');
 for(const width of [320,390,730,1024]){
  await page.setViewportSize({width,height:900});
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,`débordement ${width}`);
 }
 passes('Pas de débordement à 320, 390, 730 ni 1024 px');
 const sandbox=await browser.newPage({viewport:{width:950,height:740},reducedMotion:'reduce'});
 sandbox.on('pageerror',e=>faults.push(e.message)); sandbox.on('request',rq=>{if(/^https?:/.test(rq.url()))requests.push(rq.url());});
 await sandbox.setContent('<iframe sandbox="allow-scripts" width="900" height="730"></iframe>');
 await sandbox.locator('iframe').evaluate((el,html)=>el.srcdoc=html,fs.readFileSync(file,'utf8'));
 const frame=sandbox.frameLocator('iframe'); await frame.locator('#starter option[value="meowth_0"]').waitFor({state:'attached'});
 await frame.locator('#starter').selectOption('meowth_0');
 await frame.getByRole('button',{name:'Saphir',exact:true}).click();
 assert.equal(await frame.locator('#label0').innerText(),'Miaouss');
 assert.equal(await frame.locator('#nomCouleur').innerText(),'Saphir');
 passes('Fonctionne dans le lecteur iframe allow-scripts, sans stockage et sans réseau');
 assert.deepEqual(faults,[]);assert.deepEqual(requests,[]);passes('Zéro erreur JavaScript, zéro requête externe');
 fs.writeFileSync(path.join(base,'Verification-vestiaire.json'),JSON.stringify({statut:'PASS',verifications:controls},null,2)+'\n');
 console.log('PASS · '+controls.length+' groupes de contrôles');
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1);});
