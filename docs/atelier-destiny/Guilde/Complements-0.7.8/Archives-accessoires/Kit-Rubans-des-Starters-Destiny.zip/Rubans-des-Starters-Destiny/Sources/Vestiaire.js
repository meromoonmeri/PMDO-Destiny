'use strict';
const lib = JSON.parse(document.getElementById('banque').textContent);
const bySlug = new Map(lib.entries.map(row => [row.slug, row]));
const $ = id => document.getElementById(id);
const canvases = [$('sprite0'), $('sprite1')];
const contexts = canvases.map(c => c.getContext('2d', {alpha:true}));
const frames = new Map();
const names = ['Face', '3/4 gauche', 'Profil gauche', 'Dos gauche', 'Dos', 'Dos droit', 'Profil droit', '3/4 droit'];
const defaultDuo = () => [{slug:'pikachu_0', ink:1}, {slug:'vulpix_1', ink:4}];
let duo = defaultDuo(), active = 0, dir = 0, move = 0, light = 'jour', start = performance.now();
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
let imageStillNeeded = false;
const art = new Map();
const normalise = s => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[’']/g,' ');
const press = (list, match) => list.forEach(el => el.setAttribute('aria-pressed', String(match(el))));
const buttons = {
  actor: [...document.querySelectorAll('[data-personnage]')],
  mode: [...document.querySelectorAll('button[data-mode]')],
  light: [...document.querySelectorAll('button[data-lumiere]')],
};
function getTex(slug, night) {
  const key = `${slug}:${+night}`;
  if (!art.has(key)) {
    const img = new Image(); img.decoding = 'async';
    img.onload = () => { frames.clear(); paint(performance.now()); };
    img.src = bySlug.get(slug).img[night ? 1 : 0]; art.set(key,img);
  }
  const img = art.get(key);
  if (!img.complete || !img.naturalWidth) { imageStillNeeded = true; return null; }
  return img;
}
function stamp(ctx, palette, mask, mirror, px, py) {
  lib.masks[mask].forEach((line, y) => {
    for (let x=0; x<9; x++) {
      const code = line[mirror ? 8-x : x];
      if (code !== '.') { ctx.fillStyle = palette[Number(code)-1]; ctx.fillRect(px+x-4, py+y-3, 1, 1); }
    }
  });
}
function paint(ts) {
  imageStillNeeded = false;
  const night = light === 'nuit';
  duo.forEach((member, n) => {
    const s = bySlug.get(member.slug), ctx = contexts[n], image = getTex(member.slug, night);
    if (!image) { ctx.clearRect(0,0,64,62); return; }
    const seq = s.anim[move][dir];
    const duration = seq.reduce((a,f)=>a+f[3],0);
    let tick = (reduced.matches && move===0) ? 0 : Math.floor((ts-start)*.06) % duration;
    let f = seq[0];
    for (const next of seq) { if (tick < next[3]) { f = next; break; } tick -= next[3]; }
    const key = `${s.slug}:${member.ink}:${dir}:${move}:${light}:${f.join(',')}`;
    if (frames.get(n) === key) return;
    frames.set(n,key);
    const [tile,dx,dy,,kx,ky,mask,mirror] = f;
    const x = 32 - Math.floor(s.width/2) + dx;
    const y = 39 - Math.floor(s.height/2) + dy;
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0,0,64,62);
    ctx.drawImage(image,(tile%s.columns)*s.width,Math.floor(tile/s.columns)*s.height,s.width,s.height,x,y,s.width,s.height);
    if (member.ink) stamp(ctx,lib.palette[member.ink][night?'nuit':'c'],mask,mirror,x+kx,y+ky);
  });
}
let clock=0;
function tick(time) {
  clock = 0; paint(time);
  if (!document.hidden && (!reduced.matches || move === 1 || imageStillNeeded)) clock = requestAnimationFrame(tick);
}
function redraw() { if (!clock) clock=requestAnimationFrame(tick); }
function resetClock(){ start=performance.now(); frames.clear(); redraw(); }
document.addEventListener('visibilitychange',()=> { if (!document.hidden) redraw(); });
reduced.addEventListener('change',redraw);
function swatch(color) {
  if (!color.c.length) return `<svg viewBox="0 0 9 8" aria-hidden="true"><circle cx="4.5" cy="3.9" r="2.3" fill="none" stroke="#9788ac" stroke-width=".55"/><path d="M3 5.5 6 2.3" stroke="#9788ac" stroke-width=".6"/></svg>`;
  const pixels=lib.masks[0].map((row,y)=>[...row].map((digit,x)=>digit==='.'?'':`<rect x="${x}" y="${y}" width="1" height="1" fill="${color.c[Number(digit)-1]}"/>`).join('')).join('');
  return `<svg viewBox="0 0 9 8" aria-hidden="true">${pixels}</svg>`;
}
lib.palette.forEach((p,i)=>{
  const b=document.createElement('button'); b.type='button'; b.className='swatch'; b.dataset.encre=i;
  b.title=p.n; b.setAttribute('aria-label',p.n); b.innerHTML=swatch(p);
  const label=document.createElement('span'); label.textContent=i ? p.n.replace('Rose nacré','Rose') : 'Sans'; b.append(label);
  b.addEventListener('click',()=>{ duo[active].ink=i; sync(false); }); $('palette').append(b);
});
function writeOptions() {
  const q=normalise($('recherche').value.trim());
  const list=lib.entries.filter(s=>normalise(`${s.name} ${s.species} gen ${s.generation}`).includes(q));
  const select=$('starter'); const member=duo[active]; select.replaceChildren();
  if (!list.some(s=>s.slug===member.slug)) {
    let hint=new Option(list.length ? 'Choisir un résultat…':'Aucun résultat',''); hint.disabled=true; hint.selected=true; select.add(hint);
  }
  list.forEach(s=>select.add(new Option(s.name,s.slug,false,s.slug===member.slug)));
  select.disabled = list.length === 0;
  $('effectif').textContent=`${list.length} forme${list.length===1?'':'s'} ${q?'trouvée'+(list.length===1?'':'s'):'disponibles'}`;
}
function sync(options=true) {
  const member=duo[active], s=bySlug.get(member.slug), style=s.cut==='epaule' ? 'Attache courte à l’épaule.' : s.cut==='bas' ? 'Attache sous le col.' : 'Attache au col.';
  press(buttons.actor, e=>Number(e.dataset.personnage)===active);
  press(buttons.mode, e=>Number(e.dataset.mode)===move);
  press(buttons.light,e=>e.dataset.lumiere===light);
  press([...$('palette').children], e=>Number(e.dataset.encre)===member.ink);
  $('scene').dataset.lumiere=light; $('sceneTag').textContent=light.toUpperCase();
  $('direction').textContent=names[dir];
  $('nomCouleur').textContent=lib.palette[member.ink].n;
  $('style').textContent=style;
  duo.forEach((m,i)=>{
    $('label'+i).textContent=bySlug.get(m.slug).name;
    $('acteur'+i).setAttribute('aria-label',`${i?'Partenaire':'Héros'} : ${bySlug.get(m.slug).name}, ${lib.palette[m.ink].n}`);
  });
  if(options)writeOptions();
  $('status').textContent=`${active?'Partenaire':'Héros'} : ${s.name}. ${lib.palette[member.ink].n}. ${names[dir]}.`;
  redraw();
}
buttons.actor.forEach(b=>b.addEventListener('click',()=>{active=Number(b.dataset.personnage);$('recherche').value='';sync();}));
buttons.mode.forEach(b=>b.addEventListener('click',()=>{move=Number(b.dataset.mode);resetClock();sync(false);}));
buttons.light.forEach(b=>b.addEventListener('click',()=>{light=b.dataset.lumiere;sync(false);}));
$('recherche').addEventListener('input',writeOptions);
$('starter').addEventListener('change',()=>{ if ($('starter').value) { duo[active].slug=$('starter').value; resetClock(); sync(false); } });
$('versG').onclick=()=>{dir=(dir+1)%8;sync(false);};
$('versD').onclick=()=>{dir=(dir+7)%8;sync(false);};
$('reset').onclick=()=>{duo=defaultDuo();active=dir=move=0;light='jour';$('recherche').value='';resetClock();sync();};
sync();
