#!/usr/bin/env python3
"""Construit le patch minimal sans checkout des ressources du jeu.

Usage : python Sources/Construire-patch.py <dépôt git> <révision> <dossier-test>
Le dossier de test est créé à neuf et reçoit les seuls fichiers touchés.
"""
import argparse
from pathlib import Path
from subprocess import run, check_output

P = Path(__file__).resolve().parent
E = 'engine/RogueEssence/RogueEssence/'
L = 'game/Data/Script/destiny/'


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('repo', type=Path)
    ap.add_argument('revision')
    ap.add_argument('scratch', type=Path)
    a = ap.parse_args()
    a.scratch.mkdir(parents=True, exist_ok=False)
    git = ['git', '-C', str(a.repo), '-c', 'gc.auto=0']
    stage = ['git', '-C', str(a.scratch), '-c', 'core.autocrlf=false', '-c', 'core.safecrlf=false']
    rev = check_output(git + ['rev-parse', a.revision], text=True).strip()
    old, new = {}, {}

    def source(path):
        if path not in old:
            old[path] = check_output(git + ['show', f'{rev}:{path}'])
            new[path] = old[path].decode('utf-8')
        return new[path]

    def change(path, before, after):
        text = source(path)
        assert text.count(before) == 1, (path, before[:100], text.count(before))
        new[path] = text.replace(before, after, 1)

    def cs(file, before, after):
        change(E + file, before, after)

    char_data = 'Dungeon/Characters/CharData.cs'
    cs(char_data, '        public MonsterID BaseForm;', '''        public MonsterID BaseForm;

        // Cosmétique optionnel : champs absents des anciennes sauvegardes.
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore)]
        public string DestinyRibbonColor;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore)]
        public bool DestinyRibbonFitted;''')
    cs(char_data, '            BaseForm = other.BaseForm;', '''            BaseForm = other.BaseForm;
            DestinyRibbonColor = other.DestinyRibbonColor;
            DestinyRibbonFitted = other.DestinyRibbonFitted;''')

    sheet = 'Content/CharSheet.cs'
    cs(sheet, '        private CharSheet destinyNightCopy;', '''        private CharSheet destinyNightCopy;
        private bool destinyNightGraded;
        private byte[] destinyRibbonAlpha;
        private Dictionary<(int, Dir8, bool, DestinyRibbon.Fit), DestinyRibbon.Pose> destinyRibbonPoses;

        internal DestinyRibbon.Pose GetDestinyRibbonPose(CharAnimFrame frame, Dir8 dir, DestinyRibbon.Fit cut)
        {
            int index = frame.Frame.Y * TotalX + frame.Frame.X;
            if ((uint)frame.Frame.X >= (uint)TotalX || (uint)frame.Frame.Y >= (uint)TotalY || (uint)index >= (uint)OffsetData.Count)
                return DestinyRibbon.Pose.None;

            var key = (index, dir, frame.Flip, cut);
            destinyRibbonPoses ??= new Dictionary<(int, Dir8, bool, DestinyRibbon.Fit), DestinyRibbon.Pose>();
            if (destinyRibbonPoses.TryGetValue(key, out var pose))
                return pose;
            if (destinyRibbonAlpha == null)
            {
                // One read per sheet while cached, never a GPU read per draw.
                Color[] pixels = new Color[Width * Height];
                baseTexture.GetData(pixels);
                destinyRibbonAlpha = new byte[pixels.Length];
                for (int ii = 0; ii < pixels.Length; ii++)
                    destinyRibbonAlpha[ii] = pixels[ii].A;
            }
            int start = frame.Frame.Y * TileHeight * Width + frame.Frame.X * TileWidth;
            pose = DestinyRibbon.Place(destinyRibbonAlpha, Width, start, TileWidth, TileHeight,
                OffsetData[index], frame.Flip, dir, cut);
            destinyRibbonPoses[key] = pose;
            return pose;
        }''')
    cs(sheet, '            base.Dispose();\n        }\n\n        /// <summary>\n        /// Creates an independent GPU sheet', '''            destinyRibbonAlpha = null;
            destinyRibbonPoses = null;
            base.Dispose();
        }

        /// <summary>
        /// Creates an independent GPU sheet''')
    start = '            for (int ii = 0; ii < pixels.Length; ii++)\n            {\n                Color pixel = pixels[ii];'
    end = '            return new CharSheet(texture, TileWidth, TileHeight, ShadowSize, AnimData, OffsetData);\n        }'
    text = source(E + sheet)
    before = text[text.index(start):text.index(end) + len(end)]
    formula = before[before.index('                // CharSheet PNGs'):before.index('                pixels[ii] = new Color(nr')]
    formula = '\n'.join(line[4:] for line in formula.splitlines())
    cs(sheet, before, '''            for (int ii = 0; ii < pixels.Length; ii++)
                pixels[ii] = DestinyNightGrade(pixels[ii]);
            Texture2D texture = new Texture2D(device, Width, Height);
            texture.SetData(pixels);
            return new CharSheet(texture, TileWidth, TileHeight, ShadowSize, AnimData, OffsetData) { destinyNightGraded = true };
        }

        internal static Color DestinyNightGrade(Color pixel)
        {
            int alpha = pixel.A;
            if (alpha == 0)
                return pixel;

''' + formula + '''
            return new Color(nr * alpha / 255, ng * alpha / 255, nb * alpha / 255, alpha);
        }''')
    signature = '        public void DrawChar(SpriteBatch spriteBatch, int type, bool truncateDash, Dir8 dir, Vector2 pos, DetermineFrame frameMethod, Color color)'
    cs(sheet, signature + '\n        {', signature + '''
        {
            DrawChar(spriteBatch, type, truncateDash, dir, pos, frameMethod, color, default);
        }

        internal void DrawChar(SpriteBatch spriteBatch, int type, bool truncateDash, Dir8 dir, Vector2 pos, DetermineFrame frameMethod, Color color, DestinyRibbon.Wear ribbon)
        {''')
    from_draw = '                DrawTile(spriteBatch, pos + adjustedOffset.ToVector2(), frame.Frame.X, frame.Frame.Y, color, frame.Flip ? SpriteEffects.FlipHorizontally : SpriteEffects.None);'
    # DrawCharFrame has its own DrawTile. Only the animated draw path is decorated.
    cs(sheet, from_draw + '\n            }\n            else\n                DrawDefault(spriteBatch, new Rectangle((int)pos.X, (int)pos.Y, TileWidth, TileHeight));\n        }\n        /// <summary>', '''                Vector2 frameTopLeft = pos + adjustedOffset.ToVector2();
                DrawTile(spriteBatch, frameTopLeft, frame.Frame.X, frame.Frame.Y, color, frame.Flip ? SpriteEffects.FlipHorizontally : SpriteEffects.None);
                if (ribbon.Ink > 0 && color.A > 0)
                    DestinyRibbon.Draw(spriteBatch, frameTopLeft, GetDestinyRibbonPose(frame, dir, ribbon.Cut), color, ribbon, destinyNightGraded);
            }
            else
                DrawDefault(spriteBatch, new Rectangle((int)pos.X, (int)pos.Y, TileWidth, TileHeight));
        }
        /// <summary>''')

    ground_action = 'Ground/GroundAction.cs'
    for kind, flag, newkind in [('virtual', 'true', 'virtual'), ('override', 'false', 'override')]:
        start = f'        public {kind} void Draw(SpriteBatch spriteBatch, Loc offset, CharSheet sheet, Microsoft.Xna.Framework.Color tint)\n        {{'
        code = '''
            Loc drawLoc = GetDrawLoc(offset, sheet);
            drawLoc.Y -= LocHeight;
            //draw sprite at current frame
'''
        paint = f'            sheet.DrawChar(spriteBatch, AnimFrameType, {flag}, DirExt.AddAngles(CharDir, dirOffset), drawLoc.ToVector2(), FrameMethod, tint * ((float)opacity / 255));'
        if kind == 'virtual':
            old_body = start + code + paint + '\n        }'
            bridge = start + '''
            Draw(spriteBatch, offset, sheet, tint, default);
        }

'''
        else:
            old_body = start + code + paint + '\n        }'
            bridge = ''
        new_body = f'        internal {newkind} void Draw(SpriteBatch spriteBatch, Loc offset, CharSheet sheet, Microsoft.Xna.Framework.Color tint, DestinyRibbon.Wear ribbon)\n        {{' + code + paint[:-2] + ', ribbon);\n        }'
        cs(ground_action, old_body, bridge + new_body)

    cs('Ground/GroundChar.cs', '            currentCharAction.Draw(spriteBatch, offset, sheet, tint);', '''            DestinyRibbon.Wear ribbon = DestinyRibbon.From(Data, CurrentForm);
            if (ribbon.Ink == 0)
                currentCharAction.Draw(spriteBatch, offset, sheet, tint);
            else
                currentCharAction.Draw(spriteBatch, offset, sheet, tint, ribbon);''')

    action = 'Dungeon/Characters/CharAction.cs'
    cs(action, '        public virtual void Draw(SpriteBatch spriteBatch, Loc offset, CharSheet sheet) { currentAnim.Draw(spriteBatch, offset, sheet); }', '''        public virtual void Draw(SpriteBatch spriteBatch, Loc offset, CharSheet sheet) { Draw(spriteBatch, offset, sheet, default); }
        internal virtual void Draw(SpriteBatch spriteBatch, Loc offset, CharSheet sheet, DestinyRibbon.Wear ribbon) { currentAnim.Draw(spriteBatch, offset, sheet, ribbon); }''')
    cs(action, '''        public override void Draw(SpriteBatch spriteBatch, Loc offset, CharSheet sheet)
        {
            base.Draw(spriteBatch, offset, sheet);
            foreach (Hitbox hitbox in hitboxes)''', '''        internal override void Draw(SpriteBatch spriteBatch, Loc offset, CharSheet sheet, DestinyRibbon.Wear ribbon)
        {
            base.Draw(spriteBatch, offset, sheet, ribbon);
            foreach (Hitbox hitbox in hitboxes)''')

    anim = 'Dungeon/Characters/CharAnimation.cs'
    sig = '        public void Draw(SpriteBatch spriteBatch, Loc offset, CharSheet sheet)\n        {'
    cs(anim, sig, sig + '''
            Draw(spriteBatch, offset, sheet, default);
        }

        internal void Draw(SpriteBatch spriteBatch, Loc offset, CharSheet sheet, DestinyRibbon.Wear ribbon)
        {''')
    cs(anim, 'drawLoc.ToVector2(), determineFrame, Microsoft.Xna.Framework.Color.White * ((float)opacity / 255));', 'drawLoc.ToVector2(), determineFrame, Microsoft.Xna.Framework.Color.White * ((float)opacity / 255), ribbon);')

    character = 'Dungeon/Characters/Character.cs'
    cs(character, '            character.BaseForm = this.BaseForm;', '''            character.BaseForm = this.BaseForm;
            character.DestinyRibbonColor = this.DestinyRibbonColor;
            character.DestinyRibbonFitted = this.DestinyRibbonFitted;''')
    cs(character, '            currentCharAction.Draw(spriteBatch, offset, sheet);', '''            // Preserve the disguise: its cosmetic cannot reveal the real wearer.
            DestinyRibbon.Wear ribbon = Appearance == CurrentForm ? DestinyRibbon.From(this, Appearance) : default;
            if (ribbon.Ink == 0)
                currentCharAction.Draw(spriteBatch, offset, sheet);
            else
                currentCharAction.Draw(spriteBatch, offset, sheet, ribbon);''')

    cs('Lua/LuaEngine.cs', '            CacheMainScripts();', '''            Content.DestinyRibbon.ResetRoster();
            CacheMainScripts();''')
    cs('Menu/Team/TeamChosenMenu.cs', '            choices.Add(new MenuTextChoice(Text.FormatKey("MENU_EXIT"), ExitAction));', '''            Character ribbonMember = DataManager.Instance.Save.ActiveTeam.Players[teamSlot];
            if (inGround && DataManager.Instance.CurrentReplay == null && DestinyRibbon.CanChoose(ribbonMember))
                choices.Add(new MenuTextChoice("Ruban", () => MenuManager.Instance.AddMenu(new DestinyRibbonMenu(ribbonMember), true)));

            choices.Add(new MenuTextChoice(Text.FormatKey("MENU_EXIT"), ExitAction));''')

    quiz = L + 'ground/personality_test/init.lua'
    change(quiz, "local starters_source = require 'destiny.ground.personality_test.starters_source'", "local starter_pool = require 'destiny.starter_pool'")
    txt = source(quiz)
    full_pool = txt[txt.index('-- Réunit les choix source'):txt.index('-- Le menu de sélection natif')]
    change(quiz, full_pool, 'local construire_pool = starter_pool.construire\n\n')
    main_lua = L + 'main.lua'
    text = source(main_lua)
    new[main_lua] = text.rstrip() + "\n-- Vestiaire : le quiz fournit exactement les mêmes couples espèce/forme.\nrequire('destiny.rubans').installer()\n"

    for f in sorted((P / 'engine').rglob('*.cs')):
        new[E + f.relative_to(P / 'engine').as_posix()] = f.read_text(encoding='utf-8')
    for f in sorted((P / 'game').rglob('*.lua')):
        new['game/' + f.relative_to(P / 'game').as_posix()] = f.read_text(encoding='utf-8')
    run(stage + ['init', '-q'], check=True)
    for path, data in old.items():
        dest = a.scratch / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
    run(stage + ['add', '--', *old], check=True)
    run(stage + ['-c', 'user.name=Contrôle local', '-c', 'user.email=local@example.invalid', 'commit', '-q', '-m', 'Base Destiny contrôlée'], check=True)
    for path, text in new.items():
        dest = a.scratch / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(text.encode('utf-8'))
    run(stage + ['add', '-N', '--', *new], check=True)
    run(stage + ['diff', '--check', 'HEAD'], check=True)
    out = P.parent / 'Rubans-Destiny.patch'
    out.write_bytes(check_output(stage + ['-c', 'color.ui=false', 'diff', '--no-ext-diff', '--full-index', '--binary', 'HEAD']))
    run(stage + ['apply', '-R', '--check', str(out)], check=True)
    run(stage + ['apply', '-R', str(out)], check=True)
    run(stage + ['apply', '--check', str(out)], check=True)
    run(stage + ['apply', str(out)], check=True)
    for path, text in new.items():
        assert (a.scratch / path).read_bytes() == text.encode('utf-8'), path
    print(f'Patch vérifié par aller-retour : {len(new)} fichiers sur {rev}.')


if __name__ == '__main__':
    main()
