-- Profils de pose seulement : jamais de filtre d'éligibilité supplémentaire.
local pool = require 'destiny.starter_pool'
local M = {}
local epaule = {
  rowlet=true, snom=true, beldum=true, joltik=true, applin=true, cosmog=true,
  phanpy=true, larvesta=true, litwick=true, goomy=true, togepi=true,
  fidough=true, budew=true, rookidee=true,
}
local col_bas = { tepig=true, squirtle=true }

function M.installer()
  -- Permet de passer du script seul à une build moteur complète sans
  -- casser le lancement d'une ancienne édition portant les mêmes scripts.
  local ok, moteur = pcall(luanet.import_type, 'RogueEssence.Content.DestinyRibbon')
  if not ok or moteur == nil then return end
  for _, s in ipairs(pool.construire(nil)) do
    local coupe = epaule[s.espece] and 'epaule' or (col_bas[s.espece] and 'bas' or 'col')
    moteur.RegisterStarter(s.espece, s.forme, coupe)
  end
end

return M
