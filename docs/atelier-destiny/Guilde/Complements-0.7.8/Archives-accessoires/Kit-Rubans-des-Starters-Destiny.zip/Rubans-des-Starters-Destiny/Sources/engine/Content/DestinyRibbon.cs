using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using RogueElements;
using RogueEssence.Data;
using RogueEssence.Dungeon;

namespace RogueEssence.Content
{
    /// <summary>Vestiaire cosmétique de Destiny. Aucun objet, skin ou état de combat.</summary>
    public static class DestinyRibbon
    {
        internal enum Fit { Collar, Shoulder, LowCollar }
        internal readonly struct Wear
        {
            // Index 0 = aucun ruban. Le code sauvegardé est stable même si l'ordre du menu change.
            public readonly int Ink;
            public readonly Fit Cut;
            public Wear(int ink, Fit cut) { Ink = ink; Cut = cut; }
        }

        internal sealed class Shade
        {
            public readonly string Key;
            public readonly string Name;
            public readonly Color[] Ink;
            public Shade(string key, string name, params int[] rgb)
            {
                Key = key;
                Name = name;
                Ink = Array.ConvertAll(rgb, c => new Color(c >> 16, (c >> 8) & 255, c & 255));
            }
        }

        // Liseré, pli, tissu, lumière ; rampe dessinée, pas un aplat teinté.
        internal static readonly Shade[] Colors = {
            new Shade(null, "Sans ruban"),
            new Shade("garance", "Garance", 0x4A2033, 0xA43148, 0xDF5C65, 0xFFAE93),
            new Shade("ambre", "Ambre", 0x5C3327, 0xB76635, 0xE7A14A, 0xFFE3A0),
            new Shade("emeraude", "Émeraude", 0x203C37, 0x337C58, 0x63B67A, 0xC8E59B),
            new Shade("lagon", "Lagon", 0x213948, 0x27878C, 0x51C1BC, 0xB4F1E1),
            new Shade("saphir", "Saphir", 0x253052, 0x405BB2, 0x6B8DDC, 0xBFD8FF),
            new Shade("lilas", "Lilas", 0x45304E, 0x8558A3, 0xB487D6, 0xEBD9FA),
            new Shade("rose", "Rose nacré", 0x5A2D48, 0xAF557E, 0xE681A3, 0xFFCFD6),
            new Shade("ivoire", "Ivoire", 0x5B4842, 0xB59476, 0xF2DCAC, 0xFFF5D9),
            new Shade("encre", "Encre", 0x201A30, 0x4E4565, 0x746789, 0xC2ACCC),
        };

        private static readonly Dictionary<(string species, int form), Fit> Roster =
            new Dictionary<(string, int), Fit>();
        internal static void ResetRoster() => Roster.Clear();

        // Appelé par destiny/main.lua à partir de la même liste que le quiz.
        public static void RegisterStarter(string species, int form, string cut)
        {
            if (String.IsNullOrEmpty(species) || form < 0)
                return;
            Roster[(species, form)] = cut == "epaule" ? Fit.Shoulder : cut == "bas" ? Fit.LowCollar : Fit.Collar;
        }

        private static Fit GetFit(MonsterID id) => Roster.TryGetValue((id.Species, id.Form), out Fit fit) ? fit : Fit.Collar;

        // Un fondateur déjà évolué sur une ancienne sauvegarde reste éligible.
        // Un starter recruté garde l'accès après évolution s'il a porté un ruban.
        internal static bool CanChoose(CharData member)
        {
            return Roster.Count > 0 && member != null && (DataManager.Instance?.Save is MainProgress)
                && (Roster.ContainsKey((member.BaseForm.Species, member.BaseForm.Form))
                    || member.DestinyRibbonFitted || (member.IsFounder && member.IsPartner));
        }

        internal static bool TrySet(CharData member, int index)
        {
            if (!CanChoose(member) || index < 0 || index >= Colors.Length)
                return false;
            member.DestinyRibbonColor = Colors[index].Key;
            member.DestinyRibbonFitted |= index > 0;
            return true;
        }

        internal static int IndexOf(string key)
        {
            if (String.IsNullOrEmpty(key))
                return 0;
            for (int ii = 1; ii < Colors.Length; ii++)
                if (String.Equals(key, Colors[ii].Key, StringComparison.Ordinal))
                    return ii;
            return 0;
        }

        internal static Wear ForPreview(MonsterID visible, int ink) => new Wear(ink, GetFit(visible));

        internal static Wear From(CharData wearer, MonsterID visible)
        {
            if (wearer == null || String.IsNullOrEmpty(wearer.DestinyRibbonColor) || !CanChoose(wearer))
                return default;
            return ForPreview(visible, IndexOf(wearer.DestinyRibbonColor));
        }

        // Masques de tissu distincts : face, trois-quarts/profil, dos et petite attache.
        // Le nœud reste exactement au repère (4,3), même après miroir.
        internal const int StampW = 9;
        internal const int StampH = 8;
        internal const int KnotX = 4;
        internal const int KnotY = 3;
        internal static readonly string[][] Masks = {
            new[] { ".........", ".11...11.", ".143.341.", ".1234321.", "..11211..", "...3.2...", "..31.21..", "........." },
            new[] { ".........", ".....11..", "..11.341.", "..134321.", "...1211..", "....23...", ".....31..", "........." },
            new[] { ".........", "..1...1..", ".133.331.", ".1234321.", "..12221..", "..31.13..", "..1...1..", "........." },
            new[] { ".........", ".........", "..11.11..", "..13431..", "...121...", "...3.2...", "..1..1...", "........." },
            new[] { ".........", ".........", ".....11..", "...1431..", "...121...", "....23...", ".....1...", "........." },
            new[] { ".........", ".........", "..1...1..", "..13431..", "...121...", "..31.13..", ".........", "........." },
        };

        internal readonly struct Pose
        {
            public readonly int X;
            public readonly int Y;
            public readonly int Mask;
            public readonly bool Mirror;
            public bool Exists => Mask >= 0;
            public Pose(int x, int y, int mask, bool mirror) { X = x; Y = y; Mask = mask; Mirror = mirror; }
            public static readonly Pose None = new Pose(0, 0, -1, false);
        }

        /// <summary>
        /// Pose calculée sur la tuile affichée (et non sur le monstre immobile) :
        /// repères natifs tête/centre, masque opaque et perspective. Pas d'ancrage hors du corps.
        /// </summary>
        internal static Pose Place(byte[] alpha, int stride, int start, int w, int h, OffsetData anchor,
            bool flip, Dir8 dir, Fit cut)
        {
            if (w < 1 || h < 1 || anchor == null)
                return Pose.None;

            int l = w, t = h, r = -1, b = -1;
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                    if (alpha[start + y * stride + x] >= 64)
                    {
                        l = Math.Min(l, x);
                        r = Math.Max(r, x);
                        t = Math.Min(t, y);
                        b = Math.Max(b, y);
                    }
            if (r < l)
                return Pose.None;
            if (flip)
                (l, r) = (w - 1 - r, w - 1 - l);

            Loc center = flip ? anchor.CenterFlip : anchor.Center;
            Loc head = flip ? anchor.HeadFlip : anchor.Head;
            int cx = Math.Clamp(center.X + w / 2, l, r);
            int cy = Math.Clamp(center.Y + h / 2, t, b);
            int hx = Math.Clamp(head.X + w / 2, l, r);
            int hy = Math.Clamp(head.Y + h / 2, t, b);
            int sizeY = b - t + 1;
            int sizeX = r - l + 1;
            int d = (int)dir & 7;
            bool front = d == 0 || d == 1 || d == 7;
            bool back = d == 4;
            bool side = !back && d != 0;
            bool mirror = d >= 5;
            bool shoulder = cut == Fit.Shoulder;
            bool small = shoulder || sizeX <= 13 || sizeY <= 14;
            int targetX = (3 * cx + hx + 2) / 4;
            int targetY;
            if (shoulder)
            {
                // Broche d'épaule sur les espèces sans col ; préserve la feuille de Brindibou,
                // la grande pupille de Terhal et le visage court de Frissonille.
                targetX = cx + (back ? -1 : 1) * Math.Clamp(sizeX / (side ? 13 : 6), 1, 4) * (mirror ? -1 : 1);
                targetY = Math.Max(cy + 1, t + sizeY * (back ? 4 : 6) / 10);
            }
            else if (front && !side)
            {
                targetY = Math.Max(Math.Max(cy, hy) + 1, t + sizeY * 61 / 100);
                if (cut == Fit.LowCollar)
                    targetY++;
            }
            else if (back)
            {
                targetY = (cy * 3 + hy) / 4 + 1;
                targetY = Math.Max(targetY, t + sizeY * 43 / 100);
            }
            else
            {
                targetY = (cy * 2 + hy + 1) / 3 + Math.Clamp(sizeY / 12, 1, 3);
                if (front && cut == Fit.LowCollar)
                    targetY++;
                targetY = Math.Max(targetY, t + sizeY * (front ? 54 : 44) / 100);
            }
            // Le nœud ne tombe pas sur le dernier pixel d'un pied. Les pans
            // peuvent dépasser légèrement de la silhouette comme du tissu.
            targetY = Math.Clamp(targetY, t, Math.Max(t, b - (small ? 2 : 3)));
            targetX = Math.Clamp(targetX, l, r);

            int best = Int32.MaxValue, bestX = 0, bestY = 0;
            for (int y = t; y <= b; y++)
                for (int x = l; x <= r; x++)
                {
                    if (ReadAlpha(alpha, stride, start, w, h, x, y, flip) < 64)
                        continue;
                    int dx = x - targetX, dy = y - targetY;
                    int score = 5 * dx * dx + (dy < 0 && front ? 13 : 8) * dy * dy;
                    if (ReadAlpha(alpha, stride, start, w, h, x, y - 1, flip) < 64) score += 11;
                    if (ReadAlpha(alpha, stride, start, w, h, x, y + 1, flip) < 64) score += 9;
                    if (ReadAlpha(alpha, stride, start, w, h, x + 1, y, flip) < 64) score += 5;
                    if (ReadAlpha(alpha, stride, start, w, h, x - 1, y, flip) < 64) score += 5;
                    if (score < best)
                    {
                        best = score;
                        bestX = x;
                        bestY = y;
                    }
                }
            int mask = (small ? 3 : 0) + (back ? 2 : side ? 1 : 0);
            return best == Int32.MaxValue ? Pose.None : new Pose(bestX, bestY, mask, mirror);
        }

        private static byte ReadAlpha(byte[] alpha, int stride, int start, int w, int h, int x, int y, bool flip)
        {
            if ((uint)x >= (uint)w || (uint)y >= (uint)h)
                return 0;
            return alpha[start + y * stride + (flip ? w - 1 - x : x)];
        }

        private static Texture2D atlas;
        private static Texture2D Atlas(GraphicsDevice device)
        {
            if (atlas != null && !atlas.IsDisposed && atlas.GraphicsDevice == device)
                return atlas;
            atlas?.Dispose();
            int width = StampW * Masks.Length;
            int height = StampH * Colors.Length * 2;
            Color[] pixels = new Color[width * height];
            for (int night = 0; night < 2; night++)
                for (int ink = 1; ink < Colors.Length; ink++)
                    for (int mask = 0; mask < Masks.Length; mask++)
                        for (int y = 0; y < StampH; y++)
                            for (int x = 0; x < StampW; x++)
                            {
                                char code = Masks[mask][y][x];
                                if (code == '.')
                                    continue;
                                Color c = Colors[ink].Ink[code - '1'];
                                pixels[((night * Colors.Length + ink) * StampH + y) * width + mask * StampW + x] =
                                    night == 1 ? CharSheet.DestinyNightGrade(c) : c;
                            }
            atlas = new Texture2D(device, width, height);
            atlas.SetData(pixels);
            return atlas;
        }

        internal static void Draw(SpriteBatch batch, Vector2 frameTopLeft, Pose pose, Color tint, Wear wear, bool night)
        {
            if (!pose.Exists || wear.Ink <= 0 || wear.Ink >= Colors.Length || tint.A == 0)
                return;
            Rectangle src = new Rectangle(pose.Mask * StampW, (wear.Ink + (night ? Colors.Length : 0)) * StampH, StampW, StampH);
            Vector2 loc = frameTopLeft + new Vector2(pose.X - KnotX, pose.Y - KnotY);
            batch.Draw(Atlas(batch.GraphicsDevice), loc, src, tint, 0f, Vector2.Zero, 1f,
                pose.Mirror ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 0f);
        }
    }
}
