#!/usr/bin/env python3
"""Vérifie les fichiers de base de Destiny avant un remplacement volontaire."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('depot',type=Path,help='racine de PMDO-Destiny, celle qui contient le dossier game')
    p.add_argument('--appliquer',action='store_true',help='copier les fichiers graphiques après vérification')
    args=p.parse_args()
    root=args.depot.resolve()
    control=json.loads((HERE/'Controle.json').read_text(encoding='utf-8'))
    jobs=[]; errors=[]; done=0
    for line in control['fichiers_moteur']:
        f=line['fichier']; target=root/f; source=HERE/'Moteur'/f
        if not source.is_file() or sha(source)!=line['retouche_sha256']:
            errors.append('Archive incomplète ou altérée : '+f); continue
        if not target.is_file():
            errors.append('Fichier Destiny manquant : '+f); continue
        old=sha(target)
        if old==line['retouche_sha256']:
            done+=1; continue
        if old!=line['base_sha256']:
            errors.append('Version incompatible, fichier non remplacé : '+f); continue
        jobs.append((source,target))
    if errors:
        print('\n'.join(errors))
        raise SystemExit('Aucune copie. Base requise : '+control['reference'])
    if not args.appliquer:
        print(f'Version compatible : {len(jobs)} fichiers prêts, {done} déjà retouchés. Rien n’a été copié.')
        return
    for source,target in jobs:
        shutil.copyfile(source,target)
    print(f'{len(jobs)} fichiers graphiques copiés. Exécuter python tools/build_tile_index.py depuis le dépôt avant de lancer le jeu.')


if __name__=='__main__':
    main()
