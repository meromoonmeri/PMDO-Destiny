# Guilde Destiny · Finition native

Ce lot repart des **15 cartes de charpente Destiny** du commit `9feecc86355a9e7346e07f6bb2f80ec5102f2bcd` (*Reconstruit les quinze salles de la Guilde sans mobilier*). Il ne contient aucune carte redessinée ou générée ni aucun élément emprunté à une autre guilde.

- **Bois plus net** : léger renforcement des détails des pixels d’origine, à résolution identique. Les volumes, couleurs dominantes, fenêtres, sculptures de charpente et escaliers restent ceux de Destiny.
- **Sorties basses raccordées** : neuf passages prolongés jusqu’à la limite de leur image, avec le bois et le pas des marches d’origine. Les passages latéraux qui touchaient déjà les bords restent en place. L’ombre au fond des arches est volontaire.
- **Aucun changement de déplacement** : mêmes positions de seuils, collisions, marqueurs et destinations. Les prolongements au-delà des capteurs sont visuels. Les deux états de la porte et les quatre ambiances du jeu sont conservés.

## Voir les images

`Voir-la-guilde.html` compare l’original et la retouche hors ligne. `PNG/Jour` et `PNG/Nuit` contiennent les cartes PNG à leur définition native, avec en plus la porte ouverte du Grand Salon dans chaque ambiance (32 PNG).

## Lot moteur facultatif

`Moteur/game` contient les quinze planches `.tile` et les quinze `.rsground` correspondants. Dans les `.rsground`, seules les grilles de références graphiques ont été remplacées. N’appliquez pas le paquet sur une autre refonte ou une révision antérieure sans vérifier sa compatibilité.

Sur une copie de travail **ayant la charpente `9feecc8`** :

```sh
python Preparer-la-finition.py "/chemin/vers/PMDO-Destiny"
python Preparer-la-finition.py "/chemin/vers/PMDO-Destiny" --appliquer
cd "/chemin/vers/PMDO-Destiny"
python tools/build_tile_index.py
```

La première commande ne copie rien. Les empreintes dans `Controle.json` empêchent la copie si les fichiers de base ne correspondent pas. Aucun changement de scripts, de zone, de publication ni de release n’a été fait.

Contrôles : rendu PNG original reproduit pixel pour pixel, rendu des nouvelles planches relu à l’échelle 1:1, continuité des 9 sorties jusqu’au bord, et contrat des 29 seuils conservé. Le paquet n’est pas un exécutable de jeu.
