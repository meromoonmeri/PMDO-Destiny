[CmdletBinding()]
param(
    [ValidateSet('Installer','Restaurer','Verifier')][string]$Action = 'Installer',
    [string]$Dossier
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2

function Resource([string]$Folder, [string]$Relative) {
    Join-Path $Folder $Relative.Replace('/',[IO.Path]::DirectorySeparatorChar)
}
function Digest([string]$Path) {
    if (!(Test-Path -LiteralPath $Path -PathType Leaf)) { throw "Fichier absent : $Path" }
    (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}
function AbsentOrDigest([string]$Path) {
    if (Test-Path -LiteralPath $Path -PathType Leaf) { Digest $Path }
    else { '' }
}

function Assert-Index([string]$Root, $TileRows) {
    # Verify the six nodes against the *installed* index, not just its filename.
    # Allows an index of the same release built on another machine.
    $guide = @{}
    foreach ($row in $TileRows) {
        $path = Resource $Root $row.path
        $stream = [IO.File]::OpenRead($path)
        $fs = New-Object IO.BinaryReader $stream
        try {
            $size = $fs.ReadInt32()
            $count = $fs.ReadInt32()
            if ($size -ne 8 -or $count -lt 1 -or (8L + 16L * $count) -gt $stream.Length) { throw "Entete invalide : $path" }
            $stream.Position = 0
            $key = [IO.Path]::GetFileNameWithoutExtension($path)
            $guide[$key] = [Convert]::ToBase64String($fs.ReadBytes(8 + 16 * $count))
        } finally { $fs.Dispose() }
    }
    $path = Resource $Root 'Content/Tile/index.idx'
    if (!(Test-Path -LiteralPath $path -PathType Leaf)) { throw "Index du jeu introuvable : $path" }
    $stream = [IO.File]::OpenRead($path)
    $fs = New-Object IO.BinaryReader $stream
    try {
        $sheets = $fs.ReadInt32()
        if ($sheets -lt $guide.Count -or $sheets -gt 20000) { throw 'Index de tuiles invalide.' }
        for ($i = 0; $i -lt $sheets; $i++) {
            $key = $fs.ReadString()
            $start = $stream.Position
            $size = $fs.ReadInt32()
            $count = $fs.ReadInt32()
            $end = $stream.Position + 16L * $count
            if ($size -lt 1 -or $count -lt 0 -or $end -gt $stream.Length) { throw 'Index de tuiles tronque.' }
            if ($guide.ContainsKey($key)) {
                $stream.Position = $start
                $actual = [Convert]::ToBase64String($fs.ReadBytes(8 + 16 * $count))
                if ($actual -cne $guide[$key]) { throw "Index incompatible pour $key." }
                $guide.Remove($key)
            } else { $stream.Position = $end }
        }
        if ($guide.Count -ne 0 -or $stream.Position -ne $stream.Length) { throw 'Index incomplet ou incompatible.' }
    } finally { $fs.Dispose() }
}

function Replace-Verified([string]$Source, [string]$Destination, [string]$Sha) {
    $dir = [IO.Path]::GetDirectoryName($Destination)
    $tmp = Join-Path $dir ('.fenetres-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    try {
        [IO.File]::Copy($Source,$tmp,$false)
        if ((Digest $tmp) -cne $Sha) { throw "Copie non conforme : $Source" }
        # Atomic rename into the existing path, on its own filesystem.
        [IO.File]::Replace($tmp,$Destination,[System.Management.Automation.Language.NullString]::Value,$true)
    } finally {
        if ([IO.File]::Exists($tmp)) { [IO.File]::Delete($tmp) }
    }
}

$lock = $null
$transition = $null
$keepTransition = $false
try {
    $bundle = $PSScriptRoot
    $manifest = Get-Content -LiteralPath (Join-Path $bundle 'Manifeste.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $rows = @($manifest.assets)
    if ($manifest.version -cne '0.7.7' -or $manifest.revision -ne 2 -or $rows.Count -ne 10 -or @($rows.path | Select-Object -Unique).Count -ne 10) { throw 'Manifeste du correctif invalide.' }
    foreach ($r in $rows) {
        if ($r.path -cnotmatch '^Content/(Tile/Destiny_Guilde_(Bureau_Maitre|Refectoire|Cuisine|Dortoir_Nord_[12]|Chambre_Heros)\.tile|Object/Guilde_Fenetre_05_refectoire_Droite_(Jour|Aube|Crepuscule|Nuit)\.dir)$' -or $r.avant_sha256 -cnotmatch '^[0-9a-f]{64}$' -or $r.apres_sha256 -cnotmatch '^[0-9a-f]{64}$' -or $r.precedent_sha256 -cnotmatch '^[0-9a-f]{64}$') { throw 'Chemin ou empreinte non autorises dans le manifeste.' }
    }
    if ([string]::IsNullOrWhiteSpace($Dossier)) {
        Write-Host 'PMD Destiny 0.7.7 - correctif des fenetres de la guilde - finition R2'
        Write-Host 'Fermez le jeu avant de continuer.'
        $Dossier = Read-Host 'Collez le chemin du dossier contenant Destiny.exe (Entree vide = annuler)'
        if ([string]::IsNullOrWhiteSpace($Dossier)) { exit 0 }
    }
    $homePath = (Resolve-Path -LiteralPath $Dossier.Trim().Trim('"') -ErrorAction Stop).ProviderPath
    $exe = Join-Path $homePath 'Destiny.exe'
    if (!(Test-Path -LiteralPath $exe -PathType Leaf) -or !(Test-Path -LiteralPath (Join-Path $homePath 'Data') -PathType Container)) { throw 'Choisissez le dossier qui contient Destiny.exe et les dossiers Content et Data.' }
    if ($env:OS -eq 'Windows_NT' -and $Action -ne 'Verifier') {
        $running = @(Get-Process -Name Destiny -ErrorAction SilentlyContinue)
        if ($running.Count) { throw 'Destiny est ouvert. Fermez le jeu puis relancez ce correctif.' }
    }
    $payload = Join-Path $bundle 'Correctif'
    $backup = Join-Path $homePath '.sauvegarde-fenetres-0.7.7'
    foreach ($r in $rows) {
        if ((Digest (Resource $payload $r.path)) -cne $r.apres_sha256) { throw "Correctif incomplet ou modifie : $($r.path). Extrayez a nouveau le dossier ZIP entier." }
    }
    if ($Action -eq 'Restaurer' -and !(Test-Path -LiteralPath $backup -PathType Container)) { throw "Aucune sauvegarde a restaurer : $backup" }
    # Check both the tile index and every file before writing anything to Content.
    Assert-Index $homePath @($rows | Where-Object { $_.path.StartsWith('Content/Tile/') })
    function Read-State {
        $state = @{}
        foreach ($r in $rows) {
            $dst = Resource $homePath $r.path
            $sha = Digest $dst
            if ($sha -cne $r.avant_sha256 -and $sha -cne $r.apres_sha256 -and $sha -cne $r.precedent_sha256) {
                throw "Ressource differente de la version Windows 0.7.7 attendue : $($r.path). Aucun fichier de jeu ne sera remplace."
            }
            $state[$r.path] = $sha
        }
        return $state
    }
    $state = Read-State
    if ($Action -eq 'Verifier') {
        $ready = @($rows | Where-Object { $state[$_.path] -ceq $_.apres_sha256 }).Count
        Write-Host "Compatible. $ready/$($rows.Count) ressources deja corrigees."
        exit 0
    }
    [IO.Directory]::CreateDirectory($backup) | Out-Null
    $lock = [IO.File]::Open((Join-Path $backup '.verrou'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $state = Read-State
    foreach ($r in $rows) {
        $copy = Resource $backup $r.path
        $saved = AbsentOrDigest $copy
        if ($saved -and $saved -cne $r.avant_sha256) { throw "Sauvegarde modifiee : $copy. Rien n'a ete remplace dans Content." }
        if (!$saved -and ($Action -eq 'Restaurer' -or $state[$r.path] -cne $r.avant_sha256)) {
            throw "Sauvegarde d'origine introuvable : $copy. Rien n'a ete remplace dans Content."
        }
    }
    foreach ($r in $rows) {
        $copy = Resource $backup $r.path
        if (!(Test-Path -LiteralPath $copy -PathType Leaf)) {
            $parent = [IO.Path]::GetDirectoryName($copy)
            [IO.Directory]::CreateDirectory($parent) | Out-Null
            $temporary = Join-Path $parent ('.original-' + [Guid]::NewGuid().ToString('N') + '.tmp')
            try {
                [IO.File]::Copy((Resource $homePath $r.path),$temporary,$false)
                if ((Digest $temporary) -cne $r.avant_sha256) { throw "Original modifie en cours de sauvegarde : $($r.path)" }
                [IO.File]::Move($temporary,$copy)
            } finally {
                if ([IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) }
            }
        }
    }
    # Keep a temporary rollback copy of any R1 resources. The stock backup
    # is never changed; it still restores the original game, not R1.
    $transition = Join-Path $backup ('.transition-r2-' + [Guid]::NewGuid().ToString('N'))
    foreach ($r in $rows) {
        $current = $state[$r.path]
        if ($current -ceq $r.precedent_sha256 -and $current -cne $r.avant_sha256 -and $current -cne $r.apres_sha256) {
            $copy = Resource $transition $r.path
            [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($copy)) | Out-Null
            [IO.File]::Copy((Resource $homePath $r.path),$copy,$false)
            if ((Digest $copy) -cne $current) { throw "Ressource precedente modifiee : $($r.path)" }
        }
    }
    $completed = New-Object 'System.Collections.Generic.List[object]'
    try {
        foreach ($r in $rows) {
            $install = $Action -eq 'Installer'
            $want = if ($install) { $r.apres_sha256 } else { $r.avant_sha256 }
            $from = if ($install) { $payload } else { $backup }
            if ($state[$r.path] -cne $want) {
                $dst = Resource $homePath $r.path
                if ((Digest $dst) -cne $state[$r.path]) { throw "Ressource modifiee pendant l'operation : $($r.path)" }
                Replace-Verified (Resource $from $r.path) $dst $want
                $completed.Add($r)
            }
        }
        foreach ($r in $rows) {
            $want = if ($Action -eq 'Installer') { $r.apres_sha256 } else { $r.avant_sha256 }
            if ((Digest (Resource $homePath $r.path)) -cne $want) { throw "Verification finale echouee : $($r.path)" }
        }
    } catch {
        $originalError = $_
        for ($i = $completed.Count - 1; $i -ge 0; $i--) {
            $r = $completed[$i]
            $from = if ($state[$r.path] -ceq $r.avant_sha256) { $backup } elseif ($state[$r.path] -ceq $r.apres_sha256) { $payload } else { $transition }
            try { Replace-Verified (Resource $from $r.path) (Resource $homePath $r.path) $state[$r.path] }
            catch {
                $keepTransition = $true
                Write-Warning "Restauration automatique echouee pour $($r.path). L'original et les copies de secours sont conserves dans $backup."
            }
        }
        throw $originalError
    }
    if ($Action -eq 'Installer') {
        Write-Host 'Correctif installe. Vous pouvez relancer Destiny.' -ForegroundColor Green
    } else {
        Write-Host 'Les ressources originales ont ete restaurees.' -ForegroundColor Green
    }
    Write-Host "Sauvegarde conservee : $backup"
    exit 0
} catch {
    Write-Host ('ARRET : ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
} finally {
    if ($transition -and !$keepTransition -and [IO.Directory]::Exists($transition)) {
        try { [IO.Directory]::Delete($transition,$true) }
        catch { Write-Warning "Des copies temporaires inutilisees sont encore dans $transition." }
    }
    if ($null -ne $lock) { $lock.Dispose() }
}
