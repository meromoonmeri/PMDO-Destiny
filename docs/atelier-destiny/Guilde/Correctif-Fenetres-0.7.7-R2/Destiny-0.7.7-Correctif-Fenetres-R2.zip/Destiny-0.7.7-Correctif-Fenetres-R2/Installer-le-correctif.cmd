@echo off
setlocal
if "%~1"=="" (
  powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Appliquer.ps1" -Action Installer
) else (
  powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Appliquer.ps1" -Action Installer -Dossier "%~1"
)
set "result=%errorlevel%"
echo.
pause
exit /b %result%
