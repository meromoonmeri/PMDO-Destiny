# PMD Destiny 0.7.7 — Fenêtres de la guilde, révision 2

**Correctif pour l’édition Windows x64 existante.** Cette révision supprime les petits pixels et traits sombres restés dans le vitrage. Le ZIP ne contient ni nouvelles cartes, ni un autre jeu, ni une sauvegarde.

## Installation

1. **Fermez Destiny** puis extrayez entièrement le ZIP dans un dossier de votre choix.
2. Lancez **`Installer-le-correctif.cmd`**. À l’invite, indiquez le dossier de votre jeu : c’est celui qui contient `Destiny.exe`, `Content` et `Data`.
3. Après le message « Correctif installé », relancez Destiny. Vous pouvez reprendre votre partie existante.

**Si le premier correctif a déjà été installé avec son installateur**, suivez les mêmes étapes avec ce nouveau ZIP. Inutile de restaurer d’abord : la révision 2 reprend la sauvegarde d’origine qui se trouve déjà dans le dossier du jeu.

Le script vérifie les dix fichiers et les adresses des tuiles dans l’index avant de modifier le jeu. Il conserve les originaux dans **`.sauvegarde-fenetres-0.7.7`**, à la racine du jeu. Il n’utilise pas Internet et n’a pas besoin de droits administrateur si le dossier du jeu vous est accessible en écriture. Si une ressource est incompatible, n’écrasez pas les fichiers à la main : vérifiez l’édition et la version du jeu.

**Retour à l’original :** fermez Destiny, lancez **`Restaurer-les-fichiers-originaux.cmd`** et sélectionnez le même dossier. Gardez le dossier de sauvegarde jusqu’à ce que vous n’ayez plus besoin de restaurer.

## Ce qui change

- Huit fenêtres complétées : Bureau du maître, Réfectoire (deux), Cuisine (deux), dortoirs nord I et II, chambre du héros.
- Les tuiles de premier plan ne masquent plus les vitres de l’arche. Au Réfectoire droit, les quatre panneaux manquants ont été complétés et raccordés aux bandes de verre existantes. Le vitrage généré sur fond magenta a été recadré sur les contours de cette baie et ramené aux teintes d’origine.
- Les six fenêtres déjà complètes restent intactes. Les cadres, croisillons, murs, passages, cartes, scripts, filtre global et sauvegardes ne sont pas remplacés. Les adresses des tuiles sont conservées : **`index.idx` n’est pas remplacé**.

## Comparaisons et contrôles

- **`Finition-avant-apres.png`** : gros plans capturés en jeu, avec et sans la dernière retouche.
- **`Avant-apres.png`** : les huit fenêtres comparées à la version non corrigée, jour et nuit.
- **`Quatre-ambiances.png`** : les huit fenêtres corrigées au jour, à l’aube, au crépuscule et la nuit.
- **`Verification-en-jeu.png`** : captures avant/après du Réfectoire dans le moteur Destiny 0.7.7.
- **`Controle.json`** : inventaire, empreintes des fichiers, bilan des contrôles.

Les 14 fenêtres ont été contrôlées dans les quatre ambiances avec les assemblages du jeu 0.7.7 sur un banc Linux. Aucun écart de plus d’un niveau RVB entre les captures et les rendus attendus. L’installation, le refus de ressources incompatibles et la restauration à l’identique ont été testés sur des copies des fichiers distribués avec PowerShell. L’exécution de l’installeur sur un PC Windows n’a pas été testée ici.

Base : [PMD Destiny — Windows 0.7.7](https://github.com/meromoonmeri/PMDO-Destiny/releases/tag/v0.7.7), commit `3d86bd838698d9de699c76f6f715c8eef35562e5`. Ressources graphiques de **meromoonmeri/PMDO-Destiny** et de ses contributeurs.
