-- whiscash_pond_layout_reverie : base d'edition PMDO 0.8.12, aucun warp.
local whiscash_pond_layout_reverie = {}
return whiscash_pond_layout_reverie
