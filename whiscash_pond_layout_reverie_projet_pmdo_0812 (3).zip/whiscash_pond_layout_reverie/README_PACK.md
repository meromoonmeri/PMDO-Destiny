# Whiscash Pond — Grand Doyen (768x576, PMDO 0.8.12)

- Format `TexSize = 1` (`8x8` px), `96 x 72` tuiles, zero mixel.
- Herbe et falaises Reverie Town + raccords cliff-grass en altitude style Canyon Camp.
- Chemin sableux style Metano Town (sans empreinte ni gravillons).
- Etang et 3 cascades couleur Reverie Town (4x10 ticks + 6 scintillements 18x18, cascades 8x5 ticks + ecume 3 poses).
- Plateforme complete + 4 river stones Reverie Town animees (8x5 ticks) + preparation nage Grand Doyen.
